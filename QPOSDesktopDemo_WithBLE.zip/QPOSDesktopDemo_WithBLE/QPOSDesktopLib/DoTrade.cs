﻿using System;
using System.Collections.Generic;
using static SDK_LIB.QPOSService;

namespace SDK_LIB
{
    /// <summary>
    /// DoTrade class implements a collection of methods that process the actual transaction.
    /// </summary>
    public class DoTrade
    {
        /// <summary>
        /// Private field to store an instance of the QPOS Service class
        /// </summary>
        private QPOSService esc;

        /// <summary>
        /// Fake Key used for demo and testing
        /// </summary>
        private byte[] fakekey = { (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00 };

        /// <summary>
        /// CTOR
        /// </summary>
        /// <param name="esc">QPOSService Object to be passed to the instance</param>
        public DoTrade(QPOSService esc)
        {
            this.esc = esc;
        }

        //    public bool doTrade(VPos pos, String tradeAmount, int timeout, String amountIcon) {
        //        CommandUplink uc = EMVPollCard(pos, tradeAmount, timeout, amountIcon);
        //        bool f = esc.checkCmdId(uc);
        //        if (f) {
        //            if (uc.result() == 0) {
        //                String result = Util.byteArray2Hex(uc.getBytes(0, uc.length()));
        //                Tip.d("poll card result:" + result);
        //                if (uc.getBytes(0, 1)[0] == 1) {
        //                    esc.onDoTradeResult(QPOSService.DoTradeResult.ICC, null);
        //                    return false;
        //                } else {
        //                    int encryMode = uc.getBytes(1, 1)[0] ;
        //                    Tip.d(">>>encryMode: " + encryMode);
        //                    if(encryMode==0x11){//钱方
        //                        doCheckCardResult_qf(QPOSService.DoTradeResult.MCR,uc);
        //                    }else{//默认
        //                        if(encryMode==0x12){//中智

        //                        }else if(encryMode==0x13){//钱袋

        //                        }else{//默认

        //                        }
        //                        doCheckCardResult(QPOSService.DoTradeResult.MCR, uc);
        //                    }

        //                }

        //            } else {
        //                Tip.d("uc.result() error = " + Util.byteArray2Hex(new byte[] { uc.result() }));
        //                esc.onError(QPOSService.Error.TIMEOUT);
        //            }
        //        }
        //        return true;
        //    }

        //    public bool doTrade(VPos pos, String tradeAmount, int timeout) {
        //        CommandDownlink dc = null;
        //        CommandUplink uc = null;
        //        uc = EMVPollCard(pos, tradeAmount, timeout,"");
        //        bool f = esc.checkCmdId(uc);
        //        if (f) {
        //            if (uc.result() == 0) {
        //                String result = Util.byteArray2Hex(uc.getBytes(0, uc.length()));
        //                Tip.d("poll card result:" + result);
        //                if (uc.getBytes(0, 1)[0] == 1) {
        //                    esc.onDoTradeResult(QPOSService.DoTradeResult.ICC, null);
        //                    return false;
        //                } 
        //                while(uc.getBytes(1, 1)[0]==0x02){
        //                    doCheckCardResult(QPOSService.DoTradeResult.BAD_SWIPE, uc);
        //                    dc = new CommandDownlink(CmdId.CMDID_QUERY,0,0, 30);
        //                    pos.sendCommand(dc);
        //                    uc = pos.receiveCommandWaitResult(30);
        //                    f = esc.checkCmdId(uc);
        //                    if(!f){
        //                        return true;
        //                    }
        //                    if (!esc.isTradeFlag()) {
        //                        return false;
        //                    }
        //                }
        //                if (uc.result() == 0) {
        //                    if (uc.getBytes(0, 1)[0] == 1) {
        //                        esc.onDoTradeResult(QPOSService.DoTradeResult.ICC, null);
        //                        return false;
        //                    }
        //                    if(uc.getBytes(1, 1)[0]==0x03){
        //                        doCheckCardResult(QPOSService.DoTradeResult.NONE, uc);
        //                        return true;
        //                    }else {
        //                        Tip.d("uc.getBytes(1, 1)[0] error = " + Util.byteArray2Hex(uc.getBytes(1, 1)));
        ////						if(uc.getBytes(1, 1)[0]==0x01){
        ////							doCheckCardResult(QPOSService.DoTradeResult.MCR, uc);
        ////							return true;
        ////						}
        //                        doCheckCardResult(QPOSService.DoTradeResult.MCR, uc);
        //                        return true;
        //                    }
        //                }else{
        //                    Tip.d("uc.result() error = " + Util.byteArray2Hex(new byte[] { uc.result() }));
        //                    esc.onError(QPOSService.Error.TIMEOUT);
        //                    return true;
        //                }
        //            }else {
        //                Tip.d("uc.result() error = " + Util.byteArray2Hex(new byte[] { uc.result() }));
        //                esc.onError(QPOSService.Error.TIMEOUT);
        //            }				
        //        }

        //        return true;
        //    }

        //    public bool doTrade(int tradeMode, String randomString, String tradeAmount, String extraString, int timeout, VPos pos) {
        //        CommandUplink uc = doTradeEx(tradeMode, randomString, tradeAmount, extraString, timeout, pos);
        //        bool f = esc.checkCmdId(uc);
        //        if(f){
        //            if(uc.result()==0){
        //                String result = Util.byteArray2Hex(uc.getBytes(0, uc.length()));
        //                Tip.d("poll card result:"+result);
        //                if(uc.getBytes(0, 1)[0]==1){
        //                    esc.onDoTradeResult(QPOSService.DoTradeResult.ICC, null);
        //                    return false;
        //                }else{		
        //                    Tip.d("QPOSService.DoTradeResult.MCR:");
        //                    //doCheckCardResult_qf(QPOSService.DoTradeResult.MCR,uc);
        //                    int encryMode = uc.getBytes(1, 1)[0];
        //                    Tip.d(">>>encryMode: " + encryMode);
        //                    if (encryMode == 0x11)
        //                    {//钱方
        //                        doCheckCardResult_qf(QPOSService.DoTradeResult.MCR, uc);
        //                    }
        //                    else
        //                    {//默认
        //                        if (encryMode == 0x12)
        //                        {//中智

        //                        }
        //                        else if (encryMode == 0x13)
        //                        {//钱袋

        //                        }
        //                        else
        //                        {//默认

        //                        }
        //                        doCheckCardResult(QPOSService.DoTradeResult.MCR, uc);
        //                    }
        //                }

        //            }else{
        //                Tip.d("uc.result() error = "+Util.byteArray2Hex(new byte[]{uc.result()}));
        //            }
        //        }	
        //        return true;
        //    }

        /// <summary>
        /// Method to perform the trading/transaction command (1620 command) based on the QPOS protocol
        /// </summary>
        /// <param name="pos">POS object</param>
        /// <param name="tradeAmount">The Amount of Transcation, set by user</param>
        /// <param name="timeout">Transaction Timeout value</param>
        /// <param name="amountIcon">Currency Symbol to be displayed on QPOS Screen</param>
        /// <param name="subTime">Time recorded at the begining of transaction</param>
        /// <param name="random">Randomly Generated Number, required by the firmware</param>
        /// <param name="extra">Additional Data</param>
        /// <param name="keyIndex">Key Index</param>
        /// <param name="cardTradeMode">Card Trade Mode</param>
        /// <param name="tradeType">Trade Type</param>
        /// <param name="currencyCode">Currency Code</param>
        /// <param name="customDisplayString">Customised Message to be displayed</param>
        /// <returns>Boolean value indicating if the operation is successful</returns>
        public bool doTrade(VPos pos, String tradeAmount, int timeout, String amountIcon,
            String subTime, String random, String extra, int keyIndex, CardTradeMode cardTradeMode, String tradeType, String currencyCode, String customDisplayString)
        {
            CommandUplink uc = null;
            uc = EMVPollCard(pos, tradeAmount, timeout, amountIcon, subTime, random, extra, keyIndex, cardTradeMode, tradeType, currencyCode, customDisplayString);
            return checkDoTradeResult(pos, uc);
        }

        /// <summary>
        /// Overloading method to perform the trading/transaction command (1620 command) based on the QPOS protocol
        /// </summary>
        /// <param name="pos">POS object</param>
        /// <param name="tradeAmount">The Amount of Transcation, set by user</param>
        /// <param name="timeout">Transaction Timeout value</param>
        /// <param name="amountIcon">Currency Symbol to be displayed on QPOS Screen</param>
        /// <returns>Boolean value indicating if the operation is successful</returns>
        public bool doTrade(VPos pos, String tradeAmount, int timeout, String amountIcon)
        {
            CommandUplink uc = null;
            uc = EMVPollCard(pos, tradeAmount, timeout, amountIcon);
            return checkDoTradeResult(pos, uc);
        }

        /// <summary>
        /// Overloading method to perform the trading/transaction command (1620 command) based on the QPOS protocol
        /// </summary>
        /// <param name="pos">POS object</param>
        /// <param name="tradeAmount">The Amount of Transcation, set by user</param>
        /// <param name="timeout">Transaction Timeout value</param>
        /// <returns>Boolean value indicating if the operation is successful</returns>
        public bool doTrade(VPos pos, String tradeAmount, int timeout)
        {
            CommandUplink uc = null;
            uc = EMVPollCard(pos, tradeAmount, timeout, "");
            return checkDoTradeResult(pos, uc);
        }

        /// <summary>
        /// Method to perform the 1010 command based on the QPOS protocol
        /// </summary>
        /// <param name="tradeMode">Operation Mode</param>
        /// <param name="randomString">Randomly Generated Number, required by the firmware, Must be 3 bytes long</param>
        /// <param name="tradeAmount">The Amount of Transcation, set by user</param>
        /// <param name="extraString">Additional data</param>
        /// <param name="timeout">Transaction Timeout value</param>
        /// <param name="pos">POS object</param>
        /// <returns>Boolean value indicating if the operation is successful</returns>
        public bool doTrade(int tradeMode, String randomString, String tradeAmount, String extraString, int timeout, VPos pos)
        {
            CommandUplink uc = null;
            uc = doTradeEx(tradeMode, randomString, tradeAmount, extraString, timeout, pos);
            return checkDoTradeResult(pos, uc);
        }

        /// <summary>
        /// Core method that analysis the 1620 and 1010 response message and pass the analysed result to
        /// event handler.
        /// If the method can successfully analyse the 1620 response message, then it will return true.
        /// Otherwise false.
        /// </summary>
        /// <param name="pos">POS object</param>
        /// <param name="uc">Uplink Command Message/Device reponse message</param>
        /// <returns>Boolean value indicates if the response message can be successfully analysed</returns>
        private bool checkDoTradeResult(VPos pos, CommandUplink uc)
        {
            CommandDownlink dc = null;
            bool f = esc.checkCmdId(uc);
            if (f)
            {
                if (uc.commandID() == CmdId.CMDID_INPUT_PIN_ING)
                {
                    dc = new CommandDownlink(CmdId.CMDID_QUERY, 0, 0, 30);
                    pos.sendCommand(dc);
                    uc = pos.receiveCommandWaitResult(30);
                    f = esc.checkCmdId(uc);
                    if (!f)
                    {
                        return true;
                    }
                }

                if (uc.commandID() == CmdId.CMDID_MAG_TO_ICC_TRADE)
                {
                    dc = new CommandDownlink(CmdId.CMDID_QUERY, 0, 0, 30);
                    pos.sendCommand(dc);
                    uc = pos.receiveCommandWaitResult(30);
                    f = esc.checkCmdId(uc);
                    if (!f)
                    {
                        return true;
                    }
                }

                // If the code can reach here, it means that no EMV card is detected and
                // MRC card swiped successfully. Proceed with further analysis
                if (uc.result() == 0) // If response is 0X00, indicate command execution success
                {
                    String result = Util.byteArray2Hex(uc.getBytes(0, uc.length())); // Convert the data inside the response message data frame payload to a string for displaying.
                    Tip.d("poll card result:" + result);
                    if (uc.getBytes(0, 1)[0] == 1) // If the device detects EMV IC card => Potentially redundant
                    {
                        esc.onDoTradeResult(QPOSService.DoTradeResult.ICC, null); // return card type to ICC and no MRC card info hashtable will be returned
                        return true;
                    }
                    while (uc.getBytes(1, 1)[0] == 0x02) // If device detects unsuccessful MRC card swipe
                    {
                        doCheckCardResult(QPOSService.DoTradeResult.BAD_SWIPE, uc); // A bad swipe is informed back to the APP
                        dc = new CommandDownlink(CmdId.CMDID_QUERY, 0, 0, 30); // App will keep updating the device status to see if customer rescan the MRC card
                        pos.sendCommand(dc);
                        uc = pos.receiveCommandWaitResult(30);
                        f = esc.checkCmdId(uc);
                        if (!f) // If MRC card rescanned successfully
                        {
                            return true;
                        }
                        if (!esc.isTradeFlag()) // If current trade/transaction is cannelled
                        {
                            return false;
                        }
                    }

                    // If response is 0X00, indicate command execution success
                    if (uc.result() == 0)
                    {
                        // Check Card Type/Status  refer Section 4.1.39 in QPOS protocol document for more info.
                        if (uc.getBytes(0, 1)[0] == 1) // EMV ICC card detected
                        {
                            esc.onDoTradeResult(QPOSService.DoTradeResult.ICC, null);
                            return false;
                        }
                        else if (uc.getBytes(0, 1)[0] == 3) // NFC online
                        {
                            doCheckCardResult(QPOSService.DoTradeResult.NFC_ONLINE, uc);
                            return true;
                        }
                        else if (uc.getBytes(0, 1)[0] == 4) // NFC offline
                        {
                            doCheckCardResult(QPOSService.DoTradeResult.NFC_OFFLINE, uc);
                            return true;
                        }
                        else if (uc.getBytes(0, 1)[0] == 5) // NFC Declined
                        {
                            doCheckCardResult(QPOSService.DoTradeResult.NFC_DECLINED, uc);
                            return true;
                        }

                        // Check the second byte of the response message
                        if (uc.getBytes(1, 1)[0] == 0x03) // Exceeds maximum number of card swipes
                        {
                            doCheckCardResult(QPOSService.DoTradeResult.NONE, uc);
                            return true;
                        }
                        else
                        {
                            Tip.d("uc.getBytes(1, 1)[0] error = " + Util.byteArray2Hex(uc.getBytes(1, 1)));
                            //						if(uc.getBytes(1, 1)[0]==0x01){
                            //							doCheckCardResult(DoTradeResult.MCR, uc);
                            //							return true;
                            //						}
                            //						doCheckCardResult(DoTradeResult.MCR, uc);

                            // Check the Encryption Mode
                            int encryMode = uc.getBytes(1, 1)[0];
                            Tip.d(">>>encryMode: " + encryMode);
                            if (encryMode == 0x11 || encryMode == 0x17 || encryMode == 0x1)
                            {//钱方
                                doCheckCardResult_qf(QPOSService.DoTradeResult.MCR, uc);
                            }
                            else
                            {//默认
                                if (encryMode == 0x12)
                                {//中智

                                }
                                else if (encryMode == 0x13)
                                {//钱袋

                                }
                                else
                                {//默认

                                }
                                doCheckCardResult(QPOSService.DoTradeResult.MCR, uc);
                            }

                            return true;
                        }
                    }
                    else // If the response code isn't 0X00 (Code repeated, TIMEOUT Error will be sent twice)
                    {
                        Tip.d("uc.result() error = " + Util.byteArray2Hex(new byte[] { uc.result() }));
                        esc.onError(QPOSService.Error.TIMEOUT);
                        return true;
                    }
                }
                else // If the reponse code isn't 0X00
                {
                    Tip.d("uc.result() error = " + Util.byteArray2Hex(new byte[] { uc.result() }));
                    esc.onError(QPOSService.Error.TIMEOUT);
                }
            }

            return true;
        }


        private void doCheckCardResult_qf(QPOSService.DoTradeResult result, CommandUplink uc)
        {

            Dictionary<String, String> hashtable = new Dictionary<String, String>();
            if (result == QPOSService.DoTradeResult.MCR)
            {
                int index = 0;

                //TODO IOS需要修改
                byte[] macSrc = uc.getBytes(index, uc.length() - 8);
                byte[] macdes = Packet.calMac(macSrc, macSrc.Length);

                byte[] mymac = uc.getBytes(uc.length() - 8, 8);
                Tip.d("my mac:" + Util.byteArray2Hex(mymac));

                for (int i = 0; i < macdes.Length; i++)
                {
                    if (mymac[i] != macdes[i])
                    {
                        esc.onError(QPOSService.Error.MAC_ERROR);
                        return;
                    }
                }

                index = 2;
                int trackblockLen = Util.byteArrayToInt(new byte[] { uc.getByte(index++) });
                String trackblock = Util.byteArray2Hex(uc.getBytes(index - 1, trackblockLen + 1));
                index += trackblockLen;

                int pinblockLen = 12;
                String pinblock = Util.byteArray2Hex(uc.getBytes(index, pinblockLen));
                index += pinblockLen;

                int psamIdLen = 8;
                String psamId = Util.byteArray2Hex(uc.getBytes(index, psamIdLen));
                index += psamIdLen;

                int posIdLen = 10;
                String posId = Util.byteArray2Hex(uc.getBytes(index, posIdLen));
                index += posIdLen;

                int macblockLen = 8;
                String macblock = Util.byteArray2Hex(uc.getBytes(index, macblockLen));
                index += macblockLen;

                byte[] btmp;
                int formatIDLen = uc.getByte(index++);
                btmp = uc.getBytes(index, formatIDLen);
                String formatID = System.Text.Encoding.UTF8.GetString(btmp, 0, btmp.Length);
                index += formatIDLen;

                int maskedPANLen = uc.getByte(index++);
                btmp = uc.getBytes(index, maskedPANLen);
                String maskedPAN = System.Text.Encoding.UTF8.GetString(btmp, 0, btmp.Length);
                index += maskedPANLen;

                int expiryDateLen = uc.getByte(index++);
                btmp = uc.getBytes(index, expiryDateLen);
                String expiryDate = System.Text.Encoding.UTF8.GetString(btmp, 0, btmp.Length);
                index += expiryDateLen;

                int serviceCodeLen = uc.getByte(index++);
                btmp = uc.getBytes(index, serviceCodeLen);
                String serviceCode = System.Text.Encoding.UTF8.GetString(btmp, 0, btmp.Length);
                index += serviceCodeLen;

                int cardHolderNameLen = uc.getByte(index++);
                btmp = uc.getBytes(index, cardHolderNameLen);
                String cardholderName = System.Text.Encoding.UTF8.GetString(btmp, 0, btmp.Length);
                index += cardHolderNameLen;

                String activateCode = "";
                //    Tip.d("countLen: " + countLen + ", index: " + index);
                if (index < uc.length() - 8)
                {
                    int cactivateCodeLen = uc.getByte(index++);
                    activateCode = Util.byteArray2Hex(uc.getBytes(index, cactivateCodeLen));

                    index += cactivateCodeLen;
                }

                //			int macLen = 8;
                //			String mymac = Util.byteArray2Hex(uc.getBytes(index,macLen));
                //			index += macLen;
                //			Tip.d("my mac:"+mymac);

                hashtable.Add("formatID", formatID);
                hashtable.Add("maskedPAN", maskedPAN);
                hashtable.Add("expiryDate", expiryDate);
                hashtable.Add("cardholderName", cardholderName);
                hashtable.Add("serviceCode", serviceCode);
                hashtable.Add("trackblock", trackblock);
                hashtable.Add("psamId", psamId);
                hashtable.Add("posId", posId);
                hashtable.Add("pinblock", pinblock);
                hashtable.Add("macblock", macblock);
                hashtable.Add("activateCode", activateCode);
                //			Tip.d("SWIPE_CARD_OK:" + Util.byteArray2Hex(uc.getBytes(0, uc.length())));
            }
            esc.onDoTradeResult(result, hashtable);

        }

        /// <summary>
        /// Analyse the response message of 1620 command.
        /// </summary>
        /// <param name="result">All available trade result type</param>
        /// <param name="uc">Response message</param>
        private void doCheckCardResult(QPOSService.DoTradeResult result, CommandUplink uc)
        {
            // Hash table to store the analysed results
            Dictionary<String, String> hashtable = new Dictionary<String, String>();
            //		    if (result == QPOSService.DoTradeResult.MCR) {
            int index = 0;

            int countLen = uc.length();
            index = 2; // Escape the first two bytes

            // Track 1 data
            int encTrack1Len = uc.getByte(index++);
            String encTrack1 = Util.byteArray2Hex(uc.getBytes(index, encTrack1Len));
            index += encTrack1Len;

            // Track 2 data
            int encTrack2Len = uc.getByte(index++);
            String encTrack2 = Util.byteArray2Hex(uc.getBytes(index, encTrack2Len));
            index += encTrack2Len;

            // Track 3 data
            int encTrack3Len = uc.getByte(index++);
            String encTrack3 = Util.byteArray2Hex(uc.getBytes(index, encTrack3Len));
            index += encTrack3Len;

            // Format ID
            byte[] btmp;
            int formatIDLen = uc.getByte(index++);
            btmp = uc.getBytes(index, formatIDLen);
            String formatID = System.Text.Encoding.UTF8.GetString(btmp, 0, btmp.Length);
            index += formatIDLen;

            // Masked Card Number/PAN
            int maskedPANLen = uc.getByte(index++);
            btmp = uc.getBytes(index, maskedPANLen);
            String maskedPAN = System.Text.Encoding.UTF8.GetString(btmp, 0, btmp.Length);
            index += maskedPANLen;

            // Expiry Date
            int expiryDateLen = uc.getByte(index++);
            btmp = uc.getBytes(index, expiryDateLen);
            String expiryDate = System.Text.Encoding.UTF8.GetString(btmp, 0, btmp.Length);
            index += expiryDateLen;

            // Service Code
            int serviceCodeLen = uc.getByte(index++);
            btmp = uc.getBytes(index, serviceCodeLen);
            String serviceCode = System.Text.Encoding.UTF8.GetString(btmp, 0, btmp.Length);
            index += serviceCodeLen;

            // Card Holder Name
            int cardHolderNameLen = uc.getByte(index++);
            btmp = uc.getBytes(index, cardHolderNameLen);
            String cardholderName = System.Text.Encoding.UTF8.GetString(btmp, 0, btmp.Length);
            index += cardHolderNameLen;

            // PIN Block
            int pinBlockLen = uc.getByte(index++);
            String pinBlock = Util.byteArray2Hex(uc.getBytes(index, pinBlockLen));
            index += pinBlockLen;

            // TrackKSN
            int trackksnLen = uc.getByte(index++);
            String trackksn = Util.byteArray2Hex(uc.getBytes(index, trackksnLen));
            index += trackksnLen;

            // PinKSN
            int pinKsnLen = uc.getByte(index++);
            String pinKsn = Util.byteArray2Hex(uc.getBytes(index, pinKsnLen));
            index += pinKsnLen;

            // Track and Pin Random Number
            String trackRandomNumber = "";
            String pinRandomNumber = "";
            if (index < countLen)
            {
                int trackRandomNumberLen = uc.getByte(index++);
                trackRandomNumber = Util.byteArray2Hex(uc.getBytes(index, trackRandomNumberLen));
                index += trackRandomNumberLen;

            }
            if (index < countLen)
            {
                int pinRandomNumberLen = uc.getByte(index++);
                pinRandomNumber = Util.byteArray2Hex(uc.getBytes(index, pinRandomNumberLen));
                index += pinRandomNumberLen;
            }

            // PSAM No.
            String psamNo = "";
            if (index < countLen)
            {//qdb模式回多一个字段
                int psamNoLen = uc.getByte(index++);//psam编号
                btmp = uc.getBytes(index, psamNoLen);
                psamNo = System.Text.Encoding.UTF8.GetString(btmp, 0, btmp.Length);
                index += psamNoLen;
            }

            // Track #1,#2,#3 Lengths
            String track1Length = "";
            String track2Length = "";
            String track3Length = "";
            if (index < countLen)
            {//磁道数据长度
                int t1Len = uc.getByte(index++);//磁道1原始数据长度
                int t2Len = uc.getByte(index++);//磁道2原始数据长度
                int t3Len = uc.getByte(index++);//磁道3原始数据长度

                track1Length = t1Len + "";
                track2Length = t2Len + "";
                track3Length = t3Len + "";
            }

            // Combine the track 2 and track 3 hexdecimal string data
            String encTracks = encTrack2 + encTrack3;
            String partialTrack = "";

            String ksn = "";

            hashtable.Add("formatID", formatID);
            hashtable.Add("maskedPAN", maskedPAN);
            hashtable.Add("expiryDate", expiryDate);
            hashtable.Add("cardholderName", cardholderName);
            hashtable.Add("ksn", ksn);
            hashtable.Add("serviceCode", serviceCode);
            hashtable.Add("track1Length", track1Length);
            hashtable.Add("track2Length", track2Length);
            hashtable.Add("track3Length", track3Length);
            hashtable.Add("encTracks", encTracks.Trim());
            hashtable.Add("encTrack1", encTrack1);
            hashtable.Add("encTrack2", encTrack2);
            hashtable.Add("encTrack3", encTrack3);
            hashtable.Add("partialTrack", partialTrack);
            hashtable.Add("pinBlock", pinBlock);
            hashtable.Add("pinKsn", pinKsn);
            hashtable.Add("trackksn", trackksn);
            hashtable.Add("trackRandomNumber", trackRandomNumber);
            hashtable.Add("pinRandomNumber", pinRandomNumber);
            hashtable.Add("psamNo", psamNo);

            Tip.d("SWIPE_CARD_OK:" + Util.byteArray2Hex(uc.getBytes(0, uc.length())));
            //		    }
            if ((result == QPOSService.DoTradeResult.NFC_ONLINE) || (result == QPOSService.DoTradeResult.NFC_OFFLINE))
            {
                // Obtain TLV Batch Data
                Dictionary<String, String> h = esc.getNFCBatchData();
                Tip.d("nfc batchdata: " + h["tlv"]);
                String content = h["tlv"];
                hashtable.Add("NFCBatchData", content);
            }
            esc.onDoTradeResult(result, hashtable);

        }

        /// <summary>
        /// Core Method to implement the 1010 command based on the QPOS protocol
        /// </summary>
        /// <param name="type">Operation Mode</param>
        /// <param name="random">Randomly Generated Number, required by the firmware, must be 3 Bytes long</param>
        /// <param name="amountString">The Amount of Transcation, set by user, max length = 12 Bytes</param>
        /// <param name="extraString">Additional Data</param>
        /// <param name="timeout">Transaction Timeout value</param>
        /// <param name="pos">POS object</param>
        /// <returns>Device response to 1620 command</returns>
        private CommandUplink doTradeEx(int type, String random, String amountString, String extraString, int timeout, VPos pos)
        {
            byte[] mode = { (byte)type };
            byte[] r = System.Text.Encoding.UTF8.GetBytes(random); // Write the random number bytes
            byte[] m = new byte[0]; // Byte array that holds the transaction amount set by the user

            // Write the trade/transaction amount
            if (amountString != null && !("" == amountString))
            {
                m = System.Text.Encoding.UTF8.GetBytes(amountString);
            }

            // Write the Extra Data Bytes
            byte[] e = System.Text.Encoding.UTF8.GetBytes(extraString);

            // Construct the byte array that holds all the command parameters
            int len = mode.Length + r.Length + m.Length + e.Length;
            int plen = len + 8 + 3;
            byte[] paras = new byte[plen + 1];

            // Write the card trade mode to the first byte of the parameter byte array
            int index = 0;
            Array.Copy(mode, 0, paras, index, mode.Length);
            index += mode.Length;

            // Write the Random Generated Number Length value after the card trade mode bytes
            paras[index] = (byte)r.Length;
            index += 1;
            Array.Copy(r, 0, paras, index, r.Length);
            index += r.Length;

            // Write the Transaction Amount length and Transcation Amount data
            paras[index] = (byte)m.Length;
            index += 1;
            Array.Copy(m, 0, paras, index, m.Length);
            index += m.Length;

            // Write the Extra Data length and extra data
            paras[index] = (byte)e.Length;
            index += 1;
            Array.Copy(e, 0, paras, index, e.Length);
            index += e.Length;

            // Write the next byte after the Extra Data Byte array with value 0X14. Not documented in the QPOS hardware protocol.
            paras[index] = 0x14;
            index += 1;
            Tip.d("para lent" + index);

            //System.Diagnostics.Debug.Assert (index == len);
            //TODO IOS需要修改
            byte[] mac = Packet.calMac(paras, paras.Length - 8); // Calculate MAC for the command message
            // Write the MAC bytes
            Array.Copy(mac, 0, paras, index, 8);
            index += 8;
            //System.Diagnostics.Debug.Assert (index == (len + 8));

            CommandDownlink dc = new CommandDownlink(0x10, 0x10, timeout, paras);
            pos.sendCommand(dc);
            esc.onRequestWaitingUser();
            CommandUplink uc = null;
            uc = pos.receiveCommandWaitResult(timeout);

            return uc;

        }

        /// <summary>
        /// Core Method to implement the trading/transaction command (1620 command) based on the QPOS protocol
        /// </summary>
        /// <param name="pos">POS object</param>
        /// <param name="tradeAmount">The Amount of Transcation, set by user</param>
        /// <param name="timeout">Transaction Timeout value</param>
        /// <param name="amountIcon">Currency Symbol to be displayed on QPOS Screen</param>
        /// <param name="subTime">Time recorded at the begining of transaction</param>
        /// <param name="random">Randomly Generated Number, required by the firmware</param>
        /// <param name="extra">Additional Data</param>
        /// <param name="keyIndex">Key Index</param>
        /// <param name="cardTradeMode">Card Trade Mode</param>
        /// <param name="tradeType">Trade Type</param>
        /// <param name="currencyCode">Currency Code</param>
        /// <param name="customDisplayString">Customised Message to be displayed</param>
        /// <returns>Device response to 1620 command</returns>
        private CommandUplink EMVPollCard(VPos pos, String tradeAmount, int timeout,
            String amountIcon, String subTime, String random, String extra, int keyIndex,
            CardTradeMode cardTradeMode, String tradeType, String currencyCode, String customDisplayString)
        {
            CommandDownlink dc = null; // store Downlink message
            CommandUplink uc = null; // store Uplink message

            int index = 0;
            byte[] paras = new byte[0];
            byte[] amountIconArr = new byte[0];
            byte[] terminalTimeArr = new byte[0];
            byte[] amountArr = new byte[0];
            byte[] randomArr = new byte[0];
            byte[] extraArr = new byte[0];
            byte[] cdsArr = new byte[0];

            // Set the Currency Symbol and determine the currency Symbol byte array length
            int amountIconLen = 0;
            if (amountIcon != null && !("" == amountIcon))
            {
                //			amountIconArr = amountIcon.Trim().getBytes();
                amountIconArr = Util.HexStringToByteArray(amountIcon.Trim());
                amountIconLen = amountIconArr.Length;
            }

            // Set the Trade Amount Data Byte Array and determine the Byte Array length
            int amountLen = 0;
            if (tradeAmount != null && !("" == tradeAmount))
            {
                amountArr = System.Text.Encoding.UTF8.GetBytes(tradeAmount.Trim());
                amountLen = amountArr.Length;
            }

            // Set the Terminal Time Data Byte Array and determine the Byte Array length
            int terminalTimeLen = 0;
            String terminalTime = DateTime.Now.ToString("yyyyMMddHHmmss"); // use current system time as the transcation initiation time
            if (terminalTime != null && !("" == terminalTime))
            {
                //			amountIconArr = amountIcon.Trim().getBytes();
                terminalTimeArr = Util.HexStringToByteArray(terminalTime.Trim());
                terminalTimeLen = terminalTimeArr.Length;
            }

            // Set the Randomly Generated Number Data Byte Array and determine the Byte Array length
            int randomLen = 0;
            if (random != null && !"".Equals(random))
            {
                randomArr = Util.HexStringToByteArray(random.Trim());
                randomLen = randomArr.Length;
            }

            // Set the Additional Data Data Byte Array and determine the Byte Array length
            int extraLen = 0;
            if (extra != null && !"".Equals(extra))
            {
                extraArr = System.Text.Encoding.UTF8.GetBytes(extra.Trim());
                extraLen = extraArr.Length;
            }

            // Set the Custom Display String Data Byte Array and determine the Byte Array length
            int cuDispayLen = 0;
            String cds = customDisplayString;
            if (cds != null && !"".Equals(cds))
            {
                cdsArr = Util.HexStringToByteArray(cds.Trim());
                cuDispayLen = cdsArr.Length;
            }

            // Redeclare the byte array that holds all parameters
            paras = new byte[1 + amountLen + 1 + 1 + amountIconLen + 1 + 1 + terminalTimeLen + +
                1 + randomLen + 1 + extraLen + 1 + 1 + 1 + 1 + 2 + 1 + cuDispayLen +
                8];
            paras[index++] = (byte)amountLen;
            Array.Copy(amountArr, 0, paras, index, amountLen);
            index += amountLen;

            // Write the Byte value for Card Trade Mode based on selected enum option
            if (esc.getCardTradeMode() == QPOSService.CardTradeMode.ONLY_INSERT_CARD)
            {
                paras[index++] = 0x01;
            }
            else if (esc.getCardTradeMode() == QPOSService.CardTradeMode.ONLY_SWIPE_CARD)
            {
                paras[index++] = 0x02;
            }
            else if (esc.getCardTradeMode() == QPOSService.CardTradeMode.SWIPE_INSERT_CARD)
            {
                paras[index++] = 0x03;
            }
            else if (esc.getCardTradeMode() == QPOSService.CardTradeMode.UNALLOWED_LOW_TRADE)
            {
                paras[index++] = 0x04;
            }
            else if (esc.getCardTradeMode() == QPOSService.CardTradeMode.SWIPE_TAP_INSERT_CARD)
            {
                paras[index++] = 0x05;
            }
            else if (esc.getCardTradeMode() == QPOSService.CardTradeMode.SWIPE_TAP_INSERT_CARD_UNALLOWED_LOW_TRADE)
            {
                paras[index++] = 0x06;
            }
            else if (esc.getCardTradeMode() == QPOSService.CardTradeMode.ONLY_TAP_CARD)
            {
                paras[index++] = 0x07;
            }
            else // If specified mode is not within the enum list then default to SWIPE_INSERT_CARD mode
            {
                paras[index++] = 0x03;
            }

            // Write the Currency Symbol length and Currency Symbol
            paras[index++] = (byte)amountIconLen;
            Array.Copy(amountIconArr, 0, paras, index, amountIconLen);
            index += amountIconLen;

            // Write the Byte value for Trade Mode based on selected enum option
            if (esc.getDoTradeMode() == QPOSService.DoTradeMode.CHECK_CARD_NO_IPNUT_PIN)
            {
                paras[index++] = 0x01;
            }
            else // User need to enter pin
            {
                paras[index++] = 0x00;
            }

            // Write the terminal time length and terminal time
            paras[index++] = (byte)terminalTimeLen;
            Array.Copy(terminalTimeArr, 0, paras, index, terminalTimeLen);
            index += terminalTimeLen;

            // Write the random number length and random number
            paras[index++] = (byte)randomLen;
            Array.Copy(randomArr, 0, paras, index, randomLen);
            index += randomLen;

            // Write the extra data length and extra data
            paras[index++] = (byte)extraLen;
            Array.Copy(extraArr, 0, paras, index, extraLen);
            index += extraLen;

            // Write the Key Index
            paras[index++] = (byte)keyIndex;

            // Set the Flag to the device to decide if the POS will set the transaction amount
            if (esc.isPosInputAmountFlag())
            {
                paras[index++] = 0x01;
            }
            else
            {

                paras[index++] = 0x00;
            }
            esc.setPosInputAmountFlag(false);

            // Set the Flag to the device to decide if the POS will display the transaction amount
            if (esc.isPosDisplayAmountFlag())
            {
                paras[index++] = 0x01;
            }
            else
            {
                paras[index++] = 0x00;
            }
            esc.setPosDisplayAmountFlag(true);

            // Write the Trade Type Data length and Trade Type Data
            if (tradeType == null || "".Equals(tradeType))
            {
                tradeType = "01";
            }
            paras[index++] = Util.HexStringToByteArray(tradeType)[0];

            // Write the currency code length and currency code
            if (currencyCode == null || "".Equals(currencyCode))
            {
                currencyCode = "0156"; // default currency code
            }
            if (currencyCode.Length == 3) // if the inputed currency code doesn't have 4 characters
            {
                currencyCode = "0" + currencyCode;
            }
            paras[index++] = Util.HexStringToByteArray(currencyCode)[0];
            paras[index++] = Util.HexStringToByteArray(currencyCode)[1];

            // Write the custom message length and custom message
            paras[index++] = (byte)cuDispayLen;
            Array.Copy(cdsArr, 0, paras, index, cuDispayLen);
            index += cuDispayLen;

            // Encryption Mode Length and Encryption Mode Data
            //paras[index++] = (byte)0X01;
            //paras[index] = (byte)0X20;
            //index += 1;

            // Calculate and append 8 bytes of MAC value
            byte[] mac = Packet.calMac(paras, paras.Length - 8);
            Array.Copy(mac, 0, paras, index, 8);
            index += 8;

            // Construct and send the downlink command
            // And wait for device response.
            dc = new CommandDownlink(0x16, 0x20, timeout, paras);
            pos.sendCommand(dc);
            esc.onRequestWaitingUser();
            uc = pos.receiveCommandWaitResult(timeout);
            return uc;
        }

        /// <summary>
        /// EMVPollCard function overload. Core Method to implement the trading/transaction command (1620 command) based on the QPOS protocol
        /// </summary>
        /// <param name="pos">POS object</param>
        /// <param name="tradeAmount">The Amount of Transcation, set by user</param>
        /// <param name="timeout">Transaction Timeout value</param>
        /// <param name="amountIcon">Currency Symbol to be displayed on QPOS Screen</param>
        /// <returns>Device response to 1620 command</returns>
        private CommandUplink EMVPollCard(VPos pos, String tradeAmount, int timeout, String amountIcon)
        {
            CommandDownlink dc = null; // store Downlink message (Command that will be sent to Device)
            CommandUplink uc = null; // store Uplink message (Response from device to the received command)

            int index = 0;
            byte[] paras = new byte[0];
            byte[] amountIconArr = new byte[0];
            byte[] terminalTimeArr = new byte[0];
            byte[] amountArr = new byte[0];

            // Set the Currency Symbol and determine the currency Symbol byte array length
            int amountIconLen = 0;
            if (amountIcon != null && !("" == amountIcon))
            {
                //			amountIconArr = amountIcon.Trim().getBytes();
                amountIconArr = Util.HexStringToByteArray(amountIcon.Trim());
                amountIconLen = amountIconArr.Length;
            }

            // Set the Trade Amount Data Byte Array and determine the Byte Array length
            int amountLen = 0;
            if (tradeAmount != null && !("" == tradeAmount))
            {
                amountArr = System.Text.Encoding.UTF8.GetBytes(tradeAmount.Trim());
                amountLen = amountArr.Length;
            }

            // Set the Terminal Time Data Byte Array and determine the Byte Array length
            int terminalTimeLen = 0;
            String terminalTime = DateTime.Now.ToString("yyyyMMddHHmmss");
            if (terminalTime != null && !("" == terminalTime))
            {
                //			amountIconArr = amountIcon.Trim().getBytes();
                terminalTimeArr = Util.HexStringToByteArray(terminalTime.Trim());
                terminalTimeLen = terminalTimeArr.Length;
            }

            // Redeclare the byte array that holds all parameters
            paras = new byte[1 + amountLen + 1 + 1 + amountIconLen + 1 + 1 + terminalTimeLen];
            paras[index++] = (byte)amountLen;  // write amount length
            Array.Copy(amountArr, 0, paras, index, amountLen); // copy transaction amount
            index += amountLen;

            // Write the Byte value for Card Trade Mode based on selected enum option
            if (esc.getCardTradeMode() == QPOSService.CardTradeMode.ONLY_INSERT_CARD)
            {
                paras[index++] = 0x01;
            }
            else if (esc.getCardTradeMode() == QPOSService.CardTradeMode.ONLY_SWIPE_CARD)
            {
                paras[index++] = 0x02;
            }
            else if (esc.getCardTradeMode() == QPOSService.CardTradeMode.SWIPE_INSERT_CARD)
            {
                paras[index++] = 0x03;
            }
            else if (esc.getCardTradeMode() == QPOSService.CardTradeMode.UNALLOWED_LOW_TRADE)
            {
                paras[index++] = 0x04;
            }
            else if (esc.getCardTradeMode() == QPOSService.CardTradeMode.SWIPE_TAP_INSERT_CARD)
            {
                paras[index++] = 0x05;
            }
            else if (esc.getCardTradeMode() == QPOSService.CardTradeMode.SWIPE_TAP_INSERT_CARD_UNALLOWED_LOW_TRADE)
            {
                paras[index++] = 0x06;
            }
            else if (esc.getCardTradeMode() == QPOSService.CardTradeMode.ONLY_TAP_CARD)
            {
                paras[index++] = 0x07;
            }
            else // If specified mode is not within the enum list then default to SWIPE_INSERT_CARD mode
            {
                paras[index++] = 0x03;
            }

            // Write the Currency Symbol length and Currency Symbol
            paras[index++] = (byte)amountIconLen;
            Array.Copy(amountIconArr, 0, paras, index, amountIconLen);
            index += amountIconLen;

            // Write the Byte value for Trade Mode based on selected enum option
            if (esc.getDoTradeMode() == QPOSService.DoTradeMode.CHECK_CARD_NO_IPNUT_PIN)
            {
                paras[index++] = 0x01;
            }
            else // User need to enter pin
            {
                paras[index++] = 0x00;
            }

            // Write the terminal time length and terminal time
            paras[index++] = (byte)terminalTimeLen;
            Array.Copy(terminalTimeArr, 0, paras, index, terminalTimeLen);
            index += terminalTimeLen;

            // Construct and send the downlink command
            // And wait for device response.
            dc = new CommandDownlink(0x16, 0x20, timeout, paras);
            pos.sendCommand(dc);
            esc.onRequestWaitingUser();
            uc = pos.receiveCommandWaitResult(timeout);
            return uc;
        }

        /// <summary>
        /// Method to execute the getPin() core function and analyse the returned data into hash table.
        /// </summary>
        /// <param name="pos">POS object</param>
        /// <param name="pinTransactionData">Transaction Data that will indicate the specified transaction</param>
        public void doGetPin(VPos pos, String pinTransactionData)
        {
            CommandUplink uc = getPin(pos, pinTransactionData);
            bool f = esc.checkCmdId(uc);
            if (!f)
            {
                return;
            }

            Dictionary<String, String> hashtable = new Dictionary<String, String>();
            int index = 0;
            int en_mode = uc.getByte(index++);
            if (en_mode == 0)
            {
                int pinKsnLen = uc.getByte(index++);
                String pinKsn = Util.byteArray2Hex(uc.getBytes(index, pinKsnLen));
                index += pinKsnLen;

                int pinBlockLen = uc.getByte(index++);
                String pinBlock = Util.byteArray2Hex(uc.getBytes(index, pinBlockLen));
                index += pinBlockLen;

                hashtable.Add("pinKsn", pinKsn);
                hashtable.Add("pinBlock", pinBlock);
                esc.onReturnGetPinResult(hashtable);
            }
            else
            {
                esc.onError(QPOSService.Error.UNKNOWN);
            }
        }

        /// <summary>
        /// Core function for implementing the 1070 commands,
        /// </summary>
        /// <param name="pos">POS object</param>
        /// <param name="pinTransactionData">Transaction Data that will indicate the specified transaction</param>
        /// <returns>Uplink Command object contains response message</returns>
        private CommandUplink getPin(VPos pos, String pinTransactionData)
        {
            CommandDownlink dc = null;
            CommandUplink uc = null;

            int pinTransactionDataLen = 0;
            String str = "";
            if (pinTransactionData != null && !("" == pinTransactionData))
            {
                pinTransactionDataLen = pinTransactionData.Length;
                str = Util.byteArray2Hex(System.Text.Encoding.UTF8.GetBytes(pinTransactionData));
            }

            byte[] lens = Util.IntToHex(pinTransactionDataLen);
            String strr = "06" + Util.byteArray2Hex(lens) + str + "00";
            byte[] paras = Util.HexStringToByteArray(strr);
            dc = new CommandDownlink(0x10, 0x70, 60, paras);
            pos.sendCommand(dc);
            uc = pos.receiveCommandWaitResult(60);

            return uc;
        }
    }
}
