﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using SDK_LIB;

namespace SDK_LIB
{
    public class DoEmvApp
    {
        private QPOSService esc;
	    private EmvTradeState emvTradeState = EmvTradeState.WAITING;
	    private String EmvGoOnLineData = "";
	    private static int SLEEPTIME = 30;
	
	
	    private static String AUTH_REQ   		=     "01";   //联机授权请求
	    private static String FINA_REQ   		=     "02";   //联机金融请求
	    private static String FINA_CONFIRM  	=     "03";   // 金融确认报文
	    private static String BATCH_DC        =     "04";   //   
	    private static String OFFLINE_ADVICE  =     "05";   //
	    private static String ONLINE_ADVICE   =     "06";   //联机通知报文
	    private static String REVERSAL        =     "07";   //冲正报文
	    private static String CAPK_DOWNLOAD   =     "08";   // 
	
	    private static String EMV_TRANS_FALLBACK            =     "22";			/*fallback*/// -2
	    private static String EMV_TRANS_TERMINATE           =     "21";			/*交易中止*/ //-1 q return to polling??
	    private static String EMV_TRANS_ACCEPT              =     "01";			/*交易授受*/
	    private static String EMV_TRANS_DENIAL              =     "02";			/*交易拒绝*/
	    private static String EMV_TRANS_GOONLINE            =     "03";			/*联机*/
	    private static String EMV_TRANS_2GAC_AAC            =     "04";			/*第二个Generate AC返回AAC*/
	    private static String EMV_TRANS_ONLINEFAIL          =     "05";			/*emv_opt._online_result联机失败*/
	    private static String EMV_TRANS_ONLINESUCC_ACCEPT   =     "06";			/*emv_opt._online_result联机成功并授受交�?/
	    private static String EMV_TRANS_ONLINESUCC_DENIAL   =     "07";			/*emv_opt._online_result联机成功并拒绝参�?/
	    private static String EMV_TRANS_ONLINESUCC_ISSREF   =     "08";			/*emv_opt._online_result联机成功并返回参�?/
	    private static String EMV_TRANS_GOON_PBOC2LOG       =     "09";			/*返回PBOC2日志*/
	
	    public String getEmvGoOnLineData() {
		    return EmvGoOnLineData;
	    }

	    public void setEmvGoOnLineData(String emvGoOnLineData) {
		    EmvGoOnLineData = emvGoOnLineData;
	    }

	    public EmvTradeState getEmvTradeState() {
		    return emvTradeState;
	    }

	    public void setEmvTradeState(EmvTradeState emvTradeState) {
		    this.emvTradeState = emvTradeState;
	    }

	    public enum EmvTradeState{
		    CANCEL,
		    SET,
		    WAITING
	    }
	

	    public DoEmvApp(QPOSService esc){
		    this.esc = esc;
	    }

	    public void doEMVApp(String tradeAmount,String tradeType,String terminalTime, String currencyCode, VPos pos){
		    CommandUplink uc = null;
		    bool f = false;

		    uc = EMVStart(pos,esc.getEmvOption(),tradeType,terminalTime,tradeAmount, currencyCode);
		    f = esc.checkCmdId(uc);		
		    if(!f)return;
            while(uc.commandID() != CmdId.CMDID_COMPLETED)
            {
                CommandDownlink dc = new CommandDownlink(CmdId.CMDID_QUERY, 0, 0, 30);
                pos.sendCommand(dc);
                uc = pos.receiveCommandWaitResult(30);
                f = esc.checkCmdId(uc);
                if (!f) return;
            }
            // f = esc.checkCmdId(uc);
            Tip.d("1630:" + Util.byteArray2Hex(uc.getBytes(0, uc.length())));

            while (uc.result()==0x02){
			    Tip.d("select emv app");

                List<String> appList = new List<String>();
			    int allLen = uc.length();
			    Tip.d("alllen = "+allLen);
			    int index = 0;
			    int appCount = uc.getByte(index++);
			    Tip.d("appCount = "+appCount);			
			
			    for (int i = 0; i < appCount; i++) {
				    index++;
				    index++;
				    int app1Len = uc.getByte(index++);
                    byte[] ucbarr = uc.getBytes(index, app1Len);
                    String app1 = System.Text.Encoding.UTF8.GetString(ucbarr, 0, ucbarr.Length);
				    index += app1Len;
				    appList.Insert(i, app1);
			    }
						
			    setEmvTradeState(EmvTradeState.WAITING);
			    esc.onRequestSelectEmvApp(appList);
			    while(getEmvTradeState()==EmvTradeState.WAITING){
                    //System.Threading.Thread.Sleep(SLEEPTIME);				    
                    TaskSleeper.TaskSleep(SLEEPTIME);
                }	
			    Tip.d("select emv app getEmvTradeState()= "+getEmvTradeState());
    //			if(getEmvTradeState()==EmvTradeState.CANCEL){
    //				esc.onTransactionResult(TransactionResult.CANCEL);
    //				esc.showLogo(pos);
    //				return;
    //			}else if(getEmvTradeState()==EmvTradeState.SET){
				    setEmvTradeState(EmvTradeState.WAITING);
    //			}
			    if(!esc.isTradeFlag()){
				    return;
			    }
			    uc = EMVSelectEMVApp(pos,esc.getSelectEmvAppIndex());
			    f = esc.checkCmdId(uc);
			    if(!f){
				    return;
			    }
			
		    }
		
		    //////////////////////////////////////////////////////////////////////////////////
		    //输入密码
		    bool isPin = false;
		    while(uc.result()==0x0a){
			    isPin = true;
			    setEmvTradeState(EmvTradeState.WAITING);
			    esc.onRequestSetPin();
			    while(getEmvTradeState()==EmvTradeState.WAITING){
                    //System.Threading.Thread.Sleep(SLEEPTIME);				    
                    TaskSleeper.TaskSleep(SLEEPTIME);
                }	
			    Tip.d("set emv pin getEmvTradeState()= "+getEmvTradeState());
			
			    String pinMode = "00";
			    if(getEmvTradeState()==EmvTradeState.CANCEL){
    //						esc.onRequestTransactionResult(TransactionResult.CANCEL);
				    pinMode = "00";
			    }else if(getEmvTradeState()==EmvTradeState.SET){
				    pinMode = "01";
			    }
			    setEmvTradeState(EmvTradeState.WAITING);
			    if (!esc.isTradeFlag()) {
				    return ;
			    }
			    String pin = esc.getPinStr();
			    esc.emptyPin();
			    uc = EMVSetEmvPin(pos,pinMode,pin);
			    Tip.d(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>set emv pin end");
			    f = esc.checkCmdId(uc);
			    pin = "";
			    if(!f){
				    Tip.d(">>>>>>>>>set emv pin failed");
				    return;
			    }
			
		    }
		    if(isPin){
			    esc.onRequestDisplay(QPOSService.Display.PIN_OK);
                //esc.onRequestDisplay(QPOSService.Display.PROCESSING);
		    }		

			 while (uc.commandID() == CmdId.CMDID_INPUT_PIN_ING)
            {
                uc = esc.inquireResult(pos);
                f = esc.checkCmdId(uc);
                if (!f)
                {
                    return;
                }
            }
		    //////////////////////////////////////////////////////////////////////////////////
		
		
		
		    /*
		    #define AUTH_REQ        0x01   联机授权请求
		    #define FINA_REQ        0x02   联机金融请求
		    #define FINA_CONFIRM    0x03   金融确认报文
		    #define BATCH_DC        0x04   
		    #define OFFLINE_ADVICE  0x05
		    #define ONLINE_ADVICE   0x06  联机通知报文
		    #define REVERSAL        0x07  冲正报文
		    #define CAPK_DOWNLOAD   0x08  
		    */ 
		
		
		    Dictionary<String, String> hashtable = analysisEmvResult(uc.getBytes(0, uc.length()));
		    String transResult = hashtable[("transResult")];
		    String packType = hashtable[("packType")];
		    String issScriptRes = hashtable[("issScriptRes")];
		    String forceAccept = hashtable[("forceAccept")];
		    String iccData = hashtable[("iccData")];
		
		    //在线交易
		    if (EMV_TRANS_GOONLINE==(transResult)) {
			    esc.onRequestDisplay(QPOSService.Display.PROCESSING);
			    //确认服务器连
			    setEmvTradeState(EmvTradeState.WAITING);
			    esc.onRequestIsServerConnected();
			    while(getEmvTradeState()==EmvTradeState.WAITING){
                    TaskSleeper.TaskSleep(SLEEPTIME);
                    //System.Threading.Thread.Sleep(SLEEPTIME);				    
                }	
			    Tip.d("server connect getEmvTradeState() = "+getEmvTradeState());
			    if(getEmvTradeState()==EmvTradeState.CANCEL){
                    esc.onRequestTransactionResult(QPOSService.TransactionResult.CANCEL);
				    esc.exit_pos_trade(pos);
				    return;
			    }else if(getEmvTradeState()==EmvTradeState.SET){
				    setEmvTradeState(EmvTradeState.WAITING);
			    }
			    f = go_online(iccData,pos);
			    if(!f){
				    esc.exit_pos_trade(pos);
                    esc.onError(QPOSService.Error.UNKNOWN);
			    }
			    return;
		    }else if (EMV_TRANS_DENIAL==(transResult)) {
			    if(ONLINE_ADVICE==(packType) || OFFLINE_ADVICE==(packType)){
    //				esc.onRequestDisplay(Display.DECLINED);
                    esc.onRequestDisplay(QPOSService.Display.REMOVE_CARD);
				
				    esc.onRequestBatchData(iccData);
                    esc.onRequestTransactionResult(QPOSService.TransactionResult.DECLINED);
				    return;
			    }else if (REVERSAL==(packType)){
    //				esc.onRequestDisplay(DisplayText.DECLINED);
                    esc.onRequestDisplay(QPOSService.Display.REMOVE_CARD);
							
				    esc.onReturnReversalData(iccData);
                    esc.onRequestTransactionResult(QPOSService.TransactionResult.DECLINED);
				    return;
			    }
		    }else if (EMV_TRANS_ACCEPT==(transResult)) {
			    if (REVERSAL==(packType)){
    //				esc.onRequestDisplay(DisplayText.DECLINED);
                    esc.onRequestDisplay(QPOSService.Display.REMOVE_CARD);
							
				    esc.onReturnReversalData(iccData);
                    esc.onRequestTransactionResult(QPOSService.TransactionResult.DECLINED);
				    return;
			    }else  if(FINA_CONFIRM==(packType) || BATCH_DC==(packType) ){
    //				esc.onRequestDisplay(DisplayText.APPROVED);
                    esc.onRequestDisplay(QPOSService.Display.REMOVE_CARD);
							
				    esc.onRequestBatchData(iccData);
                    esc.onRequestTransactionResult(QPOSService.TransactionResult.APPROVED);
				    return;
			    }
		    }
		
		    esc.exit_pos_trade(pos);
            esc.onError(QPOSService.Error.UNKNOWN);
	
	    }
		
	    private bool go_online(String iccData, VPos pos){
		    CommandUplink uc = null;
		    bool f = false;
		    //在线交易
		    setEmvTradeState(EmvTradeState.WAITING);
		    esc.onRequestOnlineProcess(iccData);
		    while(getEmvTradeState()==EmvTradeState.WAITING){
                //System.Threading.Thread.Sleep(SLEEPTIME);
                TaskSleeper.TaskSleep(SLEEPTIME);
            }	
		    Tip.d("go online getEmvTradeState() = "+getEmvTradeState());
		    setEmvTradeState(EmvTradeState.WAITING);
		    //8A023030
		    String s = getEmvGoOnLineData();
		    byte[] paras = Util.HexStringToByteArray(s);
		    int plen = paras.Length;
		    Tip.d("plen"+plen);

		    uc = EMVGoOnLine(pos,s);
		    f = esc.checkCmdId(uc);
		    if(!f){
			    return true;
		    }
				
		    Dictionary<String, String> hashtable = analysisEmvResult(uc.getBytes(0, uc.length()));
		    String transResult = hashtable[("transResult")];
		    String packType = hashtable[("packType")];
		    String issScriptRes = hashtable[("issScriptRes")];
		    String forceAccept = hashtable[("forceAccept")];
		    iccData = hashtable[("iccData")];
		
		    if (EMV_TRANS_ACCEPT==(transResult)) {
			    if (REVERSAL==(packType)){
    //				esc.onRequestDisplay(DisplayText.DECLINED);
                    esc.onRequestDisplay(QPOSService.Display.REMOVE_CARD);
							
				    esc.onReturnReversalData(iccData);
                    esc.onRequestTransactionResult(QPOSService.TransactionResult.DECLINED);
				    return true;
			    }else  if(FINA_CONFIRM==(packType) || BATCH_DC==(packType) ){
    //				esc.onRequestDisplay(DisplayText.APPROVED);
                    esc.onRequestDisplay(QPOSService.Display.REMOVE_CARD);
							
				    esc.onRequestBatchData(iccData);
                    esc.onRequestTransactionResult(QPOSService.TransactionResult.APPROVED);
				    return true;
			    }
		    }else if (EMV_TRANS_DENIAL==(transResult)) {
			    if(ONLINE_ADVICE==(packType) || OFFLINE_ADVICE==(packType)){
    //				esc.onRequestDisplay(DisplayText.DECLINED);
                    esc.onRequestDisplay(QPOSService.Display.REMOVE_CARD);
				
				    esc.onRequestBatchData(iccData);
                    esc.onRequestTransactionResult(QPOSService.TransactionResult.DECLINED);
				    return true;
			    }else if (REVERSAL==(packType)){
    //				esc.onRequestDisplay(Display.DECLINED);
                    esc.onRequestDisplay(QPOSService.Display.REMOVE_CARD);
							
				    esc.onReturnReversalData(iccData);
                    esc.onRequestTransactionResult(QPOSService.TransactionResult.DECLINED);
				    return true;
			    }
			
		    }
		
		
		    return false;
	    }
		private int encMode = 0;
	    private Dictionary<String, String> analysisEmvResult(byte[] emvResult){
    //		Tip.i("analysisEmvResult: "+Util.byteArray2Hex(emvResult));
            Dictionary<String, String> hashtable = new Dictionary<String, String>();
		
		    int index = 0;
		
		    index ++;//两个预留
            encMode = emvResult[index++];//加密模式
		
		    String transResult = Util.byteArray2Hex(new byte[]{emvResult[index++]});
		
		    String packType = Util.byteArray2Hex(new byte[]{emvResult[index++]});
		
		    int issScriptResLen = Util.byteArrayToInt(new byte[]{emvResult[index++]});
		    byte[] arrs = new byte[issScriptResLen];
		    Array.Copy(emvResult, index, arrs, 0, issScriptResLen);
		    String issScriptRes = Util.byteArray2Hex(arrs);
		    index += issScriptResLen;
		
		    int forceAcceptLen = emvResult[index++];
		    arrs = new byte[forceAcceptLen];
            Array.Copy(emvResult, index, arrs, 0, forceAcceptLen);
		    String forceAccept = Util.byteArray2Hex(arrs);
		    index += forceAcceptLen;
		
		    int iccDataLen = Util.byteArrayToInt(new byte[]{emvResult[index],emvResult[index+1]});
		    index += 2;
		    arrs = new byte[iccDataLen];
            Array.Copy(emvResult, index, arrs, 0, iccDataLen);
		    String iccData = Util.byteArray2Hex(arrs);
		    index += iccDataLen;
		
		    String qfData = "";
		
		    if (index < emvResult.Length) {
			    arrs  = Util.IntToHex(iccDataLen);
			
			    String str = Util.byteArray2Hex(arrs);
			    if(str.Length==2){
				    str = "00" + str;
			    }
			
			    iccData = str + iccData;
			    int qfDataLen = emvResult.Length-index;
			    arrs = new byte[qfDataLen];
                Array.Copy(emvResult, index, arrs, 0, qfDataLen);
			    qfData = Util.byteArray2Hex(arrs);
			    index += iccDataLen;
		    }
		
		    iccData += qfData;
		
		    hashtable.Add("transResult", transResult);
            hashtable.Add("packType", packType);
            hashtable.Add("issScriptRes", issScriptRes);
            hashtable.Add("forceAccept", forceAccept);
            hashtable.Add("iccData", iccData);
		    Tip.i("---------------");
		    return hashtable;
	    }
	public Dictionary<String, String> anlysData(bool f, String tlv)
        {
            Dictionary<String, String> hashtable = new Dictionary<String, String>();
            Tip.d("ONLINE data: " + tlv);

            Tip.d("Hashtable-anlysData:" + encMode);
            if (encMode == 0x00 || encMode == 0x10 || encMode == 0x26 || encMode == 0x30)
            {
                hashtable.Add("tlv", tlv);
                return hashtable;
            }
            else if (encMode == 0x20)
            {
                return Util.anlysData_hh(tlv);
            }
            else if (encMode == 0x11)
            {
                return Util.anlysData_qf(tlv);
            }
            else if (encMode == 0x17)
            {
                return Util.anlysData_lp(tlv);
            }
            //		else if (encMode==0x14 || encMode==0x13) {
            //			return Util.anlysData_zl(tlv);
            //		}
            byte[] uc = Util.HexStringToByteArray(tlv);
            int countLen = uc.Length;

            int index = 0;
            int iccdataLen = Util.byteArrayToInt(new byte[] { uc[index], uc[index + 1] });
            index += 2;

            byte[] iccdataarrs = new byte[iccdataLen];
            Array.Copy(uc, index, iccdataarrs, 0, iccdataLen);
            String iccdata = Util.byteArray2Hex(iccdataarrs);
            index += iccdataLen;
            if (index >= countLen)
            {
                hashtable.Add("iccdata", iccdata);
                return hashtable;
            }

            index += 2; //card type
            int encTrack1Len = uc[index++];
            byte[] arrs = new byte[encTrack1Len];
            Array.Copy(uc, index, arrs, 0, encTrack1Len);
            String encTrack1 = Util.byteArray2Hex(arrs);
            index += encTrack1Len;

            int encTrack2Len = uc[index++];
            arrs = new byte[encTrack2Len];
            Array.Copy(uc, index, arrs, 0, encTrack2Len);
            String encTrack2 = Util.byteArray2Hex(arrs);
            index += encTrack2Len;

            int encTrack3Len = uc[index++];
            arrs = new byte[encTrack3Len];
            Array.Copy(uc, index, arrs, 0, encTrack3Len);
            String encTrack3 = Util.byteArray2Hex(arrs);
            index += encTrack3Len;

            int formatIDLen = uc[index++];
            arrs = new byte[formatIDLen];
            Array.Copy(uc, index, arrs, 0, formatIDLen);
            String formatID = System.Text.Encoding.UTF8.GetString(arrs);
            index += formatIDLen;

            int maskedPANLen = uc[index++];
            arrs = new byte[maskedPANLen];
            Array.Copy(uc, index, arrs, 0, maskedPANLen);
            String maskedPAN = System.Text.Encoding.UTF8.GetString(arrs);
            index += maskedPANLen;

            int expiryDateLen = uc[index++];
            arrs = new byte[expiryDateLen];
            Array.Copy(uc, index, arrs, 0, expiryDateLen);
            String expiryDate = System.Text.Encoding.UTF8.GetString(arrs);
            index += expiryDateLen;

            int serviceCodeLen = uc[index++];
            arrs = new byte[serviceCodeLen];
            Array.Copy(uc, index, arrs, 0, serviceCodeLen);
            String serviceCode = System.Text.Encoding.UTF8.GetString(arrs);
            index += serviceCodeLen;

            int cardHolderNameLen = uc[index++];
            arrs = new byte[cardHolderNameLen];
            Array.Copy(uc, index, arrs, 0, cardHolderNameLen);
            String cardholderName = System.Text.Encoding.UTF8.GetString(arrs);
            index += cardHolderNameLen;

            int pinBlockLen = uc[index++];
            arrs = new byte[pinBlockLen];
            Array.Copy(uc, index, arrs, 0, pinBlockLen);
            String pinBlock = Util.byteArray2Hex(arrs);
            index += pinBlockLen;

            int trackksnLen = uc[index++];
            arrs = new byte[trackksnLen];
            Array.Copy(uc, index, arrs, 0, trackksnLen);
            String trackksn = Util.byteArray2Hex(arrs);
            index += trackksnLen;

            int pinKsnLen = uc[index++];
            arrs = new byte[pinKsnLen];
            Array.Copy(uc, index, arrs, 0, pinKsnLen);
            String pinKsn = Util.byteArray2Hex(arrs);
            index += pinKsnLen;

            String trackRandomNumber = "";
            String pinRandomNumber = "";
            if (index < countLen)
            {
                int trackRandomNumberLen = uc[index++];
                arrs = new byte[trackRandomNumberLen];
                Array.Copy(uc, index, arrs, 0, trackRandomNumberLen);
                trackRandomNumber = Util.byteArray2Hex(arrs);
                index += trackRandomNumberLen;
            }

            if (index < countLen)
            {
                int pinRandomNumberLen = uc[index++];
                arrs = new byte[pinRandomNumberLen];
                Array.Copy(uc, index, arrs, 0, pinRandomNumberLen);
                pinRandomNumber = Util.byteArray2Hex(arrs);
                index += pinRandomNumberLen;
            }
            String psamNo = "";

            if (index < countLen)
            {
                int psamNoLen = uc[index++];//psam编号
                arrs = new byte[psamNoLen];
                Array.Copy(uc, index, arrs, 0, psamNoLen);
                psamNo = System.Text.Encoding.UTF8.GetString(arrs);
                index += psamNoLen;
            }
            String track1Length = "";
            String track2Length = "";
            String track3Length = "";
            if (index < countLen)
            {
                int t1Len = uc[index++];//磁道1原始数据长度
                int t2Len = uc[index++];//磁道2原始数据长度
                int t3Len = uc[index++];//磁道3原始数据长度

                track1Length = t1Len + "";
                track2Length = t2Len + "";
                track3Length = t3Len + "";
            }

            String encPAN = "";
            if (index < countLen)
            {//VIPOS 增加卡号密文
                int encPANLen = uc[index++];
                arrs = new byte[encPANLen];
                Array.Copy(uc, index, arrs, 0, encPANLen);
                encPAN = Util.byteArray2Hex(arrs);
                index += encPANLen;
            }

            String cardSquNo = "";
            String iccCardAppexpiryDate = "";
            if (index < countLen)
            {
                int cardSquNoLen = uc[index++];
                byte[] cardSquNoArrs = new byte[cardSquNoLen];
                Array.Copy(uc, index, cardSquNoArrs, 0, cardSquNoLen);
                cardSquNo = Util.byteArray2Hex(cardSquNoArrs);
                index += cardSquNoLen;
            }
            if (index < countLen)
            {
                int iccCardAppexpiryDateLen = uc[index++];
                byte[] iccCardAppexpiryDateArrs = new byte[iccCardAppexpiryDateLen];
                Array.Copy(uc, index, iccCardAppexpiryDateArrs, 0, iccCardAppexpiryDateLen);
                iccCardAppexpiryDate = Util.byteArray2Hex(iccCardAppexpiryDateArrs);
                index += iccCardAppexpiryDateLen;
            }
            //		
            if (f)
            {
                if (index < countLen)
                {//
                    int obuflen = countLen - index;
                    byte[] obuf = new byte[obuflen];
                    Array.Copy(uc, index, obuf, 0, obuflen);
                    index += obuflen;
                    //Dictionary<String, String> resHash = Util.anlysPaddingCommonData(encMode, obuf);
                    //myPosid = resHash.get("posID");
                    //				hashtable.put("posID", resHash.get("posID"));
                }
                else
                {
                   // myPosid = "";
                }
            }

            //		Tip.d(">>index = "+index);
            hashtable.Add("posID", "");
            if (iccCardAppexpiryDate != null && !"".Equals(iccCardAppexpiryDate) && iccCardAppexpiryDate.Length >= 12)
            {
                //			5F2403250731
                expiryDate = iccCardAppexpiryDate.Substring(6, 12);
            }
            else
            {
                expiryDate = iccCardAppexpiryDate;
            }
            //		expiryDate = iccCardAppexpiryDate;
            String encTracks = encTrack2 + encTrack3;
            hashtable.Add("formatID", formatID);
            hashtable.Add("maskedPAN", maskedPAN);
            hashtable.Add("expiryDate", expiryDate);
            hashtable.Add("cardholderName", cardholderName);
            hashtable.Add("serviceCode", serviceCode);
            hashtable.Add("track1Length", track1Length.Trim());
            hashtable.Add("track2Length", track2Length.Trim());
            hashtable.Add("track3Length", track3Length.Trim());
            hashtable.Add("encTracks", encTracks.Trim());
            hashtable.Add("encTrack1", encTrack1);
            hashtable.Add("encTrack2", encTrack2);
            hashtable.Add("encTrack3", encTrack3);
            hashtable.Add("pinBlock", pinBlock);
            hashtable.Add("trackRandomNumber", trackRandomNumber);
            hashtable.Add("pinRandomNumber", pinRandomNumber);
            hashtable.Add("psamNo", psamNo);
            hashtable.Add("encPAN", encPAN);
            hashtable.Add("iccdata", iccdata);
            hashtable.Add("cardSquNo", cardSquNo);
            hashtable.Add("iccCardAppexpiryDate", iccCardAppexpiryDate);
            hashtable.Add("trackksn", trackksn);
            hashtable.Add("pinKsn", pinKsn);
            //		Tip.i("--: "+hashtable.toString());
            return hashtable;
        }

	
	    private String doReturnData(CommandUplink uc){
		
		    String str = Util.byteArray2Hex(uc.getBytes(1, uc.length()-1));
		    return str;
		
	    }
	
	
	 
	
	    private CommandUplink EMVStart(VPos pos,QPOSService.EmvOption emvOp,String tradeType,String terminalTime,String tradeAmount, String currencyCode){
		    CommandDownlink dc = null;
		    CommandUplink uc = null;
		    Tip.i("EMVStart>> tradeAmount: "+tradeAmount);
		    byte[] paras = new byte[14+2+2];
		    int index = 0;

            if (emvOp == QPOSService.EmvOption.START)
            {
			    paras[index++] = 0;
            }
            else if (emvOp == QPOSService.EmvOption.START_WITH_FORCE_ONLINE)
            {
			    paras[index++] = 1;
		    }
		    paras[index++] = Util.HexStringToByteArray(tradeType)[0];
		
		    byte[] timearr = Util.HexStringToByteArray(terminalTime+"FF");
		    Array.Copy(timearr, 0, paras, index, timearr.Length);
		    index += timearr.Length;
		
		    String str = "FFFFFFFF";
		
		    int len = 0;
            if (tradeAmount != null && tradeAmount != "")
            {
                len = tradeAmount.Length;
		    }
		    str =str.Substring(0,str.Length - len) + tradeAmount;
    //		Tip.i("EMVStart>> str: "+str);
		
		    timearr = Util.HexStringToByteArray(str);
		    Array.Copy(timearr, 0, paras, index, timearr.Length);
		    index += timearr.Length;
		
		    str = "0000";
		    if(currencyCode.Length==3){
			    currencyCode = "0"+ currencyCode;
		    }		
		    str += currencyCode;
		    timearr = Util.HexStringToByteArray(str);
		    Array.Copy(timearr, 0, paras, index, timearr.Length);
		    index += timearr.Length;
		
		    Tip.i("EMVStart>> str: "+Util.byteArray2Hex(paras));
		
		    dc = new CommandDownlink(0x16, 0x30, 60,paras);
		    pos.sendCommand(dc);
		    uc = pos.receiveCommandWaitResult(10);
            //Tip.d("1630----:" + Util.byteArray2Hex(uc.getBytes(0, uc.length())));

            return uc;
	    }
	
	    private CommandUplink EMVStart(VPos pos){
		    CommandDownlink dc = null;
		    CommandUplink uc = null;
		
		    byte[] paras = new byte[1];
		
		    if(esc.getEmvOption()==QPOSService.EmvOption.START){
			    paras[0] = 0;
            }
            else if (esc.getEmvOption() == QPOSService.EmvOption.START_WITH_FORCE_ONLINE)
            {
			    paras[0] = 1;
		    }
		
		    dc = new CommandDownlink(0x16, 0x30, 60,paras);
		    pos.sendCommand(dc);
		    uc = pos.receiveCommandWaitResult(60);
		
		    return uc;
	    }
	
	    private CommandUplink EMVGoOnLine(VPos pos,String paras){
		    CommandDownlink dc = null;
		    CommandUplink uc = null;
		
		    dc = new CommandDownlink(0x16, 0x40, 30,Util.HexStringToByteArray(paras));
		    pos.sendCommand(dc);
		    uc = pos.receiveCommandWaitResult(30);
            //Thread.CurrentThread.Join();
		    return uc;
	    }


        private CommandUplink EMVSelectEMVApp(VPos pos, int index)
        {
		    CommandDownlink dc = null;
		    CommandUplink uc = null;
		
		    dc = new CommandDownlink(0x16, 0x31, 60,new byte[]{(byte) index});
		    pos.sendCommand(dc);
		    uc = pos.receiveCommandWaitResult(60);
		
		    return uc;
	    }


        private CommandUplink EMVSetEmvPin(VPos pos, String pinMode, String pin)
        {
		    CommandDownlink dc = null;
		    CommandUplink uc = null;
		
		    byte[] pinArrs = new byte[0];
		
		    int pinLen = 0;
		    if("" == pin || pin == null){
			    pinLen  = 0;
		    }else {
                pinArrs = System.Text.Encoding.UTF8.GetBytes(pin);
			    pinLen = pinArrs.Length;
    //			Tip.d("pin ascii :" + Util.byteArray2Hex(pinArrs));
		    }
		    //TODO DEBUG S
            pin = Util.byteArray2Hex(System.Text.Encoding.UTF8.GetBytes(pin)) + "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF";
		
		    pin = pin.Substring(0, 32);
    //		Tip.d("pin :"+pin);
		
		    byte[] pin_key = Util.HexStringToByteArray(pin);
		
		    byte[] en_pin = DES.encrypt(pin_key, pin_key);
    //		Tip.d("en_pin :"+Util.byteArray2Hex(en_pin));
		
		    //DEBUG E
		
		    String str = pinMode + Util.byteArray2Hex(Util.IntToHex(pinLen)) + Util.byteArray2Hex(pinArrs);
		
		    dc = new CommandDownlink(0x16, 0x32, 60,Util.HexStringToByteArray(str));
		    pos.sendCommand(dc);
		    uc = pos.receiveCommandWaitResult(60);
		
		    return uc;
	    }
	
	

	    private CommandUplink EMVInitSession(VPos pos,String tradeAmount,String terminalTime){
		    CommandDownlink dc = null;
		    CommandUplink uc = null;
		    String str = "FFFFFFFF";
		    byte[] paras = new byte[0];			
		    int len = tradeAmount.Length;
    //		str = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date())+str.substring(0,str.length() - len) + tradeAmount;
    //		Tip.d("terminalTime  2222222    :"+terminalTime);
		    str = terminalTime+"FF"+str.Substring(0,str.Length - len) + tradeAmount;
		    Tip.d("EMVInitSession=================arg : "+str);
		    paras = Util.HexStringToByteArray(str);
		    dc = new CommandDownlink(0x16, 0x00, 10, paras);
		    pos.sendCommand(dc);
		    uc = pos.receiveCommandWaitResult(10);
		    return uc;
	    }
	
	    private CommandUplink EMVSelectTradeType(VPos pos,String tradeType){
		    CommandDownlink dc = null;
		    CommandUplink uc = null;
		    String str = "";
		    byte[] paras = new byte[0];
		    Tip.d("tradeType : "+tradeType);
    //		str = "0"+tradeType;
		    paras = Util.HexStringToByteArray(tradeType);
		    dc = new CommandDownlink(0x16, 0x10, 10, paras);
		    pos.sendCommand(dc);
		    uc = pos.receiveCommandWaitResult(10);
		    return uc;
	    }

        public void doGetIccEmvData(VPos pos, String FunType, String transTime)
        {
            esc.onRequestWaitingUser();

            String transType = "05";
            CommandDownlink dc = null;
            CommandUplink uc = null;

            transTime = transTime + "FF";
            String lenString = Util.byteArray2Hex(Util.IntToHex(transTime.Length));

            byte[] paras = Util.HexStringToByteArray(FunType + transType + lenString + transTime);
            dc = new CommandDownlink(0x16, 0xb0, 30, paras);
            pos.sendCommand(dc);
            uc = pos.receiveCommandWaitResult(30);
            bool f = esc.checkCmdId(uc);
            if (!f) return;
            Tip.d("uc len: " + uc.length());
            if (uc.length() == 0)
            {
                esc.onRequestDisplay(QPOSService.Display.PLEASE_WAIT);
                dc = new CommandDownlink(CmdId.CMDID_QUERY, 0, 0, 30);
                pos.sendCommand(dc);
                uc = pos.receiveCommandWaitResult(30);
                f = esc.checkCmdId(uc);
                if (!f)
                {
                    return;
                }
            }


            while (uc.result() == 0x02)
            {
                Tip.d("select emv app");

                List<String> appList = new List<String>();
                int allLen = uc.length();
                Tip.d("alllen = " + allLen);
                int index = 0;
                int appCount = uc.getByte(index++);
                Tip.d("appCount = " + appCount);

                for (int i = 0; i < appCount; i++)
                {
                    index++;
                    index++;
                    int app1Len = uc.getByte(index++);
                    byte[] btmp = uc.getBytes(index, app1Len);
                    String app1 = System.Text.Encoding.UTF8.GetString(btmp, 0, btmp.Length);
                    index += app1Len;
                    appList.Insert(i, app1);
                }

                setEmvTradeState(EmvTradeState.WAITING);
                esc.onRequestSelectEmvApp(appList);
                while (getEmvTradeState() == EmvTradeState.WAITING)
                {
                    //System.Threading.Thread.Sleep(SLEEPTIME);                    
                    TaskSleeper.TaskSleep(SLEEPTIME);
                }
                Tip.d("select emv app getEmvTradeState()= " + getEmvTradeState());

                setEmvTradeState(EmvTradeState.WAITING);
                if (!esc.isTradeFlag())
                {
                    return;
                }
                uc = EMVSelectEMVApp(pos, esc.getSelectEmvAppIndex());
                f = esc.checkCmdId(uc);
                if (!f)
                {
                    return;
                }

            }

            if (FunType == ("01"))
            {
                byte[] btmp = uc.getBytes(0, uc.length());
                String cardNoStr = System.Text.Encoding.UTF8.GetString(btmp, 0, btmp.Length);
                Tip.d("cardNoStr : " + cardNoStr);
                esc.onGetCardNoResult(cardNoStr);
            }
            else if (FunType==("02"))
            {
                Tip.d("ss: " + Util.byteArray2Hex(uc.getBytes(0, uc.length())));
                int index = 0;
                int serviceCodeLen = uc.getByte(index++);
                String serviceCode = System.Text.Encoding.UTF8.GetString(uc.getBytes(index, serviceCodeLen));
                index += serviceCodeLen;

                int trackblockLen = Util.byteArrayToInt(new byte[] { uc.getByte(index++) });
                String trackblock = Util.byteArray2Hex(uc.getBytes(index - 1, trackblockLen + 1));
                index += trackblockLen;

                Hashtable hashtable = new Hashtable();
                hashtable.Add("serviceCode", serviceCode);
                hashtable.Add("trackblock", trackblock);
                esc.onReturniccCashBack(hashtable);
                //			String str = Util.byteArray2Hex(uc.getBytes(0, uc.length()));	
                //			esc.onRequestBatchData(str);
            }
            else
            {
                String str = Util.byteArray2Hex(uc.getBytes(0, uc.length()));
                //			esc.onRequestDisplay(Display.REMOVE_CARD);
                esc.onRequestBatchData(str);
                //			esc.onRequestTransactionResult(TransactionResult.APPROVED);
            }
        }
    }
}
