﻿using System;
using System.Threading.Tasks;

namespace SDK_LIB
{
    /// <summary>
    /// VPos class implements a collection of methods and attributes that helps to abstract the VPos hardware.
    /// This is the base class for VPos, some of the methods are defined as abstract method which will be implemented
    /// depends on which connection method will be used.
    /// </summary>
    public abstract class VPos : IDisposable
    {
        /// <summary>
        /// Private Boolean flag to indicate if packet successfully received with no error.
        /// </summary>
        private bool receivePacketOk = false;

        /// <summary>
        /// Private Boolean flag to indicate if CRC error occured
        /// </summary>
        private bool crcError = false;

        /// <summary>
        /// Private Boolean flag to indicate if the device needs to quit/reset current operation
        /// </summary>
        private bool needQuit = false;

        /// <summary>
        /// Timeout interval value
        /// </summary>
        private int timeout = 10;

        /// <summary>
        /// Private field to store an instance of Packet object
        /// </summary>
        private Packet p = null;

        /// <summary>
        /// Reset current VPos Instance status.
        /// </summary>
        private void clear()
        {
            setNeedQuit(false);
            p = null;
            setCrcError(false);
            receivePacketOk = false;
        }

        /// <summary>
        /// Method to return CRC Error flag status
        /// </summary>
        /// <returns>Boolean value for CRC Error status</returns>
        public bool isCrcError()
        {
            return crcError;
        }

        /// <summary>
        /// Set the CRC Error Flag
        /// </summary>
        /// <param name="crcError">Value of the flag</param>
        public void setCrcError(bool crcError)
        {
            this.crcError = crcError;
        }

        /// <summary>
        /// Return timeout value
        /// </summary>
        /// <returns>Timeout value</returns>
        public int getTimeout()
        {
            return timeout;
        }

        /// <summary>
        /// Set timeout value
        /// </summary>
        /// <param name="timeout">Timeout value to be set</param>
        public void setTimeout(int timeout)
        {
            this.timeout = timeout;
        }

        /// <summary>
        /// Return needQuit flag status.
        /// </summary>
        /// <returns>Boolean value of the needQuit flag</returns>
        public bool isNeedQuit()
        {
            return needQuit;
        }

        /// <summary>
        /// Set needQuit flag
        /// </summary>
        /// <param name="needQuit">Boolean value to be set</param>
        public void setNeedQuit(bool needQuit)
        {
            this.needQuit = needQuit;
        }


        /***********************Abstract methods below*********************************************/

        /// <summary>
        /// Pos open device operation.
        /// </summary>
        /// <returns>Boolean value to indicate if operation is successful</returns>
        public abstract bool open();

        /// <summary>
        /// Pos close device operation.
        /// </summary>
        /// <returns>Boolean value to indicate if operation is successful</returns>
        public abstract void close();

        /// <summary>
        /// Pos device read operation.
        /// </summary>
        /// <returns>Boolean value to indicate if operation is successful</returns>
        public abstract byte[] read();

        /// <summary>
        /// Pos device write operation.
        /// </summary>
        /// <param name="msgArr">Array of bytes to be written to the device</param>
        /// <returns>Boolean value to indicate if operation is successful</returns>
        public abstract void write(byte[] msgArr);

        /// <summary>
        /// Pos device disconnect operation.
        /// Newly added abstract method to handle socket disposal for BTD.
        /// </summary>
        /// <returns>Boolean value to indicate if operation is successful</returns>
        public abstract void disconnect(); 

        /// <summary>
        /// IDisposeable Interface member method, required by the interface.
        /// Dispose current VPos instance
        /// </summary>
        /// <returns>Boolean value to indicate if operation is successful</returns>
        public abstract void Dispose();

        /*************************public methods**************************************************/

        /// <summary>
        /// Method to read the device response and pack the data into Packets
        /// </summary>
        /// <returns>Packet object that contains the received response data</returns>
        private Packet receivePacket()
        {
            byte[] b = read();
            Packet p = new Packet(b);
            return p;
        }

        /// <summary>
        /// Method to call the private write() method to send array of bytes to device
        /// </summary>
        /// <param name="b">Data Bytes array</param>
        public void sendRawPacket(byte[] b)
        {            
            write(b);
        }

        /// <summary>
        /// Method to send the raw data bytes in a new downlink command (Command issued to the device)
        /// </summary>
        /// <param name="dc">Downlink command object</param>
        public void sendCommand(CommandDownlink dc)
        {
            sendRawPacket(dc.getBytes());
        }

        /// <summary>
        /// Method that wrap around the receivePacket() method with the ability to set the receivePacketOK global flag.
        /// (Kinda redundent, may be used for debugging purpose)
        /// </summary>
        private void receivePacketRun()
        {
            p = receivePacket();
            receivePacketOk = true;
        }

        /// <summary>
        /// Method to read device response after a device command is issued.
        /// </summary>
        /// <param name="delay">Amount of time to wait before start reading device reponse</param>
        /// <returns></returns>
        public CommandUplink receiveCommand(int delay)
        {
            CommandUplink uc = null;
            clear();
            /*
            Thread thread = new Thread(new ThreadStart(receivePacketRun));
            thread.Start();
            */
            Task tk = Task.Run(() =>
            {
                receivePacketRun();
            });

            // Timeout mechanism, if read operation times out, then device will be issued to reset.
            int tie = delay * 5000;
            while (!receivePacketOk)
            {
                tie -= 100;
                sleepMs(100);
                if (tie == 0 || isNeedQuit())
                {
                    setNeedQuit(true);
                    tk.Wait();
                    /*
                    thread.Abort();
                    thread.Join();                    
                    */
                    return uc;
                }
            }

            // Return the empty command response if received packet is not valid (i.e. packet is null and data length is 0)
            if (p == null || p.getBytes().Length == 0)
            {
                return uc;
            }

            // Validate the received packet and return the command response
            if (p.validCRC())
            {
                uc = new CommandUplink(p);
                setCrcError(false);
            }
            else
            {
                Tip.d("Vpos: read packet crc error");
                setCrcError(true);
            }
            return uc;
        }

        /// <summary>
        /// Method to receive long command response which requires data to be received via several batches.
        /// </summary>
        /// <param name="delay">Amount of time delayed before start to receive command response</param>
        /// <returns>CommandUplink object</returns>
        public CommandUplink receiveCommandWaitResult(int delay)
        {
            CommandUplink uc = null;

            uc = receiveCommand(delay + 5);

            if (uc == null)
            {
                return uc;
            }

            setNeedQuit(false);
            int tie = (delay + 5) * 1000;
            while (uc.commandID() == CmdId.CMDID_WAITING)
            {
                tie -= 1;
                sleepMs(1);
                if (tie == 0)
                {
                    uc = null;
                    break;
                }

                if (isNeedQuit())
                {
                    uc = null;
                    break;
                }
                //Tip.d("cmd code["+util.getHexString(new byte[]{uc.commandCode()})+"]"+",sub cmd code["+util.getHexString(new byte[]{uc.subCommandCode()})+"]");
                CommandDownlink dc = new CommandDownlink(CmdId.CMDID_QUERY, 0, 0, 15); // Send command to check the latest device execution status
                sendCommand(dc);
                uc = null;
                uc = receiveCommand(15 + 5);

                if (uc == null)
                {
                    break;
                }
            }

            //TODO debug xlh s
            // If received command response has command ID 0x36, indicate the received response is only partial of the full response
            if (uc != null && uc.commandID() == CmdId.CMDID_PART_DATA)
            {
                int comdCode = uc.commandCode();
                int comdSubCode = uc.subCommandCode();
                // Form new data byte array as buffer, copy received data bytes within the command response object
                byte[] paras = new byte[2048 * 10];
                int index = 0;
                Array.Copy(uc.getBytes(0, uc.length()), 0, paras, index, uc.length());
                index += uc.length();
                Tip.d("Vpos: read>>: " + Util.byteArray2Hex(uc.getBytes(0, uc.length())));
                tie = 15 * 1000;

                // Keep inquiring more data to be sent back from the device
                // Additional data received will be added to the data buffer
                while (uc.commandID() == CmdId.CMDID_PART_DATA)
                {
                    tie -= 1;
                    sleepMs(1);
                    if (tie == 0)
                    {
                        uc = null;
                        break;
                    }

                    if (isNeedQuit())
                    {
                        uc = null;
                        break;
                    }

                    CommandDownlink dc = new CommandDownlink(CmdId.CMDID_PART_DATA, 0, 0, 15);
                    sendCommand(dc);
                    uc = null;
                    uc = receiveCommand(15 + 5);

                    if (uc == null)
                    {
                        break;
                    }

                    Array.Copy(uc.getBytes(0, uc.length()), 0, paras, index, uc.length());
                    index += uc.length();

                }

                // Construct CommandUplink object with completely received buffered data.
                if (uc != null)
                {
                    byte[] ss = new byte[index];
                    Array.Copy(paras, 0, ss, 0, index);
                    p = new Packet(paras.Length);
                    p.setCmdID((byte)CmdId.CMDID_COMPLETED);
                    p.setCmdCode((byte)comdCode);
                    p.setCmdSubCode((byte)comdSubCode);
                    p.setTimeOut((byte)15);
                    p.setDataField(ss);
                    p.buildCRC();
                    uc = new CommandUplink(p);
                }
            }
            Tip.d("1630----:" + Util.byteArray2Hex(uc.getBytes(0, uc.length())));
            //debug xlh e  
            Tip.d("exiet start emv-------------------------");          
            return uc;
        }

        /// <summary>
        /// Method to put current task into sleep (Create a delay task)
        /// </summary>
        /// <param name="msec">Milisecond value for the amount of time delay</param>
        private static void sleepMs(int msec)
        {
            //Thread.Sleep(msec);
            TaskSleeper.TaskSleep(msec);
        }
    }
}
