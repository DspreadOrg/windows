﻿using System;
using System.Threading.Tasks;
using Windows.Networking.Sockets;
using Windows.Networking.Proximity;
using Windows.Storage.Streams;
using Windows.Devices.Bluetooth.Rfcomm;

namespace SDK_LIB
{
    /// <summary>
    /// VPosBluetooth class implements a collection of methods and attributes on top of the VPos class for communication via Legacy Bluetooth.
    /// </summary>
    public class VPosBluetooth : VPos
    {
        /// <summary>
        /// Private field to store the VPosBluetooth instance
        /// </summary>
        private static VPosBluetooth g_Instance = null;

        /// <summary>
        /// Empty Byte Array object for thread locking and synchronisation
        /// </summary>
        private static byte[] blk = { };

        /// <summary>
        /// Default CTOR, set to private to avoid using.
        /// </summary>
        private VPosBluetooth()
        {
            disposed = false;
        }

        /// <summary>
        /// Custom CTOR for initialize a new VPosBluetooth Instance
        /// </summary>
        /// <returns>VPosBluetooth object</returns>
        public static VPosBluetooth getInstance()
        {
            lock (blk)
            {
                if (g_Instance == null) g_Instance = new VPosBluetooth();
            }
            //
            return g_Instance;
        }

        /// <summary>
        /// Private Boolean flag to indicate if the Bluetooth Communication is connected and ready to transmit data
        /// </summary>
        private bool isOpen = false;

        /// <summary>
        /// Private Boolean flag to indicate if the data is currently writing into the QPOS device
        /// </summary>
        private bool isWrite = false;

        /// <summary>
        /// Private IInputStream/IOutputStream objects for Stream Reading/Writing control
        /// </summary>
        private IInputStream ins = null;
        private IOutputStream outs = null;

        /// <summary>
        /// RfcommDeviceSerivice Properties used to establish Bluetooth communication via SPP protocol.
        /// </summary>
        private RfcommDeviceService deviceService;
        public RfcommDeviceService DeviceService
        {
            set { deviceService = value; }
        }


        /*public override bool open()
        {
            if (isOpen) {
                return true;
            }

            if (deviceService == null)
            {
                Tip.d("bluetooth address is null");
                return false;
            }

            //
            try {
                socket = new StreamSocket();
                Task<bool> tsk = openInternal();
                while ((!tsk.IsCanceled) && (!tsk.IsCompleted) && (!tsk.IsFaulted))
                {
                    tsk.Wait(10);
                }
                ins = socket.InputStream;
                outs = socket.OutputStream;
                isOpen = true;
                return true;
            } catch (Exception e) {
                close();
                Tip.d("BT open Exception");
            }
            //
            return false;
        }*/

        /// <summary>
        /// Modified version of the open() method. The modified version will check if a valid socket has been connected. If a socket has been
        /// established, then the program will not initiate a new socket and try to connect it (this will cause crash due to only one socket can
        /// be assigned to a specific device).
        /// </summary>
        /// <returns></returns>
        public override bool open()
        {
            if (isOpen)
            {
                return true;
            }

            if (deviceService == null)
            {
                Tip.d("bluetooth address is null");
                return false;
            }

            //
            try
            {
                if(socket == null)
                {
                    socket = new StreamSocket();
                    Task.Delay(100000);
                    Task<bool> tsk = openInternal();
                    while ((!tsk.IsCanceled) && (!tsk.IsCompleted) && (!tsk.IsFaulted))
                    {
                        tsk.Wait(10);
                    }
                }
                ins = socket.InputStream;
                outs = socket.OutputStream;
                isOpen = true;
                return true;
            }
            catch (Exception e)
            {
                close();
                disconnect();
                Tip.d("BT open Exception");
            }
            //
            return false;
        }

        /// <summary>
        /// Core function to establish bluetooth socket connection
        /// </summary>
        /// <returns>Boolean value to indicate if the operation is successful</returns>
        private async Task<bool> openInternal()
        {
            bool bret = true;

            try {
                await socket.ConnectAsync(
                           deviceService.ConnectionHostName,
                        deviceService.ConnectionServiceName,
                        SocketProtectionLevel.BluetoothEncryptionAllowNullAuthentication);
            }
            catch (Exception e)
            {
                bret = false;
                throw;
            }

            return bret;
        }

        /*
        private async Task<bool> openInternal()
        {            
            bool bret = true;
            string serviceName = (String.IsNullOrWhiteSpace(peerinfo.ServiceName)) ? "1" : peerinfo.ServiceName;
            await socket.ConnectAsync(peerinfo.HostName, serviceName);            
            return bret;        
        }
        */

        /*
        public override void close()
        {
            try
            {
                setNeedQuit(true);
                if (socket != null)
                {
                    if (ins != null)
                    {
                        ins.Dispose();
                        ins = null;
                    }
                    if (outs != null)
                    {
                        outs.Dispose();
                        outs = null;
                    }
                    socket.Dispose();
                    socket = null;
                }
                isOpen = false;
            }
            catch (Exception e)
            {
                Tip.d("BT close IOException");	
            }
        }*/

        /// <summary>
        /// Modified version of the close() method for Bluetooth.
        /// The difference to the original version implemented above (Has been commented out)
        /// is that it doesn't dispose the socket and thus maintain socket connection.
        /// If Socket connection is down, the Bluetooth Symbol will not shown on the QPOS Device
        /// </summary>
        public override void close()
        {
            try
            {
                setNeedQuit(true);
                isOpen = false;
            }
            catch (Exception e)
            {
                Tip.d("BT close IOException");
            }
        }

        /// <summary>
        /// The disconnect() Method handles the actual socket disconnection to the Bluetooth Device
        /// </summary>
        public override void disconnect()
        {
            if(socket != null)
            {
                if (ins != null)
                {
                    ins.Dispose();
                    ins = null;
                }
                if (outs != null)
                {
                    outs.Dispose();
                    outs = null;
                }
                socket.Dispose();
                socket = null;
            }
        }

        /// <summary>
        /// Method to read data from device via Legacy Bluetooth
        /// </summary>
        /// <returns>Data bytes array</returns>
        public override byte[] read()
        {
            byte[] b = new byte[0];
            try
            {
                if (!isWrite)
                {
                    Tip.d("VposBluetooth: write error");
                    return b;
                }

                b = readResponse();
                Tip.d("[read:" + Util.byteArray2Hex(b) + "]");
            }
            catch (Exception e)
            {
                b = new byte[0];
                Tip.d("BT read IOException");                
            }
            return b;
        }

        /// <summary>
        /// Method to read the the received data byte by byte with additional data validation.
        /// </summary>
        /// <returns>Bytes array which contains data received from the device. If the received data is invalid, empty array will be returned.</returns>
        private byte[] readResponse()
        {
            byte[] lens = new byte[3];
		    int len = 0;
		    byte[] others = new byte[0];

		    int backLen = 0;
		    for (int i = 0; i < lens.Length;) {
			    if (isNeedQuit()) {
				    return new byte[0];
			    }
			    lens[i] = readInputStream();
			    if (lens[0] == 'M') {
				    i++;
			    }			
		    }
		
		    len = lens[2];
		    if (len < 0) {
			    len = len + 256;
		    }

		    len += lens[1] * 256;

		    backLen = len + 1 + 3;
		    others = new byte[backLen];

		    for (int i = 0; i < len + 1; i++) {
			    if (isNeedQuit()) {
				    return new byte[0];
			    }
			    others[3 + i] = readInputStream();			
		    }

		    Array.Copy(lens, 0, others, 0, 3);
		    return others;
        }

        /// <summary>
        /// Method that wrap around the readInternal() Method with additional operation to reset the device if a read is failed.
        /// </summary>
        /// <returns></returns>
        private byte readInputStream()
        {
		    byte result = 0;

            Task<int> tsk = readInternal();
            while ((!tsk.IsCanceled) && (!tsk.IsCompleted) && (!tsk.IsFaulted))
            {
                tsk.Wait(10);
            }
		    int ret = tsk.Result;
            if (ret == 0x00ff0000)
            {
			    do {				
				    Tip.d("quit read");
				    if (isNeedQuit()) {
					    return result;
				    }
                    tsk = readInternal();
                    while ((!tsk.IsCanceled) && (!tsk.IsCompleted) && (!tsk.IsFaulted))
                    {
                        tsk.Wait(10);
                    }
                    ret = tsk.Result;
                } while (ret == 0x00ff0000);
		    }
		    result = (byte) ret;

		    return result;
	    }

        /// <summary>
        /// The core function to read the data from inputstream using DataReader object
        /// Each time the method is called, one byte of data will be fetched and read from the inputstream.
        /// </summary>
        /// <returns>Integer value to indicate the status of the operation</returns>
        private async Task<int> readInternal()
        {
            int b = (int)(0x00ff0000);
            //DataReader _dataReader = new DataReader(ins);
            DataReader _dataReader = new DataReader(socket.InputStream);
            try
            {
                await _dataReader.LoadAsync(1);
                b = (int)_dataReader.ReadByte();
            }
            catch (Exception e)
            {
                b = (int)(0x00ff0000);
            }
            _dataReader.DetachStream();
            _dataReader.Dispose();
            //
            return b;
        }

        /// <summary>
        /// Core function to perform data writing to the outputstream using DataWriter object.
        /// </summary>
        /// <param name="msgArr">Data Bytes array which will be write to the stream</param>
        /// <returns></returns>
        private async Task<bool> writeInternal(byte[] msgArr)
        {
            //DataWriter _dataWriter = new DataWriter(outs);
            DataWriter _dataWriter = new DataWriter(socket.OutputStream);
            _dataWriter.WriteBytes(msgArr);
            await _dataWriter.StoreAsync();
            await _dataWriter.FlushAsync();
            _dataWriter.DetachStream();
            _dataWriter.Dispose();
            return true;
        }

        /// <summary>
        /// Method to write data to the device via Bluetooth Legacy mode.
        /// </summary>
        /// <param name="msgArr">Array of data bytes which will be written into the device</param>
        public override void write(byte[] msgArr)
        {
            isWrite = false;
            if (!isOpen) return;
            try {
                Task<bool> tsk = writeInternal(msgArr);
                tsk.Wait();
                while ((!tsk.IsCanceled) && (!tsk.IsCompleted) && (!tsk.IsFaulted))
                {
                    tsk.Wait(10);
                }
			    isWrite = true;
			    Tip.d("[write:" + Util.byteArray2Hex(msgArr)+"]");
		    } catch (Exception e) {
			    Tip.d("BT write IOException");			    
		    }
        }

        /// <summary>
        /// Private Boolean flag to indicate if the current VPosBluetooth instance has been disposed.
        /// </summary>
        private bool disposed;

        /// <summary>
        /// Dispose() Method to dispose the current VPosBluetooth instance.
        /// </summary>
        public override void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Custom dispose method for disposing the current VPosBluetooth instance.
        /// </summary>
        /// <param name="disposing">Boolean flag to enable complete disposing of the resource rather than just reset the disposed flag</param>
        private void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    close();
                    disconnect();         
                    g_Instance = null;
                }
                disposed = true;
            }
        }

        /// <summary>
        /// Class DTOR
        /// </summary>
        ~VPosBluetooth()
        {
            Dispose(false);
        }

        /// <summary>
        /// Private string field to store the Bluetooth Device address. For QPOS device, it would be the device serial number.
        /// </summary>
        private String blueToothAddress = "";
        /// <summary>
        /// Bluetooth Address field getter
        /// </summary>
        /// <returns>String of Bluetooth Device address. It is the device serial number for QPOS device</returns>
        public String getBlueToothAddress()
        {
            return blueToothAddress;
        }

        /// <summary>
        /// Method to assign external RfcommDeviceService object to the internal object within the class.
        /// This is crucial to provide data communication control to the device via Bluetooth SPP.
        /// </summary>
        /// <param name="deviceService">External RfcommDeviceService Object</param>
        public void setBlueToothAddress(RfcommDeviceService deviceService)
        {

            if (deviceService == null){
                return;
            }

            this.deviceService = deviceService;

        }

        /// <summary>
        /// Private field to store the socket object which will be used to control socket communication
        /// </summary>
        private StreamSocket socket = null;

        /// <summary>
        /// Private field to store the PeerInformation object.
        /// </summary>
        private PeerInformation peerinfo = null;

        /*
        private async Task<bool> setBlueToothAddressInternal(String blueToothAddress)
        {
            /*
            bool flag;
            this.blueToothAddress = blueToothAddress;
            if (this.blueToothAddress == null || this.blueToothAddress == "")
            {
                close();
                //
                peerinfo = null;
                deviceService = null;                
            }

            Task<bool> tk = scanBTD(blueToothAddress);
            flag =  await tk;
            //tk.Wait();
            //flag = await tk;
    //        if (flag == false)
            {
                System.Diagnostics.Debug.WriteLine("No devices were found.");
            }
            */
        /*          
    //  return true;
  }
  */

        /*
        private async Task<bool> setBlueToothAddressInternal(String blueToothAddress)
        {
            
            this.blueToothAddress = blueToothAddress;
            if (this.blueToothAddress == null || this.blueToothAddress == "")
            {
                close();
                //
                peerinfo = null;
            }
            //
            PeerFinder.AlternateIdentities["Bluetooth:Paired"] = "";
            var pairedDevices = await PeerFinder.FindAllPeersAsync();

            if (pairedDevices.Count == 0)
            {
                System.Diagnostics.Debug.WriteLine("No paired devices were found.");
            }
            else
            {
                IEnumerable<PeerInformation> items = (from c in pairedDevices where c.DisplayName.Equals(blueToothAddress) select c);
                if (items.Count() <= 0)
                {
                    this.blueToothAddress = "";
                }
                else
                {
                    peerinfo = null;
                    peerinfo = items.ElementAt(0);
                }
            } 
            //
            return true;
        }
        */

    }
}
