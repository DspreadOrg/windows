﻿namespace SDK_LIB
{
    /// <summary>
    /// CmdId Class implements both command IDs that are used to signal QPOS hardware
    /// and IDs that are used to indicate QPOS hardware device status.
    /// </summary>
    public class CmdId
    {
        public static  int CMDID_OLD = 0x0;			//00H/01H/1xH：以前老协议。
	    public static  int CMDID_RESET =0x20;      //复位，丢弃正执行的命令操作
	    public static  int CMDID_PROCESS =0x21;      //下发新命令
	    public static  int CMDID_QUERY = 0x22;      //查询命令结果
	    public static  int WAIT_RESULT = 0x23;	//23H：正执行命令，还没结果。
	    public static  int CMDID_WAITING = 0x23;      //正执行命令，还没结果
	    public static  int CMDID_COMPLETED = 0x24;      //结果返回
	    public static  int CMDID_TIMEOUT = 0x25;      //超时返回
	    public static  int CMDID_DESTRUCT = 0x26;      //自毁返回
	    public static  int CMDID_CRCERROR = 0x27;      //校验错误返回
	    public static  int CMDID_USERCANCEL = 0x28;      //用户取消交易
	    public static  int CMDID_MACERROR = 0x29;      //MAC校验错误

	    public static  int CMDID_ICC_INIT_ERROR = 0x30;      //icc模块初始化失败
	    public static  int CMDID_ICC_POWER_ON_ERROR = 0x31;     //icc卡上电失败
	    public static  int CMDID_ICC_TRADE_ERROR = 0x32;     //icc卡通讯失败	
	
	    public static  int CMDID_EMV_TRANS_TERMINATE = 0x33;      //EMV交易终止
	    public static  int CMDID_EMV_TRANS_DENIAL = 0x34;      //EMV交易拒绝
	    public static  int CMDID_NOT_AVAILABLE = 0x35;      //命令不可用
	
	    public static  int CMDID_PART_DATA = 0x36;      //数据拆包发送
	
	    //add 2014-03-31
	    public static  int CMDID_EMV_APP_CFG_ERROR = 0x37;      //emv app 配置错误
	    public static  int CMDID_EMV_CAPK_CFG_ERROR = 0x38;      //emv capk 配置错误
	    public static  int CMDID_WR_DATA_ERROR = 0x39;      //读/写数据失败
	
        public static  int CMDID_NO_UPDATE_WORK_KEY = 0x40;      //没有更新工作密钥
        public static int CMDID_INPUT_PIN_ING = 0x41;      // 输入密码中
        public static int CMDID_MAG_TO_ICC_TRADE = 0x42;      //请转IC卡交易
        public static int CMDID_SEND_IC_CARDNO = 0x43;      //上报IC卡卡号

        public static int CMDID_EMV_TRANS_CARD_BLOCKED_OR_EMV_APPS = 0x44;     // 
        public static int CMDID_EMV_TRANS_SELECT_APP_FAILED = 0x45;    // 
        public static int CMDID_EMV_TRANS_CAPK_FAILED = 0x46;     //
        public static int CMDID_EMV_TRANS_FALLBACK = 0x47;     //
        public static int CMDID_EMV_TRANS_TERMINATE_NFC = 0x48;//

        public static int CMDID_EMV_KERNEL_PC = 0x49;
        public static int CMDID_COMPLETED_ENCRY = 0x88;

    }
}
