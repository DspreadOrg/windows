﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Windows.Devices.Enumeration;
using SDK_LIB;

namespace QPOSDesktopDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public sealed partial class MainWindow : Window
    {
        public MainWindow()
        {
            // Initialise UI Components and reset bunch of flags.
            InitializeComponent();
            listOfDevices = new ObservableCollection<DeviceListEntry>();
            mapDeviceWatchersToDeviceSelector = new Dictionary<DeviceWatcher, string>();
            watchersStarted = false;
            watchersSuspended = false;
            isAllDevicesEnumerated = false;
            Current = this;

            // If we are connected to the device or planning to reconnect, we should disable the list of devices
            // to prevent the user from opening a device without explicitly closing or disabling the auto reconnect
            if (EventHandlerForDevice.Current.IsDeviceConnected
                || (EventHandlerForDevice.Current.IsEnabledAutoReconnect
                && EventHandlerForDevice.Current.DeviceInformation != null))
            {
                UpdateConnectDisconnectButtonsAndList(ButtonType.DisconnectButton);

                // These notifications will occur if we are waiting to reconnect to device when we start the page
                EventHandlerForDevice.Current.OnDeviceConnected = this.OnDeviceConnected;
                EventHandlerForDevice.Current.OnDeviceClose = this.OnDeviceClosing;
            }
            else
            {
                UpdateConnectDisconnectButtonsAndList(ButtonType.ConnectButton);
            }

            NotifyUser(promoteUserToStart, NotifyType.StatusMessage);
        }

        private void scanSerial_Click(object sender, RoutedEventArgs e)
        {
            // Initialize the desired device watchers so that we can watch for when devices are connected/removed
            StopBleDeviceWatcher();
            InitializeDeviceWatchers();
            StartDeviceWatchers();

            CollectionViewSource DeviceListSource = (CollectionViewSource)Current.Resources["DeviceListSource"];
            DeviceListSource.Source = listOfDevices;
            bleScanRunning = false;
        }

        private void ButtonDisconnectFromDevice_Click(object sender, RoutedEventArgs e)
        {
            var selection = ConnectDevices.SelectedItems;
            MainWindow.NotifyType notificationStatus;
            notificationStatus = NotifyType.StatusMessage;
            String notificationMessage = null;
            if (bleScanRunning)
            {
                pos.disConnectFull();
                if (selection.Count > 0)
                {
                    var obj = selection[0];
                    BluetoothLEDeviceDisplay bleEntry = (BluetoothLEDeviceDisplay)obj;
                    notificationMessage = "Bluetooth 4.0 Device " + bleEntry.Name + " closed";
                }
                MainWindow.Current.NotifyUser(notificationMessage, notificationStatus);
                UpdateConnectDisconnectButtonsAndList(ButtonType.ConnectButton);
                return;
            }
            DeviceListEntry entry = null;

            // Prevent auto reconnect because we are voluntarily closing it
            // Re-enable the ConnectDevice list and ConnectToDevice button if the connected/opened device was removed.
            EventHandlerForDevice.Current.IsEnabledAutoReconnect = false;

            if (selection.Count > 0)
            {
                var obj = selection[0];
                entry = (DeviceListEntry)obj;

                if (entry != null)
                {
                    var deviceType = entry.DeviceType;
                    if (deviceType == "Bluetooth Device")
                    {
                        pos.disConnectFull();
                    }
                    else { pos.disConnect(); }
                }
            }
            notificationMessage = "Device " + deviceInfo.Name + " closed";
            MainWindow.Current.NotifyUser(notificationMessage, notificationStatus);
            UpdateConnectDisconnectButtonsAndList(ButtonType.ConnectButton);
            waitForBTConnectionResult.Reset();
        }

        private void ConnectDevices_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selection = ConnectDevices.SelectedItems;

            if (!bleScanRunning)
            {
                DeviceListEntry entry = null;
                if (selection.Count > 0)
                {
                    var obj = selection[0];
                    entry = (DeviceListEntry)obj;
                    System.Diagnostics.Debug.WriteLine("Selection Changed!!***********************************");
                    var deviceType = entry.DeviceType;
                    if (deviceType == "Bluetooth Device")
                    {
                        ButtonConnectToUSBDevice.IsEnabled = false;
                        ButtonConnectToBTDevice.IsEnabled = true;
                    }
                    else
                    {
                        ButtonConnectToUSBDevice.IsEnabled = true;
                        ButtonConnectToBTDevice.IsEnabled = false;
                    }
                }
            }
            else
            {
                BluetoothLEDeviceDisplay entry = null;
                if (selection.Count > 0)
                {
                    var obj = selection[0];
                    entry = (BluetoothLEDeviceDisplay)obj;
                    System.Diagnostics.Debug.WriteLine("Selection Changed!!***********************************");
                    ButtonConnectToUSBDevice.IsEnabled = false;
                    ButtonConnectToBTDevice.IsEnabled = true;
                    NotifyType messageType = new NotifyType();
                    messageType = (entry.IsPaired) ? NotifyType.StatusMessage : NotifyType.ErrorMessage;
                    NotifyUser("Bluetooth 4.0 Device - " + entry.Name + " is selected. Device pairing status: " + entry.IsPaired + ".", messageType);
                }
            }
        }

        private void doTrade_Click(object sender, RoutedEventArgs e)
        {
            if (pos == null)
            {
                return;
            }
            pos.doTrade();
            return;
        }

        private void getPosId_Click(object sender, RoutedEventArgs e)
        {
            if (pos == null)
            {
                return;
            }
            pos.getQposId();
            return;
        }

        private void getPosInfo_Click(object sender, RoutedEventArgs e)
        {
            if (pos == null)
            {
                return;
            }
            pos.getQposInfo();
            return;
        }

        private void resetPosStatus_Click(object sender, RoutedEventArgs e)
        {
            //pos.sendDeviceCommandString("0000");
            //Task.Delay(5000000);
            //pos.doTrade();

            // Testing for resetQPOSStatus() method
            //if (pos.resetQPosStatus())
            //{
            //    textResult.Text = "resetQPOSStatus() Operation is completed!";
            //}
            //else
            //{
            //    textResult.Text = "resetQPOSStatus() Operation is failed...";
            //}
            // Testing for resetQPOS() method
            if (pos == null)
            {
                return;
            }
            if (pos.resetQPOS())
            {
                textResult.Text = "Device Reset is completed!";
            }
            else
            {
                textResult.Text = "Unable to reset device due to unexpected error..";
            }

            return;
        }

        private async void pairBluetooth_Click(object sender, RoutedEventArgs e)
        {
            if (!bleScanRunning)
            {
                var isSuccessful = await OpenBluetoothSettings();
                if (!isSuccessful)
                {
                    MessageBox.Show("Error, unable to open System Bluetooth Setting Window", "Oops....", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                return;
            }
            Pairing();
        }

        private async void ButtonConnectToBTDevice_Click(object sender, RoutedEventArgs e)
        {
            NotifyUser(connectionInProgress, NotifyType.ProcessingMessage);
            if (bleScanRunning)
            {
                ConnectToBLEDevice();
            }
            else
            {
                ConnectToBTLegacyDevice();
            }
            
        }

        private async void ButtonConnectToUSBDevice_Click(object sender, RoutedEventArgs e)
        {
            NotifyUser(connectionInProgress, NotifyType.ProcessingMessage);
            var selection = ConnectDevices.SelectedItems;
            DeviceListEntry entry = null;

            if (selection.Count > 0)
            {
                var obj = selection[0];
                entry = (DeviceListEntry)obj;
                System.Diagnostics.Debug.WriteLine("button clicked !!***********************************");
                if (entry != null)
                {
                    // Create an EventHandlerForDevice to watch for the device we are connecting to
                    EventHandlerForDevice.CreateNewEventHandlerForDevice();

                    // Get notified when the device was successfully connected to or about to be closed
                    EventHandlerForDevice.Current.OnDeviceConnected = this.OnDeviceConnected;
                    EventHandlerForDevice.Current.OnDeviceClose = this.OnDeviceClosing;

                    // It is important that the FromIdAsync call is made on the UI thread because the consent prompt, when present,
                    // can only be displayed on the UI thread. Since this method is invoked by the UI, we are already in the UI thread.
                    Boolean openSuccess = await OpenDeviceAsync(entry.DeviceInformation, entry.DeviceSelector);


                    // Disable connect button if we connected to the device
                    //UpdateConnectDisconnectButtonsAndList(!openSuccess);
                    if (openSuccess)
                    {
                        UpdateConnectDisconnectButtonsAndList(ButtonType.DisconnectButton);
                    }
                    else
                    {
                        UpdateConnectDisconnectButtonsAndList(ButtonType.ConnectButton);
                    }
                }
            }
        }

        private void scanBLE_Click(object sender, RoutedEventArgs e)
        {
            if (deviceWatcherBLE == null)
            {
                StopDeviceWatchers();
                StartBleDeviceWatcher();
                CollectionViewSource DeviceListSource = (CollectionViewSource) Current.Resources["DeviceListSource"];
                DeviceListSource.Source = ResultCollection;
                bleScanRunning = true;
                NotifyUser($"Device watcher for bluetooth 4.0 device started.", NotifyType.StatusMessage);
            }
        }
    }
}
