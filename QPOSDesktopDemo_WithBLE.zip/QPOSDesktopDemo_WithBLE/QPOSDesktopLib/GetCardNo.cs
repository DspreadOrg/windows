﻿using System;

namespace SDK_LIB
{
    /// <summary>
    /// GetCardNo class implements the relavent method to query card number from QPOS device
    /// </summary>
    public class GetCardNo
    {
        /// <summary>
        /// Private field to store an instance of the QPOSService object.
        /// </summary>
        private QPOSService esc;

        /// <summary>
        /// CTOR
        /// </summary>
        /// <param name="esc">External QPOSService object that will be passed to the class</param>
        public GetCardNo(QPOSService esc)
        {
            this.esc = esc;
        }

        /// <summary>
        /// Method to query card number from QPOS
        /// </summary>
        /// <param name="pos">POS object</param>
        public void doGetCardNo(VPos pos)
        {
            CommandDownlink dc = null; // Command that will be issued to the device
            CommandUplink uc = null; // Command that will contain the response from the device.

            // Issue 1040 command, refer to QPOS Protocol for more info
            dc = new CommandDownlink(0x10, 0x40, 30);
            pos.sendCommand(dc);
            uc = pos.receiveCommandWaitResult(30);
            bool f = esc.checkCmdId(uc);
            if (!f) return;
            Tip.d("cardNoStr : " + Util.byteArray2Hex(uc.getBytes(0, uc.length())));
            byte[] btmp = uc.getBytes(0, uc.length());
            String cardNoStr = System.Text.Encoding.UTF8.GetString(btmp, 0, btmp.Length);

            esc.onGetCardNoResult(cardNoStr);
        }
    }
}
