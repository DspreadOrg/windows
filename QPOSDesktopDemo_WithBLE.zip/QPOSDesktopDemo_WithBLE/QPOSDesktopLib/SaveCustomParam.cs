﻿using System;

namespace SDK_LIB
{
    public class SaveCustomParam
    {
        private static int READ_MAX_LEN =  128;
	    private static int WRITE_MAX_LEN =  256;
	
	    public enum CustomParam {
		    CUSTOM_PARAM_SEG_CUSTOM1,
		    CUSTOM_PARAM_SEG_CUSTOM2,
		    CUSTOM_PARAM_SEG_EMV_APP,
		    CUSTOM_PARAM_SEG_EMV_CAPK
	    }
	
	    private int configSize = 0;
	    private String configString = "";
	    private operationLogo mOperLogo = operationLogo.READ;
	    private QPOSService esc;
	    public SaveCustomParam(QPOSService esc){
		    this.esc = esc;
	    }

	    public bool doUpdateCustomParam(VPos pos, CustomParam customParam, int offset, String customParamString){
		    int customParamSize = customParamString.Length;
		    customParamSize = customParamSize/2;
		    bool f = startSendCustomParam(pos, operationLogo.WRITE, customParam, customParamSize);
		    if(!f)return false;
		
		    f = updateCustomParam(pos, operationLogo.WRITE, customParam, offset, customParamString);
		    if(!f)return false;
		
		    f = stopSendCustomParam(pos, operationLogo.WRITE, customParam);
		    if(!f)return false;
		
		    return true;
	    }
	
	    public bool doReadCustomParam(VPos pos, CustomParam customParam, int offset, int customParamSize){
		
		    configSize = 0;
		    bool f = startSendCustomParam(pos, operationLogo.READ, customParam, customParamSize);
		    if(!f)return f;
		
		    if(customParam==CustomParam.CUSTOM_PARAM_SEG_EMV_CAPK ||customParam==CustomParam.CUSTOM_PARAM_SEG_EMV_APP){
			    customParamSize = configSize;
		    }		
		    f = readCustomParam(pos, operationLogo.READ, customParam, offset, customParamSize);
		    if(!f)return f;
		
		    f = stopSendCustomParam(pos, operationLogo.READ, customParam);
		    if(!f)return f;
		
		    esc.onReturnCustomConfigResult(f, configString);
		    return f;
	    }
	
	    private bool updateCustomParam(VPos pos, operationLogo opLogo, CustomParam customParam, int offset, String customParamString){
		    String aStr = "";
		    int customParamSize = customParamString.Length/2;
		    Tip.d("offset: "+offset +", size: "+customParamSize);
		    byte[] arrs = Util.HexStringToByteArray(customParamString);
		
		    int index = 0;
		    while (customParamSize > 0) {
			    int tmp = (int) offset;//偏移量
			    int hh = tmp>>24;
			    int hl = (tmp>>16)&0xff;
			    int lh = (tmp>>8)&0xff;
			    int ll = (tmp)&0xff;
			
			    aStr = Util.byteArray2Hex(Util.IntToHex((int) hh));
			    aStr += Util.byteArray2Hex(Util.IntToHex((int) hl));
			    aStr += Util.byteArray2Hex(Util.IntToHex((int) lh));
			    aStr += Util.byteArray2Hex(Util.IntToHex((int) ll));
			
			    tmp = customParamSize;//长度
			    if(tmp > WRITE_MAX_LEN){
				    tmp = WRITE_MAX_LEN;
			    }
			    lh = (tmp>>8)&0xff;
			    ll = (tmp)&0xff;
			
			    aStr += Util.byteArray2Hex(Util.IntToHex((int) lh));
			    aStr += Util.byteArray2Hex(Util.IntToHex((int) ll));
			
			    byte[] tmparrs = new byte[tmp];
			    Array.Copy(arrs, index, tmparrs, 0, tmp);
			    aStr += Util.byteArray2Hex(tmparrs);
			
			    byte[] paras = Util.HexStringToByteArray(aStr);
			    CommandDownlink dc = new CommandDownlink(0x16, 0xa0, 10, paras);
			    CommandUplink uc = null;
			    pos.sendCommand(dc);
			    uc = pos.receiveCommandWaitResult(10);
			    bool f = esc.checkCmdId(uc);
			    if(!f){		
				    return false;
			    }
			    customParamSize -= tmp;
			    offset += tmp;
			    index += tmp;			
		    }		
		
		    return true;
	    }
	
	    private bool readCustomParam(VPos pos, operationLogo opLogo, CustomParam customParam, int offset, int customParamSize){
		    Tip.d("start read custom param");
		    Tip.d("offset: "+offset +", size: "+customParamSize);
		    String aStr = "";
		    configString = "";
		    while (customParamSize > 0) {
			    int tmp = offset;//偏移量
			    int hh = tmp>>24;
			    int hl = (tmp>>16)&0xff;
			    int lh = (tmp>>8)&0xff;
			    int ll = (tmp)&0xff;
			
			    aStr = Util.byteArray2Hex(Util.IntToHex((int) hh));
			    aStr += Util.byteArray2Hex(Util.IntToHex((int) hl));
			    aStr += Util.byteArray2Hex(Util.IntToHex((int) lh));
			    aStr += Util.byteArray2Hex(Util.IntToHex((int) ll));
			
			    tmp = customParamSize;//长度
			    if(tmp > READ_MAX_LEN){
				    tmp = READ_MAX_LEN;
			    }
			    lh = (tmp>>8)&0xff;
			    ll = (tmp)&0xff;
			
			    aStr += Util.byteArray2Hex(Util.IntToHex((int) lh));
			    aStr += Util.byteArray2Hex(Util.IntToHex((int) ll));
			
			
			    byte[] paras = Util.HexStringToByteArray(aStr);
			    CommandDownlink dc = new CommandDownlink(0x16, 0xa1, 10, paras);
			    CommandUplink uc = null;
			    pos.sendCommand(dc);
			    uc = pos.receiveCommandWaitResult(10);
			    bool f = esc.checkCmdId(uc);
			    if(!f){		
    //				configString = ""
				    return false;
			    }
			    customParamSize -= tmp;
			    offset += tmp;
    //			Tip.i(">>"+Util.byteArray2Hex(uc.getBytes(0, uc.Length)));
			    configString += Util.byteArray2Hex(uc.getBytes(0, uc.length()));	
    //			Tip.w("config: "+configString);
			
		    }		
		    //TODO 
    //		LogFileConfig.LogFileInit("customParam");
    //		LogFileConfig.writeLog(configString);
		    return true;
	    }
	
	
	
	    private bool startSendCustomParam(VPos pos, operationLogo opLogo, CustomParam customParam, int customParamSize){
		    byte[] paras = new byte[0];
		    String aStr = "";
		
		    mOperLogo = opLogo;
		    if (opLogo == operationLogo.READ) {//操作标识
			    aStr += "00";
		    }else { 
			    aStr += "01";
		    }
		
		    if(customParam==CustomParam.CUSTOM_PARAM_SEG_EMV_APP){//操作类型
			    aStr += "00";
		    }else if(customParam==CustomParam.CUSTOM_PARAM_SEG_EMV_CAPK){
			    aStr += "01";
		    }else if(customParam==CustomParam.CUSTOM_PARAM_SEG_CUSTOM1){
			    aStr += "02";
		    }else if(customParam==CustomParam.CUSTOM_PARAM_SEG_CUSTOM2){
			    aStr += "03";
		    }
		
		    int tmp = customParamSize;//长度
		    int hh = tmp>>24;
		    int hl = (tmp>>16)&0xff;
		    int lh = (tmp>>8)&0xff;
		    int ll = (tmp)&0xff;
		
		    aStr += Util.byteArray2Hex(Util.IntToHex((int) hh));
		    aStr += Util.byteArray2Hex(Util.IntToHex((int) hl));
		    aStr += Util.byteArray2Hex(Util.IntToHex((int) lh));
		    aStr += Util.byteArray2Hex(Util.IntToHex((int) ll));
		
		    aStr += "10";
		
		    paras = Util.HexStringToByteArray(aStr);
		    CommandDownlink dc = new CommandDownlink(0x16, 0x90, 10, paras);
		    CommandUplink uc = null;
		    pos.sendCommand(dc);
		    uc = pos.receiveCommandWaitResult(10);
		    bool f = esc.checkCmdId(uc);
		    if(!f){				
			    return false;
		    }
		    byte[] arrs = uc.getBytes(0, uc.length());
		    Tip.d("save custom param: "+Util.byteArray2Hex(arrs));
		    configSize = Util.byteArrayToInt(arrs);
		    Tip.d("config size: "+configSize);
		    return true;
	    }
	
	    private bool stopSendCustomParam(VPos pos, operationLogo opLogo, CustomParam customParam){
		    byte[] paras = new byte[0];
		    String aStr = "";
		
		    mOperLogo = opLogo;
		    if (opLogo == operationLogo.READ) {//操作标识
			    aStr += "00";
		    }else { 
			    aStr += "01";
		    }
		
		    if(customParam==CustomParam.CUSTOM_PARAM_SEG_EMV_APP){//操作类型
			    aStr += "00";
		    }else if(customParam==CustomParam.CUSTOM_PARAM_SEG_EMV_CAPK){
			    aStr += "01";
		    }else if(customParam==CustomParam.CUSTOM_PARAM_SEG_CUSTOM1){
			    aStr += "02";
		    }else if(customParam==CustomParam.CUSTOM_PARAM_SEG_CUSTOM2){
			    aStr += "03";
		    }
				
		    paras = Util.HexStringToByteArray(aStr);
		    CommandDownlink dc = new CommandDownlink(0x16, 0x91, 10, paras);
		    CommandUplink uc = null;
		    pos.sendCommand(dc);
		    uc = pos.receiveCommandWaitResult(10);
		    bool f = esc.checkCmdId(uc);
		    if(!f){				
			    return false;
		    }
		    return true;
	    }
	
	    private enum operationLogo{
		    READ,
		    WRITE
	    }
    }
}
