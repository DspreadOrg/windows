﻿namespace SDK_LIB
{
    public class TradeMsg
    {
        public const int MSG_DO_TRADE = 30001;
        public const int MSG_DO_TRADE_QF = 30002;
        public const int MSG_DO_EMV_APP = 30003;
        public const int MSG_GET_POS_ID = 30005;
        public const int MSG_GET_POS_INFO = 30006;
        public const int MSG_UPDATE_FIRMWARE = 30007;
        public const int MSG_SIGNATURE = 30008;
        public const int MSG_GET_PIN = 30009;

        public const int MSG_CONNECTED_BLUETOOTH = 30011;
        public const int MSG_POWER_ON_ICC = 30012;
        public const int MSG_POWER_OFF_ICC = 30013;
        public const int MSG_SEND_APDU = 30014;
        public const int MSG_SET_SLEEP_TIME = 30015;

        //qf
        public const int MSG_GET_CARDNO = 30016;
        public const int MSG_LCD_SHOW_CUSTOM_DISPLAY = 30017;

        //zz
        public const int MSG_UPDATE_FIRMWARE_TMK_ZZ = 30018;
        public const int MSG_CALCULATE_MAC = 30019;

        public const int MSG_EXIT_TRADE = 30020;


        //add 2014-03-31 

        public const int MSG_UPDATE_EMV_APP_CONFIG = 30021;
        public const int MSG_UPDATE_EMV_CAPK_CONFIG = 30022;
        public const int MSG_UPDATE_EMV_CONFIG = 30023;
        public const int MSG_READ_EMV_APP_CONFIG = 30024;
        public const int MSG_READ_EMV_CAPK_CONFIG = 30025;

        public const int MSG_GET_ICC_EMV_DATA = 30026;
        public const int MSG_SET_MASTER_KEY = 30027;
        public const int MSG_CONNECTED_USBSERIAL = 30028;
        public const int MSG_getMagneticTrackPlaintext = 30029;
        public const int MSG_GET_PIN1071 = 30057;
        public const int MSG_GET_POS_RSA = 30058;
        public const int MSG_SET_FORMAT_ID = 30059;

        //added on 29th January 2018 By Sheng Zhang
        public const int MSG_CONNECTED_BLUETOOTH_LE = 30060;
    }
}
