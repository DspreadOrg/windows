﻿namespace SDK_LIB
{
    /// <summary>
    /// Class that implements the Downlink command, which is the message sent to the Device from the App
    /// The Downlink command object which wraps around a communication packet
    /// for easier and more intuitive communication data management
    /// </summary>
    public class CommandDownlink
    {
        /// <summary>
        /// Private data field to store an instant of Packet class
        /// </summary>
        private Packet p = null;

        /// <summary>
        /// CTOR to construct a new Downlink Command message that will be executed by the device without providing data frame payload.
        /// </summary>
        /// <param name="cmdCode">Main Command Code</param>
        /// <param name="cmdSubCode">Sub Command Code</param>
        /// <param name="delay">Execution Timeout value</param>
        public CommandDownlink(int cmdCode, int cmdSubCode, int delay)
        {
            // CMDID = 0X21 -> Initiate new command execution
            packCmmandDownlink(0x21, cmdCode, cmdSubCode, delay, new byte[] { });
        }

        /// <summary>
        /// CTOR overload to construct a new Downlink Command message that will be executed by the device with data frame payload.
        /// </summary>
        /// <param name="cmdCode">Main Command Code</param>
        /// <param name="cmdSubCode">Sub Command Code</param>
        /// <param name="delay">Execution Timeout Value</param>
        /// <param name="paras">Data frame payload</param>
        public CommandDownlink(int cmdCode, int cmdSubCode, int delay, byte[] paras)
        {
            packCmmandDownlink(0x21, cmdCode, cmdSubCode, delay, paras);

        }

        /// <summary>
        /// CTOR overload to construct a new Downlink Command message with custom device command ID and data frame payload.
        /// </summary>
        /// <param name="cmdID">Device Command ID, refer to Section 3 QPOS Communication protocol for more info</param>
        /// <param name="cmdCode">Main Command Code</param>
        /// <param name="cmdSubCode">Sub Command Code</param>
        /// <param name="delay">Execution Timeout Value</param>
        /// <param name="paras">Data Frame Payload</param>                                                                                                                                        
        public CommandDownlink(int cmdID, int cmdCode, int cmdSubCode, int delay, byte[] paras)
        {
            packCmmandDownlink(cmdID, cmdCode, cmdSubCode, delay, paras);

        }

        /// <summary>
        /// CTOR overload to construct a new Downlink Command message with custom device command ID and NO data frame payload.
        /// </summary>
        /// <param name="cmdID">Device Command ID, refer to Section 3 QPOS Communication protocol for more info</param>
        /// <param name="cmdCode">Main Command Code</param>
        /// <param name="cmdSubCode">Sub Command Code</param>
        /// <param name="delay">Execution Timeout Value</param>
        public CommandDownlink(int cmdID, int cmdCode, int cmdSubCode, int delay)
        {
            packCmmandDownlink(cmdID, cmdCode, cmdSubCode, delay, new byte[] { });

        }

        /// <summary>
        /// Core function (Used Privately) that builds the command message that will be sent to the device to execute
        /// </summary>
        /// <param name="cmdID">Device command ID</param>
        /// <param name="cmdCode">Main Command Code</param>
        /// <param name="cmdSubCode">Sub Command Code</param>
        /// <param name="delay">Operation Timeout value</param>
        /// <param name="paras">Data Frame Payload</param>
        private void packCmmandDownlink(int cmdID, int cmdCode, int cmdSubCode, int delay, byte[] paras)
        {
            // Initiate a new Packet object giving the length of the data frame payload
            p = new Packet(paras.Length);

            p.setCmdID((byte)cmdID);// Sets the Command ID
            p.setCmdCode((byte)cmdCode);// Sets the Main Command Code
            p.setCmdSubCode((byte)cmdSubCode);// Sets the Sub Command Code
            p.setTimeOut((byte)delay);// Sets the Timeout value
            p.setDataField(paras);// Sets the data frame payload
            p.buildCRC();// Calculate and Sets the CRC value for the Packet
        }

        /**
         *  get the value inside the command, in byte
         */
        /// <summary>
        /// Returns a single byte from the command message data frame payload at the index specified by the offset value.
        /// </summary>
        /// <param name="offset">Index Offset</param>
        /// <returns>The byte value from the data frame payload at specified index</returns>
        public byte getByte(int offset)
        {
            return p.getByte(offset);
        }

        /**
         *  Set the low level Packet inside the command
         */
        /// <summary>
        /// Return all data bytes within the command message.
        /// </summary>
        /// <returns>All data bytes within the reponse message.</returns>
        public byte[] getBytes()
        {
            return p.getBytes();
        }
	
    }
}
