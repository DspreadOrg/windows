﻿using System;

namespace SDK_LIB
{
    public class IccApdu
    {
        private QPOSService esc;

        public IccApdu(QPOSService esc)
        {
            this.esc = esc;
        }

        public void sendApdu(VPos pos, String apduString)
        {
            CommandDownlink dc = null;
            CommandUplink uc = null;

            dc = new CommandDownlink(0x16, 0x70, 30, Util.HexStringToByteArray(apduString));
            pos.sendCommand(dc);
            uc = pos.receiveCommandWaitResult(30);
            bool f = esc.checkCmdId(uc);
            if (!f) return;

            int index = 0;
            int re = uc.getByte(index++);
            if (re == 0)
            {
                esc.onReturnApduResult(false, null, 0);
                return;
            }
            int apduLen = Util.byteArrayToInt(new byte[] { uc.getByte(index++) });
            int apduMaskLen = Util.byteArrayToInt(new byte[] { uc.getByte(index++) });
            String apdu = Util.byteArray2Hex(uc.getBytes(index, apduMaskLen));
            esc.onReturnApduResult(true, apdu, apduLen);
        }

        public void powerOffIcc(VPos pos)
        {
            CommandDownlink dc = null;
            CommandUplink uc = null;
            dc = new CommandDownlink(0x16, 0x80, 10);
            pos.sendCommand(dc);
            uc = pos.receiveCommandWaitResult(10);
            bool f = esc.checkCmdId(uc);
            if (!f) return;
            esc.onReturnPowerOffIccResult(true);
        }

        public void powerOnIcc(VPos pos)
        {
            CommandDownlink dc = null;
            CommandUplink uc = null;
            dc = new CommandDownlink(0x16, 0x60, 30);
            pos.sendCommand(dc);
            uc = pos.receiveCommandWaitResult(30);
            //		Tip.w("end uc: "+ Util.byteArray2Hex(uc.getBytes(0, uc.length())));
            bool f = esc.checkCmdId(uc);
            if (!f) return;

            int index = 0;

            int re = uc.getByte(index++);
            if (re == 0)
            {
                esc.onReturnPowerOnIccResult(false, null, null, 0);
                return;
            }

            String ksn = Util.byteArray2Hex(uc.getBytes(index, 10));
            index += 10;
            int atrLen = uc.getByte(index++);
            int atrMaskLen = uc.getByte(index++);
            String atr = Util.byteArray2Hex(uc.getBytes(index, atrMaskLen));

            esc.onReturnPowerOnIccResult(true, ksn, atr, atrLen);

        }
    }
}
