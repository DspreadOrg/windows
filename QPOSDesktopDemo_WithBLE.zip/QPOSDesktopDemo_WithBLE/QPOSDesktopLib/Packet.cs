﻿using System;

namespace SDK_LIB
{
    /// <summary>
    /// Packet class implements a collection of data structure and 
    /// methods that constructs packet and validate as well as process data inside a packet.
    /// </summary>
    public class Packet
    {
        private static byte[] TCKEY = {0 ,0 ,0 ,0 ,0 ,0 ,0 ,0}; // private data field to store a specific 8 Byte Keys formed from DES KEY. Specifically required by client 钱方
        private byte[] bytes = new byte[0]; // Private data field that stores the packet data
        private int dataLen = 0; // data = command (0) + validData
	    private static int HEADER_LEN = 4;   //4D(1) + LEN(2) + Protocol Version(1) -> Length of Header Fields
        private static int CRC_LEN = 1;  //1byte CRC -> Length of the CRC value

        private static int OVERHEAD_LEN = HEADER_LEN + CRC_LEN; // 1M+2len+1cmd+1crc
	
	    private static int DATA_FIELD_HEADER_LEN = 5; // Length of the DATA FIELD HEADER

        /// <summary>
        /// CTOR Default. 
        /// </summary>
        public Packet(){
		
	    }

        /**
	     * 
	     * @param len 
	     */
        /// <summary>
        /// CTOR overload with custom defined data frame payload length to initiate an empty packets
        /// </summary>
        /// <param name="len">Length of the data frame payload (bytes after the data field header)</param>
        public Packet(int len){
		    dataLen = len;
		
		    len = OVERHEAD_LEN + DATA_FIELD_HEADER_LEN + len; // Calculate the length of the entire packet
            bytes = new byte[len];
		    bytes[1] = 0; // Initialise the first byte of data frame length to 0

            byte[] lens = Util.IntToHex(len - 4); // Calculate the data frame length

            // Write the data frame length data to the corresponding field.
            if (lens.Length==1){
			    bytes[2] = lens[0];
		    }else{
			    bytes[1] = lens[0];
			    bytes[2] = lens[1];
		    }

            // Write start of packet delimiter
            // Packet needs to be started with single byte 0X4D
            bytes[0] = 0x4D;
		
	    }

        /// <summary>
        /// CTOR overload to create a packet object with predefined packet data bytes.
        /// </summary>
        /// <param name="b">Predefined packet data bytes</param>
        public Packet(byte[] b){
		    bytes = b;
		    dataLen = b.Length - OVERHEAD_LEN + DATA_FIELD_HEADER_LEN; // Calculate the length of data frame payload.
        }

        /// <summary>
        /// Write data byte at the index specified by offset value after the packet header fields
        /// </summary>
        /// <param name="offset">Index offset</param>
        /// <param name="dat">Data byte that will be write into the field</param>
        public void setByte(int offset, byte dat){
		    bytes[HEADER_LEN + offset] = dat;
	    }

        /// <summary>
        /// Return a single byte of data in the message encapsulated in the packet.
        /// Offset is the number of bytes offsetted from index 0
        /// The packet header has been escaped in this function.
        /// </summary>
        /// <param name="offset">The number of bytes offsetted from index 0</param>
        /// <returns>A single byte of data in the packet message</returns>
        public byte getByte(int offset) {
		    if (offset+HEADER_LEN < bytes.Length){
			    return bytes[offset + HEADER_LEN];
		    } else {		
			    return 0x00;
		    }
	    }

        /// <summary>
        /// Return all bytes encapsulated in a packet.
        /// </summary>
        /// <returns>Byte array contains all data in the packet</returns>
        public byte[] getBytes(){
		    return bytes;
	    }

        /// <summary>
        /// Write the command ID value in the packet header
        /// </summary>
        /// <param name="cmdID">Command ID defined in the QPOS communication protocol, refer to CMDID table in section 3 of the protocol document</param>
        public void setCmdID(byte cmdID){
		    bytes[3] = cmdID;
	    }

        /// <summary>
        /// Return the Byte that corresponse to predefined CMDID in a communication packet.
        /// </summary>
        /// <returns>CMDID Byte Code</returns>
        public byte getCmdID(){
		    return bytes[3];
	    }

        /// <summary>
        /// Write the main command code byte value in the packet message.
        /// </summary>
        /// <param name="cmdCode">Byte value correspond to the main command code</param>
        public void setCmdCode(byte cmdCode){
		    setByte(0, cmdCode);
	    }

        /// <summary>
        /// Write the sub command code byte value in the packet message.
        /// </summary>
        /// <param name="cmdSubCode">Byte value correspond to the sub command code</param>
        public void setCmdSubCode(byte cmdSubCode){
		    setByte(1, cmdSubCode);
	    }

        /// <summary>
        /// Return the main command code/function code send to/replied from the device.
        /// E.g. for command code 1620, getCmdCode() returns 16 in byte form.
        /// </summary>
        /// <returns>A single byte that corresponse to the main command code</returns>
        public byte getCmdCode(){
		    return getByte(0);
	    }

        /// <summary>
        /// Return the sub command code/function code send to/replied from the device.
        /// E.g. for command code 1620, getCmdSubCode() returns 20 in byte form.
        /// </summary>
        /// <returns>A single byte that corresponse to the sub command code</returns>
        public byte getCmdSubCode(){
		    return getByte(1);
	    }

        /// <summary>
        /// Return the byte after the main and sub command bytes.
        /// If the message is a uplink message (device response message), this indicates if the command executes successfully or not.
        /// If the message is a downlink message (message sends to device), this indicates timeout value.
        /// </summary>
        /// <returns>The byte after the main and sub command bytes</returns>
        public byte getResultCode(){
		    return getByte(2);
	    }

        /// <summary>
        /// Write the data into the data Field (Field that is after the 4 Header Fields)
        /// </summary>
        /// <param name="dataField">Data field data bytes</param>
        public void setDataField(byte[] dataField){
		    int len =  dataField.Length;
		    setByte(3, (byte)0); // Initialise the First byte field that stores the length of the data bytes to 0.

            // Write the data length into the corresponding field within the message.
            byte[] lens = Util.IntToHex(len);
		
		    if(lens.Length==1){
			    setByte(4, lens[0]);
		    }else{
			    setByte(3, lens[0]);
			    setByte(4, lens[1]);
		    }

            // Copy the data bytes into the data field of the message.
            Array.Copy(dataField, 0, bytes, HEADER_LEN+5, dataField.Length);
	    }

        /// <summary>
        /// Return a single byte from the data field of the packet.
        /// The location of the byte is selected based on the offset value.
        /// The function escapes both Packet Header fields, Command Code/Function Code fields and response code field.
        /// </summary>
        /// <param name="offset">Index offset</param>
        /// <returns>A single byte</returns>
        public byte getDataFieldByte(int offset) {
		    if (offset+HEADER_LEN + 5< bytes.Length){
			    return bytes[offset + HEADER_LEN + 5];
		    } else {		
			    return 0x00;
		    }
	    }

        /// <summary>
        /// Write the timeout value (in byte form) to the Downlink command message field.
        /// The function has escaped the Packet header to ensure data is written to the correct location.
        /// </summary>
        /// <param name="timeOut">Timeout value in Byte form</param>
        public void setTimeOut(byte timeOut){
		    setByte(2, timeOut);
	    }

        /// <summary>
        /// Method to calculate the Cyclic Redundency Check (CRC) value based on the full packet message.
        /// </summary>
        /// <returns>Single byte represents the CRC value</returns>
        private byte calCRC() {

            System.Diagnostics.Debug.WriteLine("before crc:"+Util.byteArray2Hex(bytes));

            byte crcbyte = bytes[0];
		    for (int i = 1; i < bytes.Length - 1; i++) {
			    crcbyte = (byte) (crcbyte ^ bytes[i]);
		    }
		    return crcbyte;
	    }

        /// <summary>
        /// Write defined CRC value byte to the last index of the packet message. 
        /// </summary>
        /// <param name="crc">CRC value byte</param>
        public void setCRC(byte crc) {
		    bytes[bytes.Length-1] = crc;
	    }

        /// <summary>
        /// Write calculated CRC value byte to the last index of the packet message.
        /// </summary>
        public void buildCRC() {
		    setCRC(calCRC());
	    }

        /// <summary>
        /// Return the CRC byte from the packet message.
        /// </summary>
        /// <returns>CRC byte value</returns>
        public byte getCRC() {
		    return bytes[bytes.Length-1];
	    }

        /// <summary>
        /// Validate if the received packet contains any transmission error by checking the CRC value
        /// </summary>
        /// <returns>Boolean value indicate if the received packet is valid</returns>
        public bool validCRC() {
		    byte crc = calCRC(); // calculate the received packet CRC value

            // Check if the message is valid.
            // calCRC == messageCRC -> valid, calCRC != messageCRC -> contain Err
            if (crc == getCRC()) {
			    return true;
		    } else {
			    return false;
		    }
	    }

        /// <summary>
        /// Check if the packet is valid
        /// </summary>
        /// <returns>Boolean indicates if the packet is valid</returns>
        public bool isValid() {
            // Validate packet header
            // Valid packet needs to have 4D as its first byte.
            if (bytes[0] != 0x4d){
			    Tip.w("packet is not valid cause not 0x4D");
			    return false;
		    }
            // Validate CRC value
            return validCRC();
	    }

        /// <summary>
        /// Check if the packet is empty.
        /// </summary>
        /// <returns>Boolean Value indicate if the packet is empty</returns>
        public bool isEmpty(){
		    return dataLen==0;
	    }
	
	
	    public int len() {
		    return dataLen;
	    }

        /// <summary>
        /// Set the DES Key prior to doTrade() method for 钱方 Client
        /// </summary>
        /// <param name="KEY">DES Key Byte Array</param>
        public static void setDesKey(byte[] KEY) {
		    Tip.i("TCK");
		    Tip.i(Util.byteArray2Hex(KEY));
		    if(KEY.Length==8){
                // If the provided DES Key is 8 bytes long, 
                // then set the internal TCKEY variable directly equal to DES Key
                TCKEY = KEY;
		    }else if(KEY.Length==16){
                // If the provided DES Key is 16 bytes long,
                // then the provided DES Key is subdivided into two 8 Bytes long Key
                // and Bytewise XORed with each other to form a final 8 Bytes long Key
                byte[] deskey = new byte[8];
			    for (int i = 0; i < 8; i++) {
				    deskey[i]= (byte)(KEY[i] ^ KEY[i+8]);
			    }
			    TCKEY = deskey;
		    }else{
			    Tip.i("TCK Length error ");
		    }
		
	    }

        /// <summary>
        /// Calculate the MAC (Message authentication code) Value
        /// </summary>
        /// <param name="ibuf">Incoming data which the MAC will be calculated based on</param>
        /// <param name="ilen">Length of the base data</param>
        /// <returns>Byte array that contains Calculated MAC value</returns>
        public static byte[] calMac(byte[] ibuf,int ilen){
		    Tip.d("mac["+ilen+"] src:"+ Util.byteArray2Hex(ibuf));
		
		    int padding_len = 8 - (ilen + 1) % 8; // Calculate length of the additional paddings. The incoming data needs to have a length of multiple of 8.
            int len = ilen + 1 + padding_len; // The 'True' Length of the output byte array, accounting for original data as well as the additional paddings

            // Temporary variable to store the original data bytes with additional paddings before MAC calculation.
            byte[] payload1 = new byte[len];
		    Array.Copy(ibuf, 0, payload1, 0, ilen); // Copy the original data bytes

            // Pad additional zeros
            for (int i = ilen; i < len; i++) {
			    payload1[i] = 0;
		    }
		
		    // 8 bytes XOR
		    byte[] payload = { 0, 0, 0, 0, 0, 0, 0, 0 };
            // Tip.d( "calMAC payload1 size:"+ payload1.Length) ;

            // The algorithm to calculate MAC value is by first divide the original data bytes array
            // into 8 Bytes length long chunks. Set the output MAC data equals to the first chunk.
            // Then it is Bytewise XORed with each remaining chunk of byte array. The intermediate XOR
            // result is used directly for subsequent Bytewise XOR operation until all data chunks have
            // been gone through.
            for (int i = 0; i < len; i++) {
			    // Tip.d( "calMAC i%8:"+ i%8 + " i:"+i) ;
			    payload[i % 8] = (byte) (payload[i % 8] ^ payload1[i]);
		    }
		
		    Tip.d("mac payload:"+ Util.byteArray2Hex(payload));
		    byte[] mac = {};
		    Tip.d("TCKEY: "+Util.byteArray2Hex(TCKEY));
            // 3DES encrypt the MAC plain value to get the final MAC value.
            mac = DES.encrypt(TCKEY, payload);
		
		    Tip.d("mac:"+Util.byteArray2Hex(mac));
		    return mac;
	    }

        /// <summary>
        /// Main function entry point for debugging, redundant for now.
        /// </summary>
        /// <param name="args"></param>
        public static void main(String[] args) {
		    byte[] paras = Util.HexStringToByteArray("3130303031323238");
		    Packet p = new Packet(paras.Length);
		
		    p.setCmdID((byte)0x10);
		    p.setCmdCode((byte)0x88);
		    p.setCmdSubCode((byte)0x06);
		    p.setTimeOut((byte)0x0A);
		    p.setDataField(paras);
		    p.buildCRC();
		    bool f = p.validCRC();
		    System.Diagnostics.Debug.Assert(f==true);
		    System.Diagnostics.Debug.WriteLine(Util.byteArray2Hex(p.getBytes()));

            System.Diagnostics.Debug.WriteLine(Util.byteArray2Hex(new byte[] { p.getByte(0) }));
		
	    }
    }
}
