﻿using System;

namespace SDK_LIB
{
    /// <summary>
    /// WaitSetAmount class implements a collection of methods to send user input transaction amount to the QPOS hardware.
    /// </summary>
    public class WaitSetAmount
    {
        /// <summary>
        /// Possible state of setting amount operation
        /// </summary>
        private static String CANCEL_AMOUNT = "CANCEL_AMOUNT";
	    private static String SET_AMOUNT = "SET_AMOUNT";
	    private static String WAITING_AMOUNT = "WAITING_AMOUNT";

        /// <summary>
        /// Private field to store the current set amount state, default to waiting amount
        /// </summary>
	    private String str_waitSetAmountState = WAITING_AMOUNT;

        /// <summary>
        /// Private field to store an instance of the QPOSService class
        /// </summary>
	    private QPOSService esc;

        /// <summary>
        /// CTOR
        /// </summary>
        /// <param name="esc">External QPOSService object</param>
	    public WaitSetAmount(QPOSService esc) {
		    this.esc = esc;
	    }

        /// <summary>
        /// Return the current state of wait set amount operation
        /// </summary>
        /// <returns>String that indicate the current state</returns>
	    private String getWaitSetAmountState() {
            return str_waitSetAmountState;
	    }

        /// <summary>
        /// Set the current state of wait set amount operation
        /// </summary>
        /// <param name="waitSetAmountState">Desired operation state that will be set</param>
	    private void setWaitSetAmountState(String waitSetAmountState) {
            this.str_waitSetAmountState = waitSetAmountState;
	    }

        /// <summary>
        /// Core function to perform the set transaction amount operation
        /// </summary>
        /// <returns>Boolean value to indicate if the operation is successful or not</returns>
        public bool waitSetAmountState()
        {
		    if(getWaitSetAmountState() == SET_AMOUNT){
                // If the current wait set amount state is SET_AMOUNT, then the operation has already been completed.
                return true;
		    }
		    setWaitSetAmountState(WAITING_AMOUNT); // Change the current state to WAITING_AMOUNT
            esc.onRequestSetAmount(); // Invoke the callback function to let the app to promote the user to set the transaction amount
            while (getWaitSetAmountState().Trim() == WAITING_AMOUNT) // Tasks will halt until the set transaction amount operation is complete
            {
                //Thread.Sleep(20);
                TaskSleeper.TaskSleep(20);
            }
		    Tip.d("getWaitSetAmountState = "+getWaitSetAmountState());	
		    if (getWaitSetAmountState() == CANCEL_AMOUNT) {
                // If the user decide to cancel the operation
                return false;
		    } else if (getWaitSetAmountState() == SET_AMOUNT) {
			    setWaitSetAmountState(WAITING_AMOUNT); // Operation complete, reset the internal state
                return true;
		    }	
		
		    return false;
	    }

        /// <summary>
        /// Set the current wait set amount state to CANCEL_AMOUNT
        /// </summary>
        public void cancelWaitSetAmount()
        {
		    Tip.d("cancelWaitSetAmount");
		    setWaitSetAmountState(CANCEL_AMOUNT);
	    }

        /// <summary>
        /// Set the current wait set amount state to SET_AMOUNT
        /// </summary>
        public void confirmWaitSetAmount()
        {
		    Tip.d("confirmWaitSetAmount");
		    setWaitSetAmountState(SET_AMOUNT);
	    }
    }
}
