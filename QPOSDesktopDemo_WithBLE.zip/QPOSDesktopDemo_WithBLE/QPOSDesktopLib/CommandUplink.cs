﻿using System;

namespace SDK_LIB
{
    /// <summary>
    /// Class that implements the Uplink command, which is the response message from the Device
    /// The Uplink command object which wraps around a communication packet
    /// for easier and more intuitive communication data management
    /// </summary>
    public class CommandUplink
    {
        /// <summary>
        /// Private data field to store an instant of Packet class
        /// </summary>
        private Packet p;

        /// <summary>
        /// CORT
        /// </summary>
        /// <param name="p">Packet Object to be passed to the instance</param>
        public CommandUplink(Packet p)
        {
            this.p = p;
        }

        /// <summary>
        /// Check if the device response is empty.
        /// </summary>
        /// <returns>Boolean value that indicate if the device response is empty</returns>
        public bool isEmpty()
        {
            return p.isEmpty();
        }

        /**
         * get the command name of the uplink command
         */
        /// <summary>
        /// Return the main command code replied from the QPOS device. 
        /// E.g. if the QPOS device responds to command 1620, then its response message should contain
        /// main command code 16
        /// </summary>
        /// <returns>A single byte that represents the main command code that the QPOS device responses to</returns>
        public byte commandCode()
        {
            return p.getCmdCode();
        }

        /**
         * get the subcommand name of the uplink command
         */
        /// <summary>
        /// Return the sub command code replied from the QPOS device. 
        /// E.g. if the QPOS device responds to command 1620, then its response message should contain
        /// sub command code 20
        /// </summary>
        /// <returns>A single byte that represents the sub command code that the QPOS device responses to</returns>
        public byte subCommandCode()
        {
            return p.getCmdSubCode();
        }

        /**
         * get the result value of the uplink command
         */
        /// <summary>
        /// get the device response result from Device Response Messsage
        /// </summary>
        /// <returns>Byte that used to indicate the device responses after execute a command. (e.g. success/fail/unknown)</returns>
        public byte result()
        {
            return p.getResultCode();
        }

        /// Get the byte from the device response message that indicate the device status after it receives the command.
        /// Refer to QPOS communication protocol CMDID table in Section 3
        /// </summary>
        /// <returns>Byte code that indicate the device status</returns>
        public byte commandID()
        {
            return p.getCmdID();
        }

        /**
         * get the length of the uplink command
         */
        /// <summary>
        /// Returns the length of the data frame payload.
        /// </summary>
        /// <returns>Integer number that tells the length of the data frame payload</returns>
        public int length()
        {
            return Util.byteArrayToInt(new byte[] { p.getByte(3), p.getByte(4) });
        }

        /**
         * get the byte value in a specific offset inside the uplink command
         */
        /// <summary>
        /// Returns a single byte from the response message data frame payload at the index specified by the offset value.
        /// </summary>
        /// <param name="offset">Index offset</param>
        /// <returns>The byte value from the data frame payload at specified index</returns>
        public byte getByte(int offset)
        {
            return p.getDataFieldByte(offset);
        }

        /**
         * get the byte array in a specific offset inside the uplink command
         */
        /// <summary>
        /// Return a byte array from the response message data frame payload given the index and length of the data selection.
        /// </summary>
        /// <param name="offset">Index offset</param>
        /// <param name="len">Length of the sub array</param>
        /// <returns>Byte array extracted from the data frame payload with specific index offset and size</returns>
        public byte[] getBytes(int offset, int len)
        {
            byte[] r = new byte[len];
            for (int i = 0; i < len; i++)
            {
                r[i] = p.getDataFieldByte(offset + i);
            }
            return r;
        }

        /// <summary>
        /// Return all data bytes within the response message.
        /// </summary>
        /// <returns>All data bytes within the reponse message.</returns>
        public byte[] getAllBytes()
        {
            return p.getBytes();
        }

        /// <summary>
        /// A wrap function to the CRC validation function in Packet Class.
        /// Check if a received device response is valid or not.
        /// </summary>
        /// <returns>Boolean value that indicates if the received response contains any errors</returns>
        public bool validCRC()
        {
            return p.validCRC();
        }

        /// <summary>
        /// Main function for debugging and testing this class implementation
        /// Redundant now.
        /// </summary>
        /// <param name="args"></param>
        public static void main(String[] args) 
        {
		    byte[] paras = Util.HexStringToByteArray("4D000E2188060A00083130303031323238E6");
				
		    CommandUplink cu = new CommandUplink(new Packet(paras));
		
		    byte[] bs = cu.getBytes(0, cu.length());
		    System.Diagnostics.Debug.WriteLine(Util.byteArray2Hex(bs));
		
		    System.Diagnostics.Debug.WriteLine(Util.byteArray2Hex(new byte[]{cu.commandID()}));
		
		
		    System.Diagnostics.Debug.WriteLine(Util.byteArray2Hex(new byte[]{cu.commandCode()}));
		
		
		    System.Diagnostics.Debug.WriteLine(Util.byteArray2Hex(new byte[]{cu.subCommandCode()}));
		
		    System.Diagnostics.Debug.WriteLine(Util.byteArray2Hex(new byte[]{cu.result()}));

            System.Diagnostics.Debug.WriteLine(cu.validCRC());
	    }
    }
}
