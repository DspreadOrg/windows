﻿using System;
using System.Threading.Tasks;
using Windows.Storage.Streams;
using Windows.Devices.SerialCommunication;
using Windows.Devices.Enumeration;

namespace SDK_LIB
{
    public class UsbSerial : VPos
    {
        private bool isOpen = false;
        private bool isWrite = false;
        private DeviceInformation deviceInformation;
        private SerialDevice device;
        private static UsbSerial g_Instance = null;
        private static byte[] blk = { };

        private UsbSerial()
        {
            disposed = false;
        }

        public static UsbSerial getInstance()
        {
            lock (blk)
            {
                if (g_Instance == null) g_Instance = new UsbSerial();
            }
            //
            return g_Instance;
        }

        
        public override bool open()
        {
            if (isOpen)
            {
                return true;
            }

            //
            try
            {
                Task<bool> tsk = openInternal();
                while ((!tsk.IsCanceled) && (!tsk.IsCompleted) && (!tsk.IsFaulted))
                {
                    tsk.Wait(10);
                }
                isOpen = true;
                return true;
            }
            catch (Exception e)
            {
                close();
                Tip.d("UsbSerial open Exception");
                return false;
            }
            //
        }

        private async Task<bool> openInternal()
        {
            bool bret = false;

            try
            {
                this.device = await SerialDevice.FromIdAsync(this.deviceInformation.Id);

                if (device != null)
                    return true;
            }
            catch (Exception e)
            {

            }

            return bret;
        }

        /*
        private async Task<bool> openInternal()
        {            
            bool bret = true;
            string serviceName = (String.IsNullOrWhiteSpace(peerinfo.ServiceName)) ? "1" : peerinfo.ServiceName;
            await socket.ConnectAsync(peerinfo.HostName, serviceName);            
            return bret;        
        }
        */

        public override void close()
        {
            try
            {
                setNeedQuit(true);
                
                // Slightly modified the logic to check if the device handler is null to begin with.
                // If the device handler has already point to null, then the following logic will be ignored.
                // The original logic dispose InputStream, OutputStream and Device Handler concurrently, which cause issue if the device handler is
                // already set to null (Disposed) 
                if (device != null)
                {
                    if (device.InputStream != null)
                    {
                        device.InputStream.Dispose();
                    }
                    if (device.InputStream != null)
                    {
                        device.InputStream.Dispose();
                    }
                    device.Dispose();
                    device = null;
                }
                isOpen = false;
            }
            catch (Exception e)
            {
                Tip.d("SerialPort close IOException");
            }
        }

        /// <summary>
        /// Add disconnect() method due to needs from Bluetooth Device.
        /// </summary>
        public override void disconnect()
        {
        }

        public override byte[] read()
        {
            byte[] b = new byte[0];
            try
            {
                if (!isWrite)
                {
                    Tip.d("SerialPort: write error");
                    return b;
                }

                b = readResponse();
                Tip.d("[read:" + Util.byteArray2Hex(b) + "]");
            }
            catch (Exception e)
            {
                b = new byte[0];
                Tip.d("SerialPort read IOException");
            }
            return b;
        }

        private byte[] readResponse()
        {
            byte[] lens = new byte[3];
            int len = 0;
            byte[] others = new byte[0];

            int backLen = 0;
            for (int i = 0; i < lens.Length;)
            {
                if (isNeedQuit())
                {
                    return new byte[0];
                }
                lens[i] = readInputStream();
                if (lens[0] == 'M')
                {
                    i++;
                }
            }

            len = lens[2];
            if (len < 0)
            {
                len = len + 256;
            }

            len += lens[1] * 256;

            backLen = len + 1 + 3;
            others = new byte[backLen];

            for (int i = 0; i < len + 1; i++)
            {
                if (isNeedQuit())
                {
                    return new byte[0];
                }
                others[3 + i] = readInputStream();
            }

            Array.Copy(lens, 0, others, 0, 3);
            return others;
        }

        private byte readInputStream()
        {
            byte result = 0;

            Task<int> tsk = readInternal();
            while ((!tsk.IsCanceled) && (!tsk.IsCompleted) && (!tsk.IsFaulted))
            {
                tsk.Wait(10);
            }
            int ret = tsk.Result;
            if (ret == 0x00ff0000)
            {
                do
                {
                    Tip.d("quit read");
                    if (isNeedQuit())
                    {
                        return result;
                    }
                    tsk = readInternal();
                    while ((!tsk.IsCanceled) && (!tsk.IsCompleted) && (!tsk.IsFaulted))
                    {
                        tsk.Wait(10);
                    }
                    ret = tsk.Result;
                } while (ret == 0x00ff0000);
            }
            result = (byte)ret;

            return result;
        }

        private async Task<int> readInternal()
        {
            int b = (int)(0x00ff0000);
            //DataReader _dataReader = new DataReader(ins);
            DataReader _dataReader = new DataReader(device.InputStream);
            try
            {
                await _dataReader.LoadAsync(1);
                b = (int)_dataReader.ReadByte();
            }
            catch (Exception e)
            {
                b = (int)(0x00ff0000);
            }
            _dataReader.DetachStream();
            _dataReader.Dispose();
            //
            return b;
        }

        private async Task<bool> writeInternal(byte[] msgArr)
        {
            //DataWriter _dataWriter = new DataWriter(outs);
            DataWriter _dataWriter = new DataWriter(device.OutputStream);
            _dataWriter.WriteBytes(msgArr);
            await _dataWriter.StoreAsync();
            //await _dataWriter.FlushAsync();
            _dataWriter.DetachStream();
            _dataWriter.Dispose();
            return true;
        }

        public override void write(byte[] msgArr)
        {
            isWrite = false;
            if (!isOpen) return;
            try
            {
                Task<bool> tsk = writeInternal(msgArr);
                tsk.Wait();
                /*
                while ((!tsk.IsCanceled) && (!tsk.IsCompleted) && (!tsk.IsFaulted))
                {
                    tsk.Wait(10);
                }
                */
                isWrite = true;
                Tip.d("[write:" + Util.byteArray2Hex(msgArr) + "]");
            }
            catch (Exception e)
            {
                Tip.d("UsbSerial write IOException");
            }
        }

        private bool disposed;
        public override void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    close();
                    g_Instance = null;
                }
                disposed = true;
            }
        }

        ~UsbSerial()
        {
            Dispose(false);
        }

        private String UsbSerialAddress = "";
        public String getUsbSerialAddress()
        {
            return UsbSerialAddress;
        }


        public void setUsbSerialAddress(DeviceInformation deviceInfo)
        {

            if (deviceInfo == null)
            {
                return;
            }

            deviceInformation = deviceInfo;

        }

        /*
        private async Task<bool> setUsbSerialAddressInternal(String UsbSerialAddress)
        {
            /*
            bool flag;
            this.UsbSerialAddress = UsbSerialAddress;
            if (this.UsbSerialAddress == null || this.UsbSerialAddress == "")
            {
                close();
                //
                peerinfo = null;
                deviceService = null;                
            }

            Task<bool> tk = scanBTD(UsbSerialAddress);
            flag =  await tk;
            //tk.Wait();
            //flag = await tk;
    //        if (flag == false)
            {
                System.Diagnostics.Debug.WriteLine("No devices were found.");
            }
            */
        /*          
    //  return true;
  }
  */

        /*
        private async Task<bool> setUsbSerialAddressInternal(String UsbSerialAddress)
        {
            
            this.UsbSerialAddress = UsbSerialAddress;
            if (this.UsbSerialAddress == null || this.UsbSerialAddress == "")
            {
                close();
                //
                peerinfo = null;
            }
            //
            PeerFinder.AlternateIdentities["Bluetooth:Paired"] = "";
            var pairedDevices = await PeerFinder.FindAllPeersAsync();

            if (pairedDevices.Count == 0)
            {
                System.Diagnostics.Debug.WriteLine("No paired devices were found.");
            }
            else
            {
                IEnumerable<PeerInformation> items = (from c in pairedDevices where c.DisplayName.Equals(UsbSerialAddress) select c);
                if (items.Count() <= 0)
                {
                    this.UsbSerialAddress = "";
                }
                else
                {
                    peerinfo = null;
                    peerinfo = items.ElementAt(0);
                }
            } 
            //
            return true;
        }
        */

    }
}
