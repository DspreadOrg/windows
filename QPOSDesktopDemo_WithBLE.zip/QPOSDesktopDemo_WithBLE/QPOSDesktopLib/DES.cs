﻿namespace SDK_LIB
{
    /// <summary>
    /// DES class implements DES encryption/decryption by calling the API implemented in Crypto package.
    /// </summary>
    public class DES
    {
        /**
	     * 加密函数 　　
	     * @param data 加密数据 　　
	     * @param key  密钥 　　
	     * @return 返回加密后的数据 　
	     */
        /// <summary>
        /// DES Encryption
        /// </summary>
        /// <param name="key">Key</param>
        /// <param name="data">Data will be encrypted</param>
        /// <returns>Array of encrypted data bytes</returns>
        public static byte[] encrypt(byte[] key, byte[] data) {

            Org.BouncyCastle.Crypto.Engines.DesEngine desEngine = new Org.BouncyCastle.Crypto.Engines.DesEngine();
            Org.BouncyCastle.Crypto.BufferedBlockCipher bufferedCipher = new Org.BouncyCastle.Crypto.BufferedBlockCipher(desEngine);
            Org.BouncyCastle.Crypto.Parameters.DesParameters keyParamter = new Org.BouncyCastle.Crypto.Parameters.DesParameters(key);
            bufferedCipher.Init(true, keyParamter);
            return bufferedCipher.DoFinal(data);
	    }

        /**
            * 解密函数 　　 　　
            * @param data 解密数据 　　
            * @param key 密钥 　　
            * @return	返回解密后的数据 
            */
        /// <summary>
        /// DES Decryption
        /// </summary>
        /// <param name="key">Key</param>
        /// <param name="data">Data will be decrypted</param>
        /// <returns>Array of decrypted data bytes</returns>
        public static byte[] decrypt(byte[] key, byte[] data) {

            Org.BouncyCastle.Crypto.Engines.DesEngine desEngine = new Org.BouncyCastle.Crypto.Engines.DesEngine();
            Org.BouncyCastle.Crypto.BufferedBlockCipher bufferedCipher = new Org.BouncyCastle.Crypto.BufferedBlockCipher(desEngine);
            Org.BouncyCastle.Crypto.Parameters.DesParameters keyParamter = new Org.BouncyCastle.Crypto.Parameters.DesParameters(key);
            bufferedCipher.Init(false, keyParamter);
            return bufferedCipher.DoFinal(data);
	    }
    }
}
