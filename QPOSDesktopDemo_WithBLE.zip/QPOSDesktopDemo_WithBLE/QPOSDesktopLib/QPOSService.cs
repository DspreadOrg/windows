﻿using System;
//using System.Windows.Threading;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Collections;
using Windows.Devices.Enumeration;
using Windows.Devices.Bluetooth.Rfcomm;
using SDK_LIB;
using Windows.Devices.SerialCommunication;
using Windows.Devices.Bluetooth;

namespace SDK_LIB
{
    public class QPOSService : IDisposable
    {
        #region Static variables
        public static string service_uuid = "49535343-fe7d-4ae5-8fa9-9fafd205e455";
        public static string write_uuid = "49535343-8841-43f4-a8d4-ecbe34729bb3";
        public static string notify_uuid = "49535343-1e4d-4bd9-ba61-23c647249616";
        #endregion

        private static QPOSService g_Instance = null;
        private static byte[] blk = { };

        //private Thread thd_Business;
        private EventWaitHandle evt_Business_Dispatch;
        private List<int> queue_Business;
        private byte[] lk_Business;


        private static String SDK_VERSION = "1.7.6";
	    private static bool qf_sdk = false;
	    private DataFormat dataFormat = DataFormat.OLD;

        private WaitSetAmount waitSetAmount;
        private bool posExistFlag = false;  //should be false, must be set by monitoring headset plugin.
        private bool terminalTimeFlag = false;

        private EmvOption emvOption;
        private VPos pos = null;
        
        private bool tradeFlag = false;
        private String tradeAmount = "";
        private String amountDescribe = "";
        private String tradeType;
        private String terminalTime = "";
        private String currencyCode = "";

        private String randomString = "";
        private String extraString = "";
        private int tradeMode = 0;
        private int selectEmvAppIndex = 0;
        private String updateFirmwareStr = "";
        private String amountIcon = "";
        private String pinTransactionData = "";
        private String lcdShowCustomDisplayStr = "";
        private String apduString = "";
        private int sleepTimeout;
        private String customParamStr = "";
        private int customParamStringSize = 0;
        private int customParamStrOffset = 0;
        private int do_trade_timeout = 60;
        private String pinStr = "";
       private int keyIndex = 0;
        private static bool isKeyboard = true;

        private bool posInputAmountFlag = false;
        private bool posDisplayAmountFlag = true;
        private String customDisplayString = "";
        private String deviceCommandString = "";

        private DoEmvApp dea;
        private DoTrade dt;
        private GetPosInfo gpi;
        private UpdateFirmware uf;
        private Signature sig;
        private IccApdu iccApdu;
        private GetCardNo gcn;
        private SaveCustomParam scp;

        private QPOSServiceListener aCallBackListener;

        private QPOSService()
        {
            aCallBackListener = null;
            startBusinessDispatcher();
            //
            dea = new DoEmvApp(this);
            dt = new DoTrade(this);
            gpi = new GetPosInfo(this);
            waitSetAmount = new WaitSetAmount(this);
            uf = new UpdateFirmware(this);
            sig = new Signature(this);
            iccApdu = new IccApdu(this);
            gcn = new GetCardNo(this);
            scp = new SaveCustomParam(this);

            do_trade_timeout = 60;
            isKeyboard = true;
        }

        private void runBusiDisp()
        {
            while (true)
            {
                int iMsg = -1;
                evt_Business_Dispatch.WaitOne();    
                evt_Business_Dispatch.Reset();
                lock (lk_Business)
                {
                    iMsg = queue_Business[0];
                    queue_Business.RemoveAt(0);
                }
                //
                if (iMsg != -1)
                {
                    if (doBusiness(iMsg) == 0) break;
                }
            }
        }

        private void startBusinessDispatcher()
        {
            lk_Business = new byte[0];
            queue_Business = new List<int>();
            evt_Business_Dispatch = new EventWaitHandle(false, EventResetMode.ManualReset);
            Task.Run(() =>
            {
                runBusiDisp();
            });
            /*
            thd_Business = new Thread(new ThreadStart(runBusiDisp));
            thd_Business.Start();
            */
        }

        private void stopBusinessDispatcher()
        {
            removeAllMsg();
            sendMsg(0);
            /*
            thd_Business.Join();
            thd_Business = null;            
            evt_Business_Dispatch.Close();
            */
            evt_Business_Dispatch.Dispose();
            evt_Business_Dispatch = null;           
            queue_Business = null;
            lk_Business = null;
        }

        private void sendMsg(int what)
        {
            lock (lk_Business)
            {
                queue_Business.Add(what);
            }
            evt_Business_Dispatch.Set();
        }

        private void removeMsg(int what)
        {
            lock (lk_Business)
            {
                queue_Business.RemoveAll(name =>
                    {
                        return (what == name) ? true : false;
                    });
            }
        }

        private void removeAllMsg()
        {
            lock (lk_Business)
            {
                queue_Business.Clear();
            }
        }

        private int doBusiness(int aBusinessID)
        {
            int iret = 1;
            if (aBusinessID == 0)
            {
                iret = 0;
                return iret;
            }
            //
            switch (aBusinessID)
            {
                case TradeMsg.MSG_DO_TRADE:
                    Tip.d("TradeMsg.MSG_DO_TRADE");
                    try
                    {
                        doTrade__();
                        //							testECHO();
                    }
                    catch (Exception e)
                    {
                        onError(Error.DO_TRADE_ICC_EXCECPTION);
                        disConnect();
                    }

                    break;
                case TradeMsg.MSG_DO_TRADE_QF:
                    try
                    {
                        doTrade_QF__();
                    }
                    catch (Exception e)
                    {
                        onError(Error.DO_TRADE_ICC_EXCECPTION);
                        disConnect();
                    }
                    break;
                case TradeMsg.MSG_DO_EMV_APP:
                    try
                    {
                        doEmvTrade__();
                    }
                    catch (Exception e)
                    {
                        onError(Error.DO_TRADE_ICC_EXCECPTION);
                        disConnect();
                    }
                    break;
                case TradeMsg.MSG_GET_POS_ID:
                    try
                    {
                        doGetPosId();
                    }
                    catch (Exception e)
                    {
                        onError(Error.UNKNOWN);
                        disConnect();
                    }
                    break;
                    case TradeMsg.MSG_GET_POS_RSA:
                    try
                    {
                        doGetPosRsa();
                    }
                    catch (Exception e)
                    {
                        onError(Error.UNKNOWN);
                        disConnect();
                    }
                    break;
                case TradeMsg.MSG_SET_FORMAT_ID:
                    try
                    {
                        doSetFormatID();
                    }
                    catch (Exception e)
                    {
                        onError(Error.UNKNOWN);
                        disConnect();
                    }
                    break; 
                case TradeMsg.MSG_GET_POS_INFO:
                    try
                    {
                        doGetPosInfo();
                    }
                    catch (Exception e)
                    {
                        onError(Error.UNKNOWN);
                        disConnect();
                    }
                    break;
                case TradeMsg.MSG_UPDATE_FIRMWARE:
                    try
                    {
                        doUpdateFirmware();
                    }
                    catch (Exception e)
                    {
                        onError(Error.UNKNOWN);
                        disConnect();
                    }
                    break;
                case TradeMsg.MSG_SIGNATURE:
                    try
                    {
                        doSignature();
                    }
                    catch (Exception e)
                    {
                        onError(Error.UNKNOWN);
                        disConnect();
                    }
                    break;
                case TradeMsg.MSG_GET_PIN:
                    try
                    {
                        doGetPin();
                    }
                    catch (Exception e)
                    {
                        onError(Error.UNKNOWN);
                        disConnect();
                    }
                    break;
                case TradeMsg.MSG_EXIT_TRADE:
                    try
                    {
                        onError(Error.DEVICE_BUSY);
                        bool f = exit();
                    }
                    catch (Exception e)
                    {
                        onError(Error.UNKNOWN);
                    }
                    disConnect();
                    //
                    resetState = ResetState.RESETED;
                    //
                    break;
                case TradeMsg.MSG_CONNECTED_BLUETOOTH:
                    try
                    {
                        //							Tip.d("connect bluetooth start");
                        bool f = connect(1);
                        //							Tip.d("connect bluetooth end");
                        if (f)
                        {
                            setPosExistFlag(true);
                            onRequestQposConnected();
                        }
                    }
                    catch (Exception e)
                    {
                        onError(Error.UNKNOWN);
                    }
                    disConnect();
                    break;
                // Newly added case for execute procedures to connect to Bluetooth LE device
                // Added on 29th January 2018 by Sheng Zhang
                case TradeMsg.MSG_CONNECTED_BLUETOOTH_LE:
                    try
                    {
                        Tip.d("Connect bluetooth LE start");
                        bool f = connect(1);
                        Tip.d("Connect bluetooth LE end");
                        if (f)
                        {
                            setPosExistFlag(true);
                            onRequestQposConnected();
                        }
                    }
                    catch (Exception e)
                    {

                        onError(Error.UNKNOWN);
                    }
                    disConnect();
                    break;
                case TradeMsg.MSG_CONNECTED_USBSERIAL:
                    try
                    {
                        //							Tip.d("connect usb serial start");
                        bool f = connect(1);
                        //							Tip.d("connect usb serial end");
                        if (f)
                        {
                            setPosExistFlag(true);
                            onRequestQposConnected();
                        }
                    }
                    catch (Exception e)
                    {
                        onError(Error.UNKNOWN);
                    }
                    disConnect();
                    break;
                case TradeMsg.MSG_POWER_ON_ICC:
                    try
                    {
                        doPowerOnIcc();
                    }
                    catch (Exception e)
                    {
                        onError(Error.UNKNOWN);
                        disConnect();
                    }
                    break;
                case TradeMsg.MSG_POWER_OFF_ICC:
                    try
                    {
                        doPowerOffIcc();
                    }
                    catch (Exception e)
                    {
                        onError(Error.UNKNOWN);
                        disConnect();
                    }
                    break;
                case TradeMsg.MSG_SEND_APDU:
                    try
                    {
                        doSendApdu();
                    }
                    catch (Exception e)
                    {
                        onError(Error.UNKNOWN);
                        disConnect();
                    }
                    break;
                case TradeMsg.MSG_SET_SLEEP_TIME:
                    try
                    {
                        doSetSleepTime();
                    }
                    catch (Exception e)
                    {
                        onError(Error.UNKNOWN);
                        disConnect();
                    }
                    break;
                case TradeMsg.MSG_GET_CARDNO:
                    try
                    {
                        doGetCardNo();
                    }
                    catch (Exception e)
                    {
                        onError(Error.UNKNOWN);
                        disConnect();
                    }
                    break;
                    case TradeMsg.MSG_GET_PIN1071:
                    try
                    {
                        doGetPin1071();
                    }
                    catch (Exception e)
                    {
                        onError(Error.UNKNOWN);
                        disConnect();
                    }
                    break;
                case TradeMsg.MSG_LCD_SHOW_CUSTOM_DISPLAY:
                    try
                    {
                        doLcdShowCustomDisplay__();
                    }
                    catch (Exception e)
                    {
                        onError(Error.UNKNOWN);
                        disConnect();
                    }
                    break;

                case TradeMsg.MSG_UPDATE_FIRMWARE_TMK_ZZ:
                    try
                    {
                        doUpdateFirmware_tmk_zz();
                    }
                    catch (Exception e)
                    {
                        onError(Error.UNKNOWN);
                        disConnect();
                    }
                    break;
                case TradeMsg.MSG_CALCULATE_MAC:
                    try
                    {
                        doCalculateMac();
                    }
                    catch (Exception e)
                    {
                        onError(Error.UNKNOWN);
                        disConnect();
                    }
                    break;
                case TradeMsg.MSG_UPDATE_EMV_APP_CONFIG:
                    try
                    {
                        doUpdateEmvAppConfig();
                    }
                    catch (Exception e)
                    {
                        onError(Error.UNKNOWN);
                        disConnect();
                    }
                    break;
                case TradeMsg.MSG_UPDATE_EMV_CAPK_CONFIG:
                    try
                    {
                        doUpdateEmvCapkConfig();
                    }
                    catch (Exception e)
                    {
                        onError(Error.UNKNOWN);
                        disConnect();
                    }
                    break;
                case TradeMsg.MSG_READ_EMV_APP_CONFIG:
                    try
                    {
                        doReadEmvAppConfig();
                    }
                    catch (Exception e)
                    {
                        onError(Error.UNKNOWN);
                        disConnect();
                    }
                    break;
                case TradeMsg.MSG_READ_EMV_CAPK_CONFIG:
                    try
                    {
                        doReadEmvCapkConfig();
                    }
                    catch (Exception e)
                    {
                        onError(Error.UNKNOWN);
                        disConnect();
                    }
                    break;
                case TradeMsg.MSG_UPDATE_EMV_CONFIG:
                    try
                    {
                        doUpdateEmvConfig();
                    }
                    catch (Exception e)
                    {
                        onError(Error.UNKNOWN);
                        disConnect();
                    }
                    break;
                case TradeMsg.MSG_GET_ICC_EMV_DATA:
                    try
                    {
                        doGetIccEmvData();
                    }
                    catch (Exception e)
                    {
                        onError(Error.UNKNOWN);
                        disConnect();
                    }
                    break;
                case TradeMsg.MSG_SET_MASTER_KEY:
                    try
                    {
                        doSetMasterKey();
                    }
                    catch (Exception e)
                    {
                        onError(Error.UNKNOWN);
                        disConnect();
                    }
                    break;
                default:
                    break;
            }
            //
            return iret;
        }

        public void initListener(QPOSServiceListener aListener)
        {
            aCallBackListener = aListener;
        }

        public void onRequestSetAmount()
        {
		   // need implement to do callback upto mainloop;
           // Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate()
           //     {
                    if (aCallBackListener != null) aCallBackListener.onRequestSetAmount();
           //     } );
	    }

        public void onError(Error errorState)
        {
            // need implement to do callback upto mainloop;            
           // Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
           // {
                    if (aCallBackListener != null) aCallBackListener.onError(errorState);
            //    });
        }        

        public void onRequestDisplay(Display displayMsg)
        {
            // need implement to do callback upto mainloop;
           // Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
           // {
                if (aCallBackListener != null) aCallBackListener.onRequestDisplay(displayMsg);
           // });
        }

        public void onDoTradeResult(DoTradeResult result, Dictionary<String, String> decodeData)
        {
            // need implement to do callback upto mainloop;
           // Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
           // {
                if (aCallBackListener != null) aCallBackListener.onDoTradeResult(result, decodeData);
           // });
        }
        
	    public void onRequestSelectEmvApp(List<String> appList)
        {
            //Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
           // {
                if (aCallBackListener != null) aCallBackListener.onRequestSelectEmvApp(appList);
           // });
	    }

	    public void onRequestFinalConfirm()
        {
            // need implement to do callback upto mainloop;
           // Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
           // {
                if (aCallBackListener != null) aCallBackListener.onRequestFinalConfirm();
            //});
        }

	    public void onQposInfoResult(Dictionary<String, String> deviceInfoData)
        {
            // need implement to do callback upto mainloop;
            //Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
            //{
                if (aCallBackListener != null) aCallBackListener.onQposInfoResult(deviceInfoData);
            //});
        }

	    public void onRequestOnlineProcess(String tlv)
        {
            // need implement to do callback upto mainloop;
            //Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
            //{
                if (aCallBackListener != null) aCallBackListener.onRequestOnlineProcess(tlv);
           // });
        }

	    public void onRequestIsServerConnected()
        {
            // need implement to do callback upto mainloop;
            //Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
            //{
                if (aCallBackListener != null) aCallBackListener.onRequestIsServerConnected();
           // });
        }

	    public void onRequestTime()
        {
            // need implement to do callback upto mainloop;
            //Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
            //{
                if (aCallBackListener != null) aCallBackListener.onRequestTime();
            //});
        }

	    public void onRequestTransactionResult(TransactionResult transactionResult)
        {
            // need implement to do callback upto mainloop;
            //Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
            //{
                if (aCallBackListener != null) aCallBackListener.onRequestTransactionResult(transactionResult);
            //});
        }

	    public void onRequestTransactionLog(String tlv)
        {
            // need implement to do callback upto mainloop;
           // Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
           // {
                if (aCallBackListener != null) aCallBackListener.onRequestTransactionLog(tlv);
           // });
        }

	    public void onRequestBatchData(String tlv)
        {
            // need implement to do callback upto mainloop;
            //Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
            //{
                if (aCallBackListener != null) aCallBackListener.onRequestBatchData(tlv);
           // });
        }

	    public void onRequestQposConnected()
        {
            // need implement to do callback upto mainloop;
            //Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
            //{
                if (aCallBackListener != null) aCallBackListener.onRequestQposConnected();
            //});
        }

	    public void onRequestQposDisconnected()
        {
            // need implement to do callback upto mainloop;
            //Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
            //{
                if (aCallBackListener != null) aCallBackListener.onRequestQposDisconnected();
            //});
        }

	    public void onRequestNoQposDetected()
        {
            // need implement to do callback upto mainloop;
            //Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
            //{
                if (aCallBackListener != null) aCallBackListener.onRequestNoQposDetected();
           // });
        }

        public void onRequestWaitingUser()
        {
            // need implement to do callback upto mainloop;
            //Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
           // {
                if (aCallBackListener != null) aCallBackListener.onRequestWaitingUser();
            //});
        }

        public void onRequestSetPin()
        {
            // need implement to do callback upto mainloop;
           // Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
           // {
                if (aCallBackListener != null) aCallBackListener.onRequestSetPin();
            //});
        }
	
	    public void onReturnCustomConfigResult(bool isSuccess, String result)
        {
            // need implement to do callback upto mainloop;
           // Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
            //{
                if (aCallBackListener != null) aCallBackListener.onReturnCustomConfigResult(isSuccess, result);
            //});
        }

        public void onRequestCalculateMac(String calMac)
        {
            // need implement to do callback upto mainloop;
            //Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
            //{
                if (aCallBackListener != null) aCallBackListener.onRequestCalculateMac(calMac);
           // });
        }

        public void onReturniccCashBack(Hashtable result)
        {
            // need implement to do callback upto mainloop;
            //Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
            //{
            if (aCallBackListener != null) aCallBackListener.onReturniccCashBack(result);
            // });
        }

        public void onGetCardNoResult(String cardNo)
        {
            // need implement to do callback upto mainloop;
           // Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
            //{
                if (aCallBackListener != null) aCallBackListener.onGetCardNoResult(cardNo);
            //});
        }
	
	    public void onReturnSetSleepTimeResult(bool isSuccess)
        {
            // need implement to do callback upto mainloop;
            //Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
            //{
                if (aCallBackListener != null) aCallBackListener.onReturnSetSleepTimeResult(isSuccess);
            //});
        }
	
	    public void onReturnApduResult(bool isSuccess, String apdu, int apduLen)
        {
            // need implement to do callback upto mainloop;
            //Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
            //{
                if (aCallBackListener != null) aCallBackListener.onReturnApduResult(isSuccess, apdu, apduLen);
            //});
        }
	
	    public void onReturnPowerOffIccResult(bool isSuccess)
        {
            // need implement to do callback upto mainloop;
           // Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
            //{
                if (aCallBackListener != null) aCallBackListener.onReturnPowerOffIccResult(isSuccess);
            //});
        }
	
	    public void onReturnPowerOnIccResult(bool isSuccess, String ksn,  String atr, int atrLen)
        {
            // need implement to do callback upto mainloop;
            //Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
            //{
                if (aCallBackListener != null) aCallBackListener.onReturnPowerOnIccResult(isSuccess, ksn, atr, atrLen);
            //});
        }

	    public void onReturnGetPinResult(Dictionary<String, String> result)
        {
            // need implement to do callback upto mainloop;
            //Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
            //{
                if (aCallBackListener != null) aCallBackListener.onReturnGetPinResult(result);
           // });
        }
	
	    public void onReturnReversalData(String  tlv)
        {
            /// need implement to do callback upto mainloop;
            //Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
           // {
                if (aCallBackListener != null) aCallBackListener.onReturnReversalData(tlv);
           // });
        }
	
	    public void onRequestUpdateWorkKeyResult(UpdateInformationResult result)
        {
            // need implement to do callback upto mainloop;
            //Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
           // {
                if (aCallBackListener != null) aCallBackListener.onRequestUpdateWorkKeyResult(result);
           // });
        }

        public void onRequestSignatureResult(byte[] paras)
        {
            // need implement to do callback upto mainloop;
            //Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
            //{
                if (aCallBackListener != null) aCallBackListener.onRequestSignatureResult(paras);
            //});
        }

        public void onQposIdResult(Dictionary<String, String> posId)
        {
            // need implement to do callback upto mainloop;
            //Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
            //{
                if (aCallBackListener != null) aCallBackListener.onQposIdResult(posId);
            //});
            //ThreadStart threadDelegate = new ThreadStart(() =>
            //{
            //    aCallBackListener.onQposIdResult(posId);
            //}
            //    );
            //Thread newThread = new Thread(threadDelegate);
            //newThread.Start();
        }

        public void onQposRSAResult(String RSAresult)
        {
            // need implement to do callback upto mainloop;
            //Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
            //{
            if (aCallBackListener != null) aCallBackListener.onQposRSAResult(RSAresult);
            //});
            //ThreadStart threadDelegate = new ThreadStart(() =>
            //{
            //    aCallBackListener.onQposIdResult(posId);
            //}
            //    );
            //Thread newThread = new Thread(threadDelegate);
            //newThread.Start();
        }

        public void onQposSendRawCommand(bool isSuccess)
        {
            // need implement to do callback upto mainloop;
            //Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
            //{
            if (aCallBackListener != null) aCallBackListener.onReturnSendDeviceCommandString(isSuccess);
            //});
            //ThreadStart threadDelegate = new ThreadStart(() =>
            //{
            //    aCallBackListener.onQposIdResult(posId);
            //}
            //    );
            //Thread newThread = new Thread(threadDelegate);
            //newThread.Start();
        }

        public void onReturnSetMasterKeyResult(bool isSuccess)
        {
            // need implement to do callback upto mainloop;
            //Dispatcher.CurrentDispatcher.BeginInvoke((Action)delegate ()
           // {
                if (aCallBackListener != null) aCallBackListener.onReturnSetMasterKeyResult(isSuccess);
           // });
        }
        
        public String getPinStr()
        {
            return pinStr;
        }

        private void setPinStr(String pinStr)
        {
            this.pinStr = pinStr;
        }        

        public EmvOption getEmvOption()
        {
            return emvOption;
        }

        public void setEmvOption(EmvOption emvOption)
        {
            this.emvOption = emvOption;
        }

        private String getLcdShowCustomDisplayStr()
        {
            return lcdShowCustomDisplayStr;
        }

        private void setLcdShowCustomDisplayStr(String lcdShowCustomDisplayStr)
        {
            this.lcdShowCustomDisplayStr = lcdShowCustomDisplayStr;
        }

        private String getUpdateFirmwareStr()
        {
            return updateFirmwareStr;
        }

        private void setUpdateFirmwareStr(String updateFirmwareStr)
        {
            this.updateFirmwareStr = updateFirmwareStr;
        }

        private bool isPosExistFlag()
        {
            return posExistFlag;
        }

        private void setPosExistFlag(bool posExistFlag)
        {
            this.posExistFlag = posExistFlag;
        }

        public bool isTradeFlag()
        {
            return tradeFlag;
        }

        private void setTradeFlag(bool tradeFlag)
        {
            Tip.d("set Trade Flag = " + tradeFlag);
            this.tradeFlag = tradeFlag;
        }

        public int getSelectEmvAppIndex()
        {
            return selectEmvAppIndex;
        }

        public void setSelectEmvAppIndex(int selectEmvAppIndex)
        {
            this.selectEmvAppIndex = selectEmvAppIndex;
        }

        private ResetState resetState = ResetState.INIT;
        private enum ResetState
        {
            INIT,
            RESETING,
            RESETED,
        }

        private DoTradeMode doTradeMode = DoTradeMode.COMMON;
        public DoTradeMode getDoTradeMode()
        {
            return doTradeMode;
        }

        private void setDoTradeMode(DoTradeMode doTradeMode)
        {
            this.doTradeMode = doTradeMode;
        }

         private CardTradeMode cardTradeMode = CardTradeMode.SWIPE_INSERT_CARD;
        public CardTradeMode getCardTradeMode()
        {
            return cardTradeMode;
        }
        public enum CardTradeMode
        {
            ONLY_INSERT_CARD, ONLY_SWIPE_CARD, SWIPE_INSERT_CARD,
            UNALLOWED_LOW_TRADE, SWIPE_TAP_INSERT_CARD,
            SWIPE_TAP_INSERT_CARD_UNALLOWED_LOW_TRADE,
            ONLY_TAP_CARD
        }

        public void setCardTradeMode(CardTradeMode cardTradeMode)
        {
            int i = 0;
            // 确保上次的disconnect关闭
            if (disconnectState == DisconnectState.DISCONNECTING)
            {
                while (true)
                {
                    if (disconnectState == DisconnectState.DISCONNECTED)
                    {
                        break;
                    }
                    else if (disconnectState == DisconnectState.UNKNOW)
                    {
                        return;
                    }
                    try
                    {
                        //Thread.Sleep(10);
                    }
                    catch (Exception e)
                    {
                        Tip.d("setCardTradeMode exception " + e.StackTrace);
                    }
                    if (i++ == 200)
                    {
                        break;
                    }
                }
            }

            i = 0;
            while (isTradeFlag())
            {
                try
                {
                    //Thread.Sleep(10);
                }
                catch (Exception e)
                {
                    Tip.d("setCardTradeMode exception " + e.StackTrace);
                }
                if (i++ == 200)
                {
                    return;
                }
                disConnect();
            }
            this.cardTradeMode = cardTradeMode;
        }

        public bool exit_pos_trade(VPos pos)
        {
            CommandDownlink dc = new CommandDownlink(CmdId.CMDID_RESET, 0x00, 0x00, 5);
            pos.sendCommand(dc);
            CommandUplink uc = pos.receiveCommandWaitResult(5);
            bool f = checkCmdId(uc);
            return f;

        }

         public CommandUplink inquireResult(VPos pos)
        {
            CommandDownlink dc = new CommandDownlink(CmdId.CMDID_QUERY, 0, 0, 30);
            pos.sendCommand(dc);
            CommandUplink uc = pos.receiveCommandWaitResult(30);
            return uc;
        }

        public bool exit_pos_trade(VPos pos, bool isCheckCmd)
        {
            CommandDownlink dc = new CommandDownlink(CmdId.CMDID_RESET, 0x00, 0x00, 5);
            pos.sendCommand(dc);
            CommandUplink uc = pos.receiveCommandWaitResult(5);
            bool f = true;
            if (isCheckCmd)
            {
                f = checkCmdId(uc);
            }
            return f;

        }

        public bool checkCmdId(CommandUplink uc)
        {
            bool rf = false;
            if (uc == null)
            {
                if (resetState != ResetState.RESETING)
                {
                    rf = false;
                    exit_pos_trade(pos, false);
                    onError(Error.TIMEOUT);
                }
            }
            else
            {
                if (uc.commandID() == CmdId.CMDID_COMPLETED)
                {
                    rf = true;
                }
                else
                {
                    rf = false;
                    if (uc.commandID() == CmdId.CMDID_DESTRUCT)
                    {
                        // onError(Error.DEVICE_DESTRUCT);
                        onRequestTransactionResult(TransactionResult.DEVICE_ERROR);
                        //					onDoTradeResult(doTradeResult.BAD_SWIPE,null);
                        // Tip.d("设备自毁");
                    }
                    else if (uc.commandID() == CmdId.CMDID_INPUT_PIN_ING)
                    {
                        rf = true;
                        if (uc.length()>0)
                        {
                            if (uc.getByte(0) == 0)
                            {
                                onRequestDisplay(Display.INPUT_PIN_ING);
                               
                            }
                            else
                            {
                                onRequestDisplay(Display.INPUT_OFFLINE_PIN_ONLY);
                               
                            }
                            
                        }
                        else
                        {
                            onRequestDisplay(Display.INPUT_PIN_ING);
                        }
                        
                        
                    }
                    else if (uc.commandID() == CmdId.CMDID_MAG_TO_ICC_TRADE)
                    {
                        onRequestDisplay(Display.MAG_TO_ICC_TRADE);
                        rf= true;
                    }
                    else if (uc.commandID() == CmdId.CMDID_TIMEOUT)
                    {
                        onError(Error.CMD_TIMEOUT);
                    }
                    else if (uc.commandID() == CmdId.CMDID_USERCANCEL)
                    {
                        // onError(Error.USER_CANCEL);
                        onRequestDisplay(Display.TRANSACTION_TERMINATED);
                        onRequestTransactionResult(TransactionResult.CANCEL);
                    }
                    else if (uc.commandID() == CmdId.CMDID_MACERROR)
                    {
                        onError(Error.MAC_ERROR);
                    }
                    else if (uc.commandID() == CmdId.CMDID_EMV_TRANS_DENIAL)
                    {
                        onRequestTransactionResult(TransactionResult.DECLINED);

                    }
                    else if (uc.commandID() == CmdId.CMDID_EMV_TRANS_TERMINATE)
                    {
                        onRequestDisplay(Display.TRANSACTION_TERMINATED);
                        onRequestTransactionResult(TransactionResult.TERMINATED);

                    }
                    else if (uc.commandID() == CmdId.CMDID_NOT_AVAILABLE)
                    {
                        onError(Error.CMD_NOT_AVAILABLE);

                    }
                    else if (uc.commandID() == CmdId.CMDID_OLD)
                    {
                        onError(Error.CMD_NOT_AVAILABLE);
                    }
                    else if (uc.commandID() == CmdId.CMDID_RESET)
                    {
                        rf = true;
                        onError(Error.DEVICE_RESET);
                    }
                    else if (uc.commandID() == CmdId.CMDID_ICC_POWER_ON_ERROR)
                    {//icc卡上电失败
                        Tip.i("POS_SDK : CmdId.CMDID_ICC_POWER_ON_ERROR," + CmdId.CMDID_ICC_POWER_ON_ERROR);
                        onDoTradeResult(DoTradeResult.NOT_ICC, null);
                    }
                    else if (uc.commandID() == CmdId.CMDID_WR_DATA_ERROR)
                    { //读/写数据失败
                        onError(Error.WR_DATA_ERROR);
                    }
                    else if (uc.commandID() == CmdId.CMDID_EMV_APP_CFG_ERROR)
                    {//emv app 配置错误
                        onError(Error.EMV_APP_CFG_ERROR);
                    }
                    else if (uc.commandID() == CmdId.CMDID_EMV_CAPK_CFG_ERROR)
                    {////emv capk 配置错误
                        onError(Error.EMV_CAPK_CFG_ERROR);
                    }
                    else if (uc.commandID() == CmdId.CMDID_NO_UPDATE_WORK_KEY)
                    {
                        onDoTradeResult(DoTradeResult.NO_UPDATE_WORK_KEY, null);
                    }
                    else
                    {
                        rf = false;
                        if(uc.commandID() == CmdId.CMDID_DESTRUCT)
                        {
                            onRequestTransactionResult(TransactionResult.DEVICE_ERROR);
                        }
                        else if (uc.commandID() == CmdId.CMDID_TIMEOUT)
                        {
                            onError(Error.CMD_TIMEOUT);
                        }
                        else if (uc.commandID() == CmdId.CMDID_USERCANCEL)
                        {
                            // onError(Error.USER_CANCEL);
                            onRequestDisplay(Display.TRANSACTION_TERMINATED);
                            onRequestTransactionResult(TransactionResult.CANCEL);

                        }
                        else if (uc.commandID() == CmdId.CMDID_MACERROR)
                        {
                            onError(Error.MAC_ERROR);
                        }
                        else if (uc.commandID() == CmdId.CMDID_EMV_TRANS_DENIAL)
                        {
                            //onEmvICCExceptionData(Util.byteArray2Hex(uc.getBytes(0, uc.length())));
                            onRequestTransactionResult(TransactionResult.DECLINED);
                        }
                        else if (uc.commandID() == CmdId.CMDID_EMV_TRANS_TERMINATE)
                        {
                            onRequestDisplay(Display.TRANSACTION_TERMINATED);
                            //onEmvICCExceptionData(Util.byteArray2Hex(uc.getBytes(0, uc.length())));
                            onRequestTransactionResult(TransactionResult.TERMINATED);
                        }
                        else if (uc.commandID() == CmdId.CMDID_EMV_TRANS_TERMINATE_NFC)
                        {
                            onRequestTransactionResult(TransactionResult.TERMINATED);
                        }
                        else if (uc.commandID() == CmdId.CMDID_NOT_AVAILABLE)
                        {
                            onError(Error.CMD_NOT_AVAILABLE);

                        }
                        else if (uc.commandID() == CmdId.CMDID_OLD)
                        {
                            onError(Error.CMD_NOT_AVAILABLE);
                        }
                        else if (uc.commandID() == CmdId.CMDID_RESET)
                        {
                            rf = true;
                            onError(Error.DEVICE_RESET);
                        }
                        else if (uc.commandID() == CmdId.CMDID_ICC_POWER_ON_ERROR)
                        {// icc卡上电失败
                            Tip.i("POS_SDK:CmdId.CMDID_ICC_POWER_ON_ERROR,"
                                    + CmdId.CMDID_ICC_POWER_ON_ERROR);
                            onDoTradeResult(DoTradeResult.NOT_ICC, null);
                        }
                        else if (uc.commandID() == CmdId.CMDID_WR_DATA_ERROR)
                        { // 读/写数据失败
                            onError(Error.WR_DATA_ERROR);
                        }
                        else if (uc.commandID() == CmdId.CMDID_EMV_APP_CFG_ERROR)
                        {// emv
                         // app
                         // 配置错误
                            onError(Error.EMV_APP_CFG_ERROR);
                        }
                        else if (uc.commandID() == CmdId.CMDID_EMV_CAPK_CFG_ERROR)
                        {// //emv
                         // capk
                         // 配置错误
                            onError(Error.EMV_CAPK_CFG_ERROR);
                        }
                        else if (uc.commandID() == CmdId.CMDID_NO_UPDATE_WORK_KEY)
                        {
                            onDoTradeResult(DoTradeResult.NO_UPDATE_WORK_KEY, null);
                        }
                        else if (uc.commandID() == CmdId.CMDID_EMV_TRANS_CARD_BLOCKED_OR_EMV_APPS)
                        {
                            // onRequestDisplay(Display.TRANSACTION_TERMINATED);
                            onRequestTransactionResult(TransactionResult.CARD_BLOCKED_OR_NO_EMV_APPS);

                        }
                        else if (uc.commandID() == CmdId.CMDID_EMV_TRANS_SELECT_APP_FAILED)
                        {
                            // onRequestDisplay(Display.TRANSACTION_TERMINATED);
                            onRequestTransactionResult(TransactionResult.SELECT_APP_FAIL);

                        }
                        else if (uc.commandID() == CmdId.CMDID_EMV_TRANS_CAPK_FAILED)
                        {
                            // onRequestDisplay(Display.TRANSACTION_TERMINATED);
                            onRequestTransactionResult(TransactionResult.CAPK_FAIL);

                        }
                        else if (uc.commandID() == CmdId.CMDID_EMV_TRANS_FALLBACK)
                        {
                            // onRequestDisplay(Display.TRANSACTION_TERMINATED);
                            onRequestTransactionResult(TransactionResult.FALLBACK);

                        }
                        else
                        {
                            // 设备异常，请重新插拔设备
                            if (uc.commandID() == CmdId.CMDID_ICC_INIT_ERROR)
                            {//icc模块初始化失败
                                Tip.i("POS_SDK : CmdId.CMDID_ICC_INIT_ERROR," + CmdId.CMDID_ICC_INIT_ERROR);
                            }
                            else if (uc.commandID() == CmdId.CMDID_ICC_TRADE_ERROR)
                            {//icc卡通讯失败
                                Tip.i("POS_SDK : CmdId.CMDID_ICC_TRADE_ERROR," + CmdId.CMDID_ICC_TRADE_ERROR);
                            }
                            else if (uc.commandID() == CmdId.CMDID_TIMEOUT)
                            {//超时
                                Tip.i("POS_SDK : CmdId.CMDID_TIMEOUT," + CmdId.CMDID_TIMEOUT);
                            }
                            else
                            {
                                Tip.i("POS_SDK : uc command id = " + uc.commandID());
                            }
                            onError(Error.UNKNOWN);
                        }
                        
                    }
                }

            }
            //		if (!rf && uc != null) {
            //			showLogo(pos);
            //		}
            Tip.d("checkCmdId rf = " + rf);
            setTradeFlag(rf);
            return rf;
        }

        public static QPOSService getInstance()
        {
            QPOSService s = getInstance(CommunicationMode.AUDIO);
            isKeyboard = false;
            return s;
        }

        public static QPOSService getInstance(CommunicationMode mode)
        {
            lock (blk)
            {
                if (g_Instance == null)
                {
                    g_Instance = new QPOSService();
                }
                if (CommunicationMode.BLUETOOTH == mode)
                {
                    g_Instance.initBluetooth();
                }
                else if (CommunicationMode.AUDIO == mode)
                {
                    g_Instance.initAudio();
                }
                else if (CommunicationMode.BLUETOOTH_VER2 == mode)
                {
                    g_Instance.initBluetoothIVT();
                }
                else if (CommunicationMode.com == mode)
                {
                    g_Instance.initCom();
                }
                else if (CommunicationMode.BLUETOOTH_LE == mode) // Newly Added by Sheng Zhang to fulfill the client requirement regarding connecting to Bluetooth 4.0 Device.
                {
                    g_Instance.initBluetooth_LE();
                }
                else
                {
                    g_Instance.Dispose();
                    g_Instance = null;
                    return null;
                }
            }
            return g_Instance;

        }

        private void initBluetoothIVT()
        {
            throw new NotImplementedException();
        }

        private void initBluetooth()
        {
            pos = VPosBluetooth.getInstance();
            setPosExistFlag(false);
        }

        /// <summary>
        /// Newly Added function to initialise BLE device instance. Added by Sheng Zhang to fulfill the new client requirement regarding connecting
        /// to Bluetooth 4.0 Devices.
        /// </summary>
        private void initBluetooth_LE()
        {
            pos = VPosBluetoothLE.getInstance();
            setPosExistFlag(false);
        }

        private void initAudio()
        {
            //pos = VPosAudio.getInstance();
            //setPosExistFlag(false);
            //setPosExistFlag(true);
        }

        private void initCom()
        {            
            pos = UsbSerial.getInstance();
            setPosExistFlag(false);          
        }

        public bool isPosInputAmountFlag()
        {
            return posInputAmountFlag;
        }

        public void setPosInputAmountFlag(bool flag)
        {
            this.posInputAmountFlag = flag;
        }

        public bool isPosDisplayAmountFlag()
        {
            return posDisplayAmountFlag;
        }

        public void setPosDisplayAmountFlag(bool flag)
        {
            this.posDisplayAmountFlag = flag;
        }

        private void setVolume()
        {
        }

        private int getProperVolume()
        {
            return 22;
        }

        private bool connect(int count)
        {
            bool f = false;
            for (int i = 0; i < count; i++)
            {
                f = pos.open();
                if (f)
                {
                    break;
                }
                //Thread.Sleep(1000);                
                TaskSleeper.TaskSleep(1000);
            }
            if (!f)
            {
                onRequestNoQposDetected();
                Tip.d("bollean open false");
                setTradeFlag(f);
            }
            // setDeviceExistFlag(f);
            return f;
        }

        private DisconnectState disconnectState = DisconnectState.UNKNOW;
        private enum DisconnectState
        {
            UNKNOW,
            DISCONNECTING,
            DISCONNECTED,
        }
        public void disConnect()
        {
            Tip.d("<<<<<<<<<<<<disConnect start");
            disconnectState = DisconnectState.DISCONNECTING;
            pos.close();
            
            setTradeFlag(false);
            waitSetAmount.cancelWaitSetAmount();
            terminalTimeFlag = true;
            dea.setEmvTradeState(DoEmvApp.EmvTradeState.CANCEL);
            Tip.d("disConnect end>>>>>>>>>>>");
            disconnectState = DisconnectState.DISCONNECTED;
        }

        /// <summary>
        /// Slight modified version to already implemented disConnect() method. The full disconnect method is mainly specifically for Bluetooth Device
        /// As the Bluetooth Device socket cannot be disposed if you want to maintain Bluetooth Device connectivity and therefore the Bluetooth symbol
        /// shown on the QPOS device screen.
        /// </summary>
        public void disConnectFull()
        {
            Tip.d("<<<<<<<<<<<<disConnectFull start");
            disconnectState = DisconnectState.DISCONNECTING;
            pos.close();
            pos.disconnect();

            setTradeFlag(false);
            waitSetAmount.cancelWaitSetAmount();
            terminalTimeFlag = true;
            dea.setEmvTradeState(DoEmvApp.EmvTradeState.CANCEL);
            Tip.d("disConnectFull end>>>>>>>>>>>");
            disconnectState = DisconnectState.DISCONNECTED;
        }

        /**
	     * 重启
	     * @param pos
	     * @return
	     */
        private CommandUplink resetPos(VPos pos)
        {
            CommandDownlink dc = null;

            dc = new CommandDownlink(0x20, 0x30, 30);
            pos.sendCommand(dc);
            CommandUplink uc = pos.receiveCommandWaitResult(30);
            return uc;
        }

        private bool exit()
        {
            bool f = false;
            //		onError(Error.DEVICE_BUSY);
            try
            {
                disConnect();
                //Thread.Sleep(500);
                TaskSleeper.TaskSleep(500);
                f = connect(2);
                if (f)
                {
                    for (int i = 0; i < 1; i++)
                    {
                        f = exit_pos_trade(pos);
                        if (f) break;
                    }
                    if (!f)
                    {
                        onError(Error.TIMEOUT);
                    }
                }

            }
            catch (Exception e)
            {
                ;
            }

            return f;
        }

        private void doTrade__()
        {
            if (!connect(1))
            {
                return;
            }

            if (isKeyboard)
            {
                isKeyboardTrade();                
            }
            else
            {
                bool f = dt.doTrade(pos, tradeAmount, do_trade_timeout,
                    amountIcon, this.terminalTime, this.randomString,
                    this.extraString, keyIndex, cardTradeMode, this.tradeType, this.currencyCode, this.customDisplayString);
                if (!f)
                {
                    return;
                }
                disConnect();
            }            
        }

        private void doTrade_QF__()
        {
            if (!connect(1))
            {
                return;
            }
            Tip.i("waitSetAmountState");
            bool f = waitSetAmount.waitSetAmountState();
            if (f)
            {
                f = checkAmount(tradeAmount);

                if (f)
                {
                    //				onRequestWaitingUser();
                    f = dt.doTrade(tradeMode, randomString, tradeAmount, extraString, do_trade_timeout, pos);
                    if (!f)
                    {
                        return;
                    }
                }

            }
            else
            {
                onRequestTransactionResult(TransactionResult.CANCEL);

            }

            disConnect();
        }

        private void doEmvTrade__()
        {
            if (!connect(1))
            {
                return;
            }
            if (isKeyboard)
            {
                terminalTimeFlag = false;
                onRequestTime();
                while (!terminalTimeFlag)
                {
                    // Thread.Sleep(30);
                    TaskSleeper.TaskSleep(30);
                }
                onRequestDisplay(Display.PLEASE_WAIT);
                dea.doEMVApp(tradeAmount, tradeType, terminalTime, currencyCode, pos);
            }
            else
            {
                noKeyboardEmv();
            }

            disConnect();
        }

        private void isKeyboardTrade()
        {
            bool f = waitSetAmount.waitSetAmountState();
            Tip.d("set amount f = " + f);

            if (f)
            {
                Tip.d("set amount ");

                f = checkAmount(tradeAmount);

                if (f)
                {
                    //				onRequestWaitingUser();
                    f = dt.doTrade(pos, tradeAmount, do_trade_timeout,
                    amountIcon, this.terminalTime, this.randomString,
                    this.extraString, keyIndex, cardTradeMode, this.tradeType, this.currencyCode, this.customDisplayString);
                    if (!f)
                    {
                        return;
                    }
                }

            }
            else
            {
                onRequestTransactionResult(TransactionResult.CANCEL);

            }
            disConnect();
        }

        private void noKeyboardEmv()
        {
            // 
            bool f = waitSetAmount.waitSetAmountState();
            if (f)
            {
                Tip.d("set amount ");

                f = checkAmount(tradeAmount);

                if (f)
                {
                    terminalTimeFlag = false;
                    onRequestTime();
                    while (!terminalTimeFlag)
                    {
                        // Thread.Sleep(30); 
                        TaskSleeper.TaskSleep(30);
                    }
                    onRequestDisplay(Display.PLEASE_WAIT);
                    dea.doEMVApp(tradeAmount, tradeType, terminalTime, currencyCode, pos);
                }
                else
                {
                    exit_pos_trade(pos);
                }

            }
            else
            {
                exit_pos_trade(pos);
                onRequestDisplay(Display.TRANSACTION_TERMINATED);
                onRequestDisplay(Display.REMOVE_CARD);
                onRequestTransactionResult(TransactionResult.TERMINATED);
            }
        }

        private bool checkAmount(String tradeAmount)
        {
            bool f = true;
            if (tradeAmount != null && !(""==(tradeAmount)))
            {
                if (tradeAmount.Length > 8 || tradeAmount.StartsWith("0"))
                {
                    onError(Error.INPUT_INVALID);
                    f = false;
                }
                else
                {
                    try
                    {
                        Convert.ToInt32(tradeAmount);
                    }
                    catch (FormatException e)
                    {
                        Tip.d("amount format error");
                        onError(Error.INPUT_INVALID_FORMAT);
                        f = false;
                    }
                }
            }
            else
            {
                if (!(tradeType==("05")))
                {
                    //查询
                    onError(Error.INPUT_INVALID);
                    f = false;
                }
            }

            return f;

        }

        private void doGetPosId()
        {
            if (!connect(1))
            {
                return;
            }
            gpi.doGetPosId(pos);
            disConnect();
        }

         private void doGetPosRsa()
        {
            if (!connect(1))
            {
                return;
            }
            gpi.doGetPosRsa(pos);
            disConnect();
    }

    private void doSetFormatID()
        {
            if (!connect(1))
            {
                return;
            }
            gpi.doSetFormatID(pos, deviceCommandString);
            disConnect();
        }

        private void doGetPosInfo()
        {
            if (!connect(1))
            {
                return;
            }
            gpi.doGetPosInfo(pos);
            disConnect();
        }

        private void doGetPin()
        {
            if (!connect(1))
            {
                return;
            }
            dt.doGetPin(pos, pinTransactionData);
            disConnect();
        }


        private void doPowerOnIcc()
        {
            if (!connect(1))
            {
                return;
            }
            iccApdu.powerOnIcc(pos);
            disConnect();
        }

        private void doPowerOffIcc()
        {
            if (!connect(1))
            {
                return;
            }
            iccApdu.powerOffIcc(pos);
            disConnect();
        }

        private void doSendApdu()
        {
            if (!connect(1))
            {
                return;
            }
            iccApdu.sendApdu(pos, apduString);
            disConnect();
        }
        private void doSetSleepTime()
        {
            if (!connect(1))
            {
                return;
            }
            gpi.doSetSleepTimeout(pos, sleepTimeout);
            disConnect();
        }

        private void doGetCardNo()
        {
            if (!connect(1))
            {
                return;
            }
            gcn.doGetCardNo(pos);
            disConnect();
        }

        private void doGetPin1071()
        {
            if (!connect(1))
            {
                return;
            }
            uf.doGetPin1071(pos, getUpdateFirmwareStr(), do_trade_timeout);
        }

        private void doLcdShowCustomDisplay__()
        {
            if (!connect(1))
            {
                return;
            }
            doLcdShowCustomDisplay(pos);
            disConnect();
        }

        private void doUpdateFirmware_tmk_zz()
        {
            if (!connect(3))
            {
                return;
            }
            uf.doUpdateFirmware_tmk_zz(pos, Util.HexStringToByteArray(getUpdateFirmwareStr()));
            disConnect();
        }

        private macType mType;
        private enum macType
        {
            MAC_KEY_ENCRYPT,
            MAC_UNIONPAY_DOUBLE,
            MAC_UNIONPAY_SINGLE
        }

        private void doCalculateMac()
        {
            if (!connect(3))
            {
                return;
            }
            if (mType == macType.MAC_KEY_ENCRYPT)
            {
                uf.doCalculateMac(pos, Util.HexStringToByteArray(getUpdateFirmwareStr()));
            }
            else if (mType == macType.MAC_UNIONPAY_DOUBLE)
            {
                uf.doDoubleMac(pos, Util.HexStringToByteArray(getUpdateFirmwareStr()));
            }
            else if (mType == macType.MAC_UNIONPAY_SINGLE)
            {
                uf.doSingleMac(pos, Util.HexStringToByteArray(getUpdateFirmwareStr()));
            }
            else
            {
                onError(Error.CMD_NOT_AVAILABLE);
            }

            disConnect();
        }

        private void doUpdateFirmware()
        {
            if (!connect(1))
            {
                return;
            }
            //		String string = readLine("upgrade_package.asc");

            //		String string = readLine("upgrade_package.asc");
            uf.doUpdateFirmware(pos, Util.HexStringToByteArray(getUpdateFirmwareStr()));
            disConnect();
        }

        private void doSignature()
        {
            if (!connect(1))
            {
                return;
            }
            sig.doSignature(pos);
            disConnect();
        }

        private void doLcdShowCustomDisplay(VPos apos)
        {
            byte[] paras = Util.HexStringToByteArray(getLcdShowCustomDisplayStr());

            CommandDownlink dc = new CommandDownlink(0x41, 0x10, 10, paras);
            apos.sendCommand(dc);
            CommandUplink uc = apos.receiveCommandWaitResult(10);
            bool f = checkCmdId(uc);
            //		if(f){
            //			
            //		}
        }

        private void doUpdateEmvConfig()
        {
            if (!connect(1))
            {
                return;
            }

            String[] arrs = customParamStr.Split(new String[]{","},  StringSplitOptions.RemoveEmptyEntries);

            customParamStrOffset = 0;
            bool f = scp.doUpdateCustomParam(pos, SaveCustomParam.CustomParam.CUSTOM_PARAM_SEG_EMV_APP, customParamStrOffset, arrs[0]);

            if (f)
            {
                customParamStrOffset = 0;
                f = scp.doUpdateCustomParam(pos, SaveCustomParam.CustomParam.CUSTOM_PARAM_SEG_EMV_CAPK, customParamStrOffset, arrs[1]);
            }
            onReturnCustomConfigResult(f, "");
            disConnect();
        }

        private void doUpdateEmvAppConfig()
        {
            if (!connect(1))
            {
                return;
            }
            customParamStrOffset = 0;
            bool f = scp.doUpdateCustomParam(pos, SaveCustomParam.CustomParam.CUSTOM_PARAM_SEG_EMV_APP, customParamStrOffset, customParamStr);
            if (!f)
            {
                onReturnCustomConfigResult(f, "");
            }
            disConnect();
        }

        private void doUpdateEmvCapkConfig()
        {
            if (!connect(1))
            {
                return;
            }
            customParamStrOffset = 0;
            bool f = scp.doUpdateCustomParam(pos, SaveCustomParam.CustomParam.CUSTOM_PARAM_SEG_EMV_CAPK, customParamStrOffset, customParamStr);
            if (!f)
            {
                onReturnCustomConfigResult(f, "");
            }
            disConnect();
        }

        private void doReadEmvCapkConfig()
        {
            if (!connect(1))
            {
                return;
            }
            bool f = scp.doReadCustomParam(pos, SaveCustomParam.CustomParam.CUSTOM_PARAM_SEG_EMV_CAPK, 0, 0);
            if (!f)
            {
                onReturnCustomConfigResult(f, "");
            }
            disConnect();
        }

        private void doReadEmvAppConfig()
        {
            if (!connect(1))
            {
                return;
            }
            bool f = scp.doReadCustomParam(pos, SaveCustomParam.CustomParam.CUSTOM_PARAM_SEG_EMV_APP, 0, 0);
            if (!f)
            {
                onReturnCustomConfigResult(f, "");
            }
            disConnect();
        }

        private void doGetIccEmvData()
        {
            if (!connect(1))
            {
                return;
            }
            dea.doGetIccEmvData(pos, amountDescribe, pinTransactionData);
            disConnect();
        }

        //TODO 
        private void doSetMasterKey()
        {
            if (!connect(1))
            {
                return;
            }
            uf.doSetMasterKey(pos, getUpdateFirmwareStr());
            disConnect();
        }

        private byte getTradeType(TransactionType tradeType)
        {
            if (tradeType == TransactionType.GOODS)
            {
                return 0x01;
            }
            else if (tradeType == TransactionType.SERVICES)
            {
                return 0x02;
            }
            else if (tradeType == TransactionType.CASH)
            {
                return 0x03;
            }
            else if (tradeType == TransactionType.CASHBACK)
            {
                return 0x04;
            }
            else if (tradeType == TransactionType.INQUIRY)
            {
                return 0x05;
            }
            else if (tradeType == TransactionType.TRANSFER)
            {
                return 0x06;
            }
            else if (tradeType == TransactionType.ADMIN)
            {
                return 0x07;
            }
            else if (tradeType == TransactionType.CASHDEPOSIT)
            {
                return 0x08;
            }
            else if (tradeType == TransactionType.PAYMENT)
            {
                return 0x09;
            }
            else if (tradeType == TransactionType.PBOCLOG || tradeType == TransactionType.ECQ_INQUIRE_LOG)
            {
                return 0x0A;
            }
            else if (tradeType == TransactionType.SALE)
            {
                return 0x0B;
            }
            else if (tradeType == TransactionType.PREAUTH)
            {
                return 0x0C;
            }
            else if (tradeType == TransactionType.ECQ_DESIGNATED_LOAD)
            {
                return 0x10;
            }
            else if (tradeType == TransactionType.ECQ_UNDESIGNATED_LOAD)
            {
                return 0x11;
            }
            else if (tradeType == TransactionType.ECQ_CASH_LOAD)
            {
                return 0x12;
            }
            else if (tradeType == TransactionType.ECQ_CASH_LOAD_VOID)
            {
                return 0x13;
            }

            return 0x01;
        }

        public void showLogo(VPos pos)
        {
            for (int i = 0; i < 3; i++)
            {
                bool f = exit_pos_trade(pos);
                if (f)
                {
                    break;
                }
            }

            CommandDownlink dc = null;

            dc = new CommandDownlink(0x41, 0x10, 30);
            pos.sendCommand(dc);
            CommandUplink uc = pos.receiveCommandWaitResult(30);
        }

        /**
	     * 重传
	     * @param pos
	     * @return
	     */
        public CommandUplink retransmission(VPos pos)
        {
            CommandDownlink dc = null;

            dc = new CommandDownlink(0x20, 0xb0, 30);
            pos.sendCommand(dc);
            CommandUplink uc = pos.receiveCommandWaitResult(30);
            return uc;
        }

        public void openAudio()
        {
            ;
        }

        public void closeAudio()
        {
            disConnect();            
        }

        public bool connectBT(RfcommDeviceService deviceService)
        {
            VPosBluetooth posBT;

            if (!(pos is VPosBluetooth))
            {
                Tip.i("connectBT: is not VPosBluetooth");
                onError(Error.UNKNOWN);
                setTradeFlag(false);
                return false;
            }

            posBT = (VPosBluetooth)pos;

            if ((pos is VPosBluetooth))
            {
                ((VPosBluetooth)pos).setBlueToothAddress(deviceService);
            }

            else
            {
                onError(Error.UNKNOWN);
                setTradeFlag(false);
                return false;
            }

            if (deviceService == null || "" == (deviceService.ConnectionServiceName))
            {
                onRequestQposDisconnected();
                return false;
            }

            if (isTradeFlag())
            {
                onError(Error.DEVICE_BUSY);
                return false;
            }

            setTradeFlag(true);
            removeMsg(TradeMsg.MSG_CONNECTED_BLUETOOTH);
            sendMsg(TradeMsg.MSG_CONNECTED_BLUETOOTH);

            return true;
        }

        public bool connectBT(String blueToothAddress)
        {
            //if (!(pos is VPosBluetooth) && !(pos is VPosBluetooth_VER2)) {
            if (false/*!(pos is VPosBluetooth)*/)
            {
			    Tip.i("connectBT: is not implementation");
			//    onError(Error.UNKNOWN);
			//    setTradeFlag(false);
			//    return false;
		    }
		    //if ((pos is VPosBluetooth))
            //{
               // ((VPosBluetooth)pos).setBlueToothAddress(blueToothAddress);
		    //}
            //else if (pos instanceof VPosBluetooth_VER2)
            //{
            //    ((VPosBluetooth_VER2) pos).setBlueToothAddress(blueToothAddress);
            //}
            else 
            {
			    onError(Error.UNKNOWN);
			    setTradeFlag(false);
			    return false;
		    }
		
		    if(blueToothAddress==null || "" == (blueToothAddress)){
			    onRequestQposDisconnected();
			    return false;
		    }
		
		    if(isTradeFlag()){
			    onError(Error.DEVICE_BUSY);
			    return false;
		    }
		
		    setTradeFlag(true);
		    removeMsg(TradeMsg.MSG_CONNECTED_BLUETOOTH);
		    sendMsg(TradeMsg.MSG_CONNECTED_BLUETOOTH);    

		    return true;
	    }

        /// <summary>
        /// Newly implemented method to set trade message/trade operation as to connect to Bluetooth Low Energy device
        /// Added on 29th January 2018 by Sheng Zhang
        /// </summary>
        /// <param name="btLEDevice">BluetoothLEDevice instance that will be connected to</param>
        /// <returns>Boolean value indicates if the operation is correct.</returns>
        public bool connectBTLED(string btLEDeviceId)
        {
            VPosBluetoothLE posBTLED;

            if (!(pos is VPosBluetoothLE))
            {
                Tip.i("connectBT: is not VPosBluetooth Low Energy Device");
                onError(Error.UNKNOWN);
                setTradeFlag(false);
                return false;
            }

            posBTLED = (VPosBluetoothLE)pos;

            if ((pos is VPosBluetoothLE))
            {
                ((VPosBluetoothLE)pos).setBlueToothAddress(btLEDeviceId);
            }

            else
            {
                onError(Error.UNKNOWN);
                setTradeFlag(false);
                return false;
            }

            if (string.IsNullOrWhiteSpace(btLEDeviceId))
            {
                onRequestQposDisconnected();
                return false;
            }

            if (isTradeFlag())
            {
                onError(Error.DEVICE_BUSY);
                return false;
            }

            setTradeFlag(true);
            removeMsg(TradeMsg.MSG_CONNECTED_BLUETOOTH_LE);
            sendMsg(TradeMsg.MSG_CONNECTED_BLUETOOTH_LE);

            return true;
        }

        public void disconnectBT()
        {
            Tip.d("disconnect buletooth");
            connectBT("");
        }

        public bool resetQPOS()
        {
            bool f = false;
            disconnectState = DisconnectState.UNKNOW;
            resetState = ResetState.INIT;
            // Thread.Sleep(500);
            TaskSleeper.TaskSleep(500);

            try
            {
                if (isTradeFlag())
                {
                    resetState = ResetState.RESETING;
                    f = exit();
                    resetState = ResetState.RESETED;
                }
                else
                {
                    disConnect();
                    f = true;
                }
            }
            catch (Exception e)
            {

            }
            setTradeFlag(false);
            return f;
        }
        /// <summary>
        /// implement usb serial port
        /// </summary>
        public bool connectUSB(DeviceInformation deviceService)
        {
            UsbSerial posUSB;

            if (!(pos is UsbSerial))
            {
                Tip.i("connectUSB: is not USB serial");
                onError(Error.UNKNOWN);
                setTradeFlag(false);
                return false;
            }

            posUSB = (UsbSerial)pos;

            if ((pos is UsbSerial))
            {
                ((UsbSerial)pos).setUsbSerialAddress (deviceService);
            }

            else
            {
                onError(Error.UNKNOWN);
                setTradeFlag(false);
                return false;
            }

            if (deviceService == null || "" == (deviceService.Id))
            {
                onRequestQposDisconnected();
                return false;
            }

            if (isTradeFlag())
            {
                onError(Error.DEVICE_BUSY);
                return false;
            }

            setTradeFlag(true);
            removeMsg(TradeMsg.MSG_CONNECTED_USBSERIAL);
            sendMsg(TradeMsg.MSG_CONNECTED_USBSERIAL);

            return true;
        }
        /////////////////////////////////////////////////////////////////////////////////////////////////////
        private enum BusinessMode
        {
		    BusinessMode_DO_TRADE,
		    BusinessMode_GET_POS_ID,
		    BusinessMode_GET_POS_INFO,
		    BusinessMode_DO_TRADE_QF,
		    BusinessMode_UPDATE_FIRMWARE,
		    BusinessMode_SIGNATURE,
		    BusinessMode_GET_PIN,
		    BusinessMode_POWER_ON_ICC,
		    BusinessMode_POWER_OFF_ICC,
		    BusinessMode_SEND_APDU,
		    BusinessMode_SET_SLEEP_TIME,
		    BusinessMode_GET_POS_CARDNO,
		    BusinessMode_LCD_SHOW_CUSTOM_DIDPLAY,
		
		    BusinessMode_UPDATE_FIRMWARE_TMK_ZZ,
		    BusinessMode_CALCULATE_MAC,
		
		    BusinessMode_UPDATE_EMV_CONFIG,
		    BusinessMode_UPDATE_EMV_APP_CONFIG,
		    BusinessMode_UPDATE_EMV_CAPK_CONFIG,
		    BusinessMode_READ_EMV_APP_CONFIG,
		    BusinessMode_READ_EMV_CAPK_CONFIG,
		
		    BusinessMode_GET_ICC_EMV_DATA,
		    BusinessMode_SET_MASTER_KEY,
            BusinessMode_GET_PIN1071,
            BusinessMode_GET_POS_RSA,
            BusinessMode_SET_FORMAT_ID
		
	    }
        private void onDoTrade(BusinessMode mode)
        {
            /*
            Dispatcher.CurrentDispatcher.BeginInvoke(
                new onDoTradeDelegate(callbackDoTradeOnMainDispatcher), new object[] { mode });
            */
            Task.Run(() =>
            {
                callbackDoTradeOnMainDispatcher(mode);
            });
        }

        private delegate void onDoTradeDelegate(BusinessMode aMode);

        private void callbackDoTradeOnMainDispatcher(BusinessMode mode)
        {
            //确保上次的disconnect关闭
            if (disconnectState == DisconnectState.DISCONNECTING)
            {
                while (true)
                {
                    if (disconnectState == DisconnectState.DISCONNECTED)
                    {
                        break;
                    }
                    else if (disconnectState == DisconnectState.UNKNOW)
                    {
                        onError(Error.UNKNOWN);
                        return;
                    }
                    TaskSleeper.TaskSleep(30);
                    //Thread.Sleep(30);
                }
            }

            //判断是否上次已经在重装设备了
            if (resetState == ResetState.RESETING)
            {
                onError(Error.DEVICE_BUSY);
                return;
            }
            resetState = ResetState.INIT;

            if (isTradeFlag())
            {
                if (qf_sdk)
                {
                    resetState = ResetState.RESETING;
                    bool f = exit();
                    resetState = ResetState.RESETED;
                    if (!f) return;
                }
                else
                {
                    resetState = ResetState.RESETING;
                    disConnect();
                    TaskSleeper.TaskSleep(500);
                    //Thread.Sleep(500);                    
                    removeMsg(TradeMsg.MSG_EXIT_TRADE);
                    sendMsg(TradeMsg.MSG_EXIT_TRADE);
                    return;
                }

            }

            setTradeFlag(true);
            switch (mode)
            {
                case BusinessMode.BusinessMode_DO_TRADE:
                    removeMsg(TradeMsg.MSG_DO_TRADE);
                    sendMsg(TradeMsg.MSG_DO_TRADE);
                    break;
                case BusinessMode.BusinessMode_GET_POS_ID:
                    removeMsg(TradeMsg.MSG_GET_POS_ID);
                    sendMsg(TradeMsg.MSG_GET_POS_ID);
                    break;
                case BusinessMode.BusinessMode_GET_POS_RSA:
                    removeMsg(TradeMsg.MSG_GET_POS_RSA);
                    sendMsg(TradeMsg.MSG_GET_POS_RSA);
                    break;
                case BusinessMode.BusinessMode_SET_FORMAT_ID:
                    removeMsg(TradeMsg.MSG_SET_FORMAT_ID);
                    sendMsg(TradeMsg.MSG_SET_FORMAT_ID);
                    break; 
                case BusinessMode.BusinessMode_GET_POS_INFO:
                    removeMsg(TradeMsg.MSG_GET_POS_INFO);
                    sendMsg(TradeMsg.MSG_GET_POS_INFO);
                    break;
                case BusinessMode.BusinessMode_GET_PIN:
                    removeMsg(TradeMsg.MSG_GET_PIN);
                    sendMsg(TradeMsg.MSG_GET_PIN);
                    break;
                case BusinessMode.BusinessMode_POWER_ON_ICC:
                    removeMsg(TradeMsg.MSG_POWER_ON_ICC);
                    sendMsg(TradeMsg.MSG_POWER_ON_ICC);
                    break;
                case BusinessMode.BusinessMode_POWER_OFF_ICC:
                    removeMsg(TradeMsg.MSG_POWER_OFF_ICC);
                    sendMsg(TradeMsg.MSG_POWER_OFF_ICC);
                    break;
                case BusinessMode.BusinessMode_SEND_APDU:
                    removeMsg(TradeMsg.MSG_SEND_APDU);
                    sendMsg(TradeMsg.MSG_SEND_APDU);
                    break;
                case BusinessMode.BusinessMode_SET_SLEEP_TIME:
                    removeMsg(TradeMsg.MSG_SET_SLEEP_TIME);
                    sendMsg(TradeMsg.MSG_SET_SLEEP_TIME);
                    break;

                //qf
                case BusinessMode.BusinessMode_UPDATE_FIRMWARE:
                    removeMsg(TradeMsg.MSG_UPDATE_FIRMWARE);
                    sendMsg(TradeMsg.MSG_UPDATE_FIRMWARE);
                    break;
                case BusinessMode.BusinessMode_DO_TRADE_QF:
                    removeMsg(TradeMsg.MSG_DO_TRADE_QF);
                    sendMsg(TradeMsg.MSG_DO_TRADE_QF);
                    break;
                case BusinessMode.BusinessMode_SIGNATURE:
                    removeMsg(TradeMsg.MSG_SIGNATURE);
                    sendMsg(TradeMsg.MSG_SIGNATURE);
                    break;
                case BusinessMode.BusinessMode_GET_POS_CARDNO:
                    removeMsg(TradeMsg.MSG_GET_CARDNO);
                    sendMsg(TradeMsg.MSG_GET_CARDNO);
                    break;
                case BusinessMode.BusinessMode_LCD_SHOW_CUSTOM_DIDPLAY:
                    removeMsg(TradeMsg.MSG_LCD_SHOW_CUSTOM_DISPLAY);
                    sendMsg(TradeMsg.MSG_LCD_SHOW_CUSTOM_DISPLAY);
                    break;
                case BusinessMode.BusinessMode_GET_PIN1071:                    
                    removeMsg(TradeMsg.MSG_GET_PIN1071);
                    sendMsg(TradeMsg.MSG_GET_PIN1071);
                    break;

                case BusinessMode.BusinessMode_UPDATE_FIRMWARE_TMK_ZZ:
                    removeMsg(TradeMsg.MSG_UPDATE_FIRMWARE_TMK_ZZ);
                    sendMsg(TradeMsg.MSG_UPDATE_FIRMWARE_TMK_ZZ);
                    break;
                case BusinessMode.BusinessMode_CALCULATE_MAC:
                    removeMsg(TradeMsg.MSG_CALCULATE_MAC);
                    sendMsg(TradeMsg.MSG_CALCULATE_MAC);
                    break;
                case BusinessMode.BusinessMode_UPDATE_EMV_APP_CONFIG:
                    removeMsg(TradeMsg.MSG_UPDATE_EMV_APP_CONFIG);
                    sendMsg(TradeMsg.MSG_UPDATE_EMV_APP_CONFIG);
                    break;
                case BusinessMode.BusinessMode_UPDATE_EMV_CAPK_CONFIG:
                    removeMsg(TradeMsg.MSG_UPDATE_EMV_CAPK_CONFIG);
                    sendMsg(TradeMsg.MSG_UPDATE_EMV_CAPK_CONFIG);
                    break;
                case BusinessMode.BusinessMode_READ_EMV_APP_CONFIG:
                    removeMsg(TradeMsg.MSG_READ_EMV_APP_CONFIG);
                    sendMsg(TradeMsg.MSG_READ_EMV_APP_CONFIG);
                    break;
                case BusinessMode.BusinessMode_READ_EMV_CAPK_CONFIG:
                    removeMsg(TradeMsg.MSG_READ_EMV_CAPK_CONFIG);
                    sendMsg(TradeMsg.MSG_READ_EMV_CAPK_CONFIG);
                    break;
                case BusinessMode.BusinessMode_UPDATE_EMV_CONFIG:
                    removeMsg(TradeMsg.MSG_UPDATE_EMV_CONFIG);
                    sendMsg(TradeMsg.MSG_UPDATE_EMV_CONFIG);
                    break;
                case BusinessMode.BusinessMode_GET_ICC_EMV_DATA:
                    removeMsg(TradeMsg.MSG_GET_ICC_EMV_DATA);
                    sendMsg(TradeMsg.MSG_GET_ICC_EMV_DATA);
                    break;
                case BusinessMode.BusinessMode_SET_MASTER_KEY:
                    removeMsg(TradeMsg.MSG_SET_MASTER_KEY);
                    sendMsg(TradeMsg.MSG_SET_MASTER_KEY);
                    break;
                default:
                    break;
            }
        }
        /////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// Overloaded resetPosStatus() method. Similar to original resetPosStatus() method without doing too much status variable setting/resetting.
        /// Newly added by Sheng Zhang on 1st Feb 2018
        /// </summary>
        /// <param name="enableQuickReset">Boolean to enable/disable Quick Reset mode</param>
        /// <returns>Boolean to indicate if the operation is successful</returns>
        public bool resetQPosStatus(bool enableQuickReset)
        {
            Tip.d("QPOSService resetPosStatus(bool enableQuickReset)");
            if (!enableQuickReset)
            {
                return resetQPosStatus();
            }
            if(pos == null)
            {
                return false;
            }
            if (!posExistFlag)
            {
                return true;
            }

            bool f = false;
            try
            {
                f = exit();
            }
            catch (Exception e) {}
            setTradeFlag(false);
            disConnect();
            return f;
        }
            
        /// <summary>
        /// Method to reset pos status
        /// Newly added resetPosStatus() API. Added by Sheng Zhang on 1st Feb 2018
        /// </summary>
        /// <returns>Boolean value to indicate if operation is successful</returns>
        public bool resetQPosStatus()
        {
            Tip.d("QPOSService resetPosStatus");
            // If no QPOSService Instance currently exists, then the method call cannot be called and hence return false.
            if(pos == null)
            {
                return false;
            }
            bool f = false;
            disconnectState = DisconnectState.UNKNOW;
            resetState = ResetState.INIT;

            if (!posExistFlag)
            {
                return true;
            }

            try
            {
                resetState = ResetState.RESETING;
                f = exit();
                resetState = ResetState.RESETED;
                //disConnect();
            }
            catch (Exception e){}
            setTradeFlag(false);
            return f;
        }

        public void setDesKey(String ikey)
        {
            Packet.setDesKey(Util.HexStringToByteArray(ikey));
        }

        public void signature()
        {
            if (!isPosExistFlag())
            {
                onRequestNoQposDetected();
                return;
            }
            onDoTrade(BusinessMode.BusinessMode_SIGNATURE);
        }

        public void udpateWorkKey(String str)
        {
            if (!isPosExistFlag())
            {
                onRequestNoQposDetected();
                return;
            }
            setUpdateFirmwareStr(str);
            onDoTrade(BusinessMode.BusinessMode_UPDATE_FIRMWARE);
        }



        public void doTrade_QF(int tradeMode, String randomString, String extraString)
        {
            doTrade_QF(tradeMode, randomString, extraString, 60);
        }

        public void doTrade_QF(int tradeMode, String randomString, String extraString, int timeout)
        {
            if (!isPosExistFlag())
            {
                onRequestNoQposDetected();
                return;
            }
            do_trade_timeout = timeout;
            this.randomString = randomString;
            this.extraString = extraString;
            this.tradeMode = tradeMode;
            onDoTrade(BusinessMode.BusinessMode_DO_TRADE_QF);
        }

        public void getCardNo()
        {
            if (!isPosExistFlag())
            {
                onRequestNoQposDetected();
                return;
            }
            onDoTrade(BusinessMode.BusinessMode_GET_POS_CARDNO);
        }

        public void getPin(int encryptType, int keyIndex, int maxLen, String typeFace, String cardNo, String data, int timeout)
        {
            if (!isPosExistFlag())
            {
                return;
            }
            this.do_trade_timeout = timeout;
            //预留两字节
            String str = "0000";
            //加密类型+密钥索引+输入密码最大长度
            str += (Util.byteArray2Hex(new byte[] { (byte)encryptType }) + Util.byteArray2Hex(new byte[] { (byte)keyIndex }) + Util.byteArray2Hex(new byte[] { (byte)maxLen }));
            //显示字体长度+显示字体+卡号长度+卡号+附加数据长度+附加数据
            int typeFaceLen = 0;
            if (typeFace != null && !typeFace.Equals(""))
            {

                typeFaceLen = System.Text.Encoding.UTF8.GetBytes(typeFace).Length + 1;
                str += Util.byteArray2Hex(new byte[] { (byte)typeFaceLen }) + Util.byteArray2Hex(System.Text.Encoding.UTF8.GetBytes(typeFace)) + "00";

            }
            else
            {
                typeFaceLen = 0;
                typeFace = "";
                str += Util.byteArray2Hex(new byte[] { (byte)typeFaceLen }) + typeFace;
            }
            int cardNoLen = 0;
            if (typeFace != null && !typeFace.Equals(""))
            {
                cardNoLen = cardNo.Length;
                str += Util.byteArray2Hex(new byte[] { (byte)cardNoLen }) + Util.byteArray2Hex(System.Text.Encoding.UTF8.GetBytes(cardNo));
            }
            else
            {
                cardNoLen = 0;
                cardNo = "";
                str += Util.byteArray2Hex(new byte[] { (byte)cardNoLen }) + cardNo;
            }
            int dataLen = 0;
            if (typeFace != null && !typeFace.Equals(""))
            {
                dataLen = data.Length / 2;
                str += Util.byteArray2Hex(new byte[] { (byte)dataLen }) + data;
            }
            else
            {
                dataLen = 0;
                data = "";
                str += Util.byteArray2Hex(new byte[] { (byte)dataLen }) + data;
            }
            setUpdateFirmwareStr(str);
            onDoTrade(BusinessMode.BusinessMode_GET_PIN1071);
        }

        public void lcdShowCustomDisplay(LcdModeAlign lcdModeAlign, String lcdFont)
        {
            if (!isPosExistFlag())
            {
                onRequestNoQposDetected();
                return;
            }
            String align = "00";
            if (lcdModeAlign == LcdModeAlign.LCD_MODE_ALIGNLEFT)
            {
                align = "00";
            }
            else if (lcdModeAlign == LcdModeAlign.LCD_MODE_ALIGNRIGHT)
            {
                align = "20";
            }
            else if (lcdModeAlign == LcdModeAlign.LCD_MODE_ALIGNCENTER)
            {
                align = "40";
            }
            else
            {
                align = "00";
            }
            String str = "";

            if (lcdFont != null && !(""==(lcdFont)))
            {
                str = align + lcdFont + "00";
            }
            setLcdShowCustomDisplayStr(str);
            onDoTrade(BusinessMode.BusinessMode_LCD_SHOW_CUSTOM_DIDPLAY);
        }

        public void udpateWorkKey(String workKey, String workKeyCheck)
        {
            if (workKeyCheck.Length == 8)
            {
                workKeyCheck += "00000000";
            }
            udpateWorkKey(workKey, workKeyCheck, workKey, workKeyCheck, "", "");
        }

        /**
         * 
         * @param pik			if not exist, pik = "" , pikCheck = ""
         * @param pikCheck		len is 8, if not 8 ,append 0
         * @param trk			if not exist, trk = "" , trkCheck = ""
         * @param trkCheck		len is 8, if not 8 ,append 0
         * @param mak			if not exist, mak = "" , makCheck = ""
         * @param makCheck		len is 8, if not 8 ,append 0
         */
        public void udpateWorkKey(String pik, String pikCheck, String trk,
                String trkCheck, String mak, String makCheck)
        {
            if (!isPosExistFlag())
            {
                onRequestNoQposDetected();
                return;
            }
            String str = "";

            int pikkLen = 0;
            if ((pik != null && !(""==(pik)))
                    && (pikCheck != null && !(""==(pikCheck))))
            {
                pikkLen = pik.Length + pikCheck.Length;
                pikkLen = pikkLen / 2;
            }
            else
            {
                pik = "";
                pikCheck = "";
            }
            str += Util.byteArray2Hex(new byte[] { (byte)pikkLen }) + pik
                    + pikCheck;

            int trkLen = 0;
            if ((trk != null && !(""==(trk)))
                    && (trkCheck != null && !("" == (trkCheck))))
            {
                trkLen = trk.Length + trkCheck.Length;
                trkLen = trkLen / 2;
            }
            else
            {
                trk = "";
                trkCheck = "";
            }
            str += Util.byteArray2Hex(new byte[] { (byte)trkLen }) + trk
                    + trkCheck;

            int makLen = 0;
            if ((mak != null && !(""==mak))
                    && (makCheck != null && !(""==makCheck)))
            {
                makLen = mak.Length + makCheck.Length;
                makLen = makLen / 2;
            }
            else
            {
                mak = "";
                makCheck = "";
            }
            str += Util.byteArray2Hex(new byte[] { (byte)makLen }) + mak
                    + makCheck;
            Tip.d("work keys: " + str);
            setUpdateFirmwareStr(str);
            onDoTrade(BusinessMode.BusinessMode_UPDATE_FIRMWARE_TMK_ZZ);
        }

        /**
	     * 
	     * @param macStr	len is 8 , if not 8 ,append 0
	     */
        public void MacKeyEncrypt(String macStr)
        {
            if (!isPosExistFlag())
            {
                onRequestNoQposDetected();
                return;
            }
            if (macStr == null || macStr==("") || macStr.Length != 16)
            {
                onError(Error.INPUT_INVALID_FORMAT);
                return;
            }
            mType = macType.MAC_KEY_ENCRYPT;
            setUpdateFirmwareStr(macStr);
            onDoTrade(BusinessMode.BusinessMode_CALCULATE_MAC);
        }

        public void calcMacSingle(String macStr)
        {
            if (!isPosExistFlag())
            {
                onRequestNoQposDetected();
                return;
            }
            if (macStr == null || macStr==("") || macStr.Length != 32)
            {
                onError(Error.INPUT_INVALID_FORMAT);
                return;
            }
            mType = macType.MAC_UNIONPAY_SINGLE;
            setUpdateFirmwareStr(macStr);
            onDoTrade(BusinessMode.BusinessMode_CALCULATE_MAC);
        }

        public void calcMacDouble(String macStr)
        {
            if (!isPosExistFlag())
            {
                onRequestNoQposDetected();
                return;
            }
            if (macStr == null || macStr==("") || macStr.Length != 32)
            {
                onError(Error.INPUT_INVALID_FORMAT);
                return;
            }
            mType = macType.MAC_UNIONPAY_DOUBLE;
            setUpdateFirmwareStr(macStr);
            onDoTrade(BusinessMode.BusinessMode_CALCULATE_MAC);
        }

        public void setMasterKey(String key, String checkValue)
        {
            if (!isPosExistFlag())
            {
                onRequestNoQposDetected();
                return;
            }
            setUpdateFirmwareStr(key + checkValue);
            onDoTrade(BusinessMode.BusinessMode_SET_MASTER_KEY);
        }

        public void iccCashBack(String transactionTime, String random)
        {
            if (!isPosExistFlag())
            {
                return;
            }
            this.randomString = random;
            pinTransactionData = transactionTime;
            amountDescribe = "02";
            onDoTrade(BusinessMode.BusinessMode_GET_ICC_EMV_DATA);
        }
        public void getIccCardNo(String transactionTime)
        {
            if (!isPosExistFlag())
            {
                onRequestNoQposDetected();
                return;
            }
            pinTransactionData = transactionTime;
            amountDescribe = "01";
            onDoTrade(BusinessMode.BusinessMode_GET_ICC_EMV_DATA);
        }

        public void inquireECQAmount(String transactionTime)
        {
            if (!isPosExistFlag())
            {
                onRequestNoQposDetected();
                return;
            }
            pinTransactionData = transactionTime;
            amountDescribe = "00";
            onDoTrade(BusinessMode.BusinessMode_GET_ICC_EMV_DATA);
        }

        public void getPin(String transactionData)
        {
            if (!isPosExistFlag())
            {
                onRequestNoQposDetected();
                return;
            }
            pinTransactionData = transactionData;
            if (pinTransactionData != null && !(""==pinTransactionData))
            {
                int pinTransactionDataLen = pinTransactionData.Length;
                if (pinTransactionDataLen > 24)
                {
                    onError(Error.INPUT_OUT_OF_RANGE);
                    return;
                }
            }
            onDoTrade(BusinessMode.BusinessMode_GET_PIN);
        }

        public void updateEmvConfig(String emvAppCfg, String emvCapkCfg)
        {
            if (!isPosExistFlag())
            {
                onRequestNoQposDetected();
                return;
            }

            if (emvAppCfg == null || ""==(emvAppCfg) || emvAppCfg.Length % 2 != 0)
            {
                onError(Error.INPUT_INVALID_FORMAT);
                return;
            }

            if (emvCapkCfg == null || ""==(emvCapkCfg) || emvCapkCfg.Length % 2 != 0)
            {
                onError(Error.INPUT_INVALID_FORMAT);
                return;
            }

            customParamStr = emvAppCfg + "," + emvCapkCfg;
            onDoTrade(BusinessMode.BusinessMode_UPDATE_EMV_CONFIG);
        }

        private void updateEmvAppConfig(String emvAppCfg)
        {
            if (!isPosExistFlag())
            {
                onRequestNoQposDetected();
                return;
            }
            if (emvAppCfg == null || ""==(emvAppCfg) || emvAppCfg.Length % 2 != 0)
            {
                onError(Error.INPUT_INVALID_FORMAT);
                return;
            }

            customParamStr = emvAppCfg;
            onDoTrade(BusinessMode.BusinessMode_UPDATE_EMV_APP_CONFIG);
        }

        private void updateEmvCapkConfig(String emvCapkCfg)
        {
            if (!isPosExistFlag())
            {
                onRequestNoQposDetected();
                return;
            }
            if (emvCapkCfg == null || ""==(emvCapkCfg) || emvCapkCfg.Length % 2 != 0)
            {
                onError(Error.INPUT_INVALID_FORMAT);
                return;
            }
            customParamStr = emvCapkCfg;
            onDoTrade(BusinessMode.BusinessMode_UPDATE_EMV_CAPK_CONFIG);
        }

        public void readEmvAppConfig()
        {
            if (!isPosExistFlag())
            {
                onRequestNoQposDetected();
                return;
            }
            onDoTrade(BusinessMode.BusinessMode_READ_EMV_APP_CONFIG);
        }

        public void readEmvCapkConfig()
        {
            if (!isPosExistFlag())
            {
                onRequestNoQposDetected();
                return;
            }
            onDoTrade(BusinessMode.BusinessMode_READ_EMV_CAPK_CONFIG);

        }

        public void powerOnIcc()
        {
            if (!isPosExistFlag())
            {
                onRequestNoQposDetected();
                return;
            }
            onDoTrade(BusinessMode.BusinessMode_POWER_ON_ICC);
        }

        public void powerOffIcc()
        {
            if (!isPosExistFlag())
            {
                onRequestNoQposDetected();
                return;
            }
            onDoTrade(BusinessMode.BusinessMode_POWER_OFF_ICC);
        }

        public void sendApdu(String apduString)
        {
            if (!isPosExistFlag())
            {
                onRequestNoQposDetected();
                return;
            }
            if (apduString == null || ""==(apduString))
            {
                onError(Error.INPUT_INVALID_FORMAT);
                return;
            }
            this.apduString = apduString;
            onDoTrade(BusinessMode.BusinessMode_SEND_APDU);
        }

        public void setPosSleepTime(int time)
        {
            if (!isPosExistFlag())
            {
                onRequestNoQposDetected();
                return;
            }
            sleepTimeout = time;
            onDoTrade(BusinessMode.BusinessMode_SET_SLEEP_TIME);
        }

        public void doTradeNoPinpad(int timeout)
        {
            isKeyboard = false;
            doCheckCard(timeout);
        }

        public void doTrade()
        {
            doTrade(60);
        }
         /*
     * @param cardType  NFC card or Chip card, only 0 or 1
	 * @param tagCount  The number of the tag
     * @param tagArrStr The tag content
	 * @return
     */
        public Dictionary<String, String> getICCTag(int cardType, int tagCount, String tagArrStr)
        {
            Dictionary<String, String> hashtable = new Dictionary<String, String>();
            if (!isTradeFlag())
            {
                if (!isPosExistFlag())
                {
                    return hashtable;
                }
                if (!connect(1))
                {
                    return hashtable;
                }
            }
            String str = "00";
            str += Util.byteArray2Hex(Util.IntToHex(cardType));
            str += Util.byteArray2Hex(Util.IntToHex(cardType));//"01";
            str += Util.byteArray2Hex(Util.IntToHex(tagCount));
            if (tagArrStr == null || "".Equals(tagArrStr))
            {
                tagArrStr = "00";
            }
            str += tagArrStr;
            Tip.w("str: " + str);
            byte[] paras = Util.HexStringToByteArray(str.Trim());
            CommandDownlink dc = new CommandDownlink(0x16, 0x51, 10, paras);
            pos.sendCommand(dc);
            CommandUplink uc = pos.receiveCommandWaitResult(10);
            bool f = checkCmdId(uc);

            if (!isTradeFlag())
            {
                disConnect();
            }

            if (cardType == 1)
            {
                disConnect();
            }

            if (!f)
            {
                return hashtable;
            }

            if (uc.commandID() == CmdId.CMDID_EMV_KERNEL_PC)
            {
                //str = dea.getIccTag(paras);
                str = Util.byteArray2Hex(uc.getBytes(0, uc.length()));
            }
            else
            {
                str = Util.byteArray2Hex(uc.getBytes(0, uc.length()));
            }

            hashtable.Add("tlv", str);
            return hashtable;
        }

        public Dictionary<String, String> getNFCBatchData()
        {

            return getICCTag(1, 0, "");
        }

        public void doTrade(int timeout)
        {
            if (!isPosExistFlag())
            {
                onRequestNoQposDetected();
                return;
            }
            do_trade_timeout = timeout;
            setDoTradeMode(DoTradeMode.COMMON);
            onDoTrade(BusinessMode.BusinessMode_DO_TRADE);
        }

        public void doCheckCard(int timeout)
        {
            if (!isPosExistFlag())
            {
                onRequestNoQposDetected();
                return;
            }
            do_trade_timeout = timeout;
            setDoTradeMode(DoTradeMode.CHECK_CARD_NO_IPNUT_PIN);
            onDoTrade(BusinessMode.BusinessMode_DO_TRADE);
        }

        public void doCheckCard()
        {
            doCheckCard(60);
        }

        public void getQposInfo()
        {
            if (!isPosExistFlag())
            {
                onRequestNoQposDetected();
                return;
            }
            onDoTrade(BusinessMode.BusinessMode_GET_POS_INFO);
        }

        public void getQposId()
        {
            if (!isPosExistFlag())
            {
                onRequestNoQposDetected();
                return;
            }
            onDoTrade(BusinessMode.BusinessMode_GET_POS_ID);
        }

         public void getQposRsaKey()
        {
            if (!isPosExistFlag())
            {
                onRequestNoQposDetected();
                return;
            }
            onDoTrade(BusinessMode.BusinessMode_GET_POS_RSA);
        }

        public void sendDeviceCommandString(String deviceCommandString)
        {
            if (!isPosExistFlag())
            {
                onRequestNoQposDetected();
                return;
            }
            this.deviceCommandString = deviceCommandString;
            onDoTrade(BusinessMode.BusinessMode_SET_FORMAT_ID);
        }

        public void doEmvApp(EmvOption emvOption)
        {
            if (emvOption == EmvOption.START_WITH_FORCE_ONLINE)
            {
                onRequestDisplay(Display.TRY_ANOTHER_INTERFACE);
                disConnect();
                return;
            }
            removeMsg(TradeMsg.MSG_DO_EMV_APP);
            sendMsg(TradeMsg.MSG_DO_EMV_APP);
            setEmvOption(emvOption);

        }



        public void cancelSetAmount()
        {
            Tip.d("cancelSetAmount");
            waitSetAmount.cancelWaitSetAmount();
        }

        public void setAmountIcon(String amountIcon)
        {
            setAmountIcon(AmountType.MONEY_TYPE_CUSTOM_STR, amountIcon);
        }

        public enum AmountType
        {
            MONEY_TYPE_NONE,
            MONEY_TYPE_RMB,
            MONEY_TYPE_DOLLAR,
            MONEY_TYPE_CUSTOM_STR
        }
        public void setAmountIcon(AmountType amtType, String amountIcon)
        {
            String str = "";
            if (amtType == AmountType.MONEY_TYPE_NONE)
            {
                str = "01";
            }
            else if (amtType == AmountType.MONEY_TYPE_RMB)
            {
                str = "02";
            }
            else if (amtType == AmountType.MONEY_TYPE_DOLLAR)
            {
                str = "03";
            }
            else if (amtType == AmountType.MONEY_TYPE_CUSTOM_STR)
            {
                this.amountIcon = amountIcon;
                if (amountIcon != null && !(""==amountIcon))
                {
                    this.amountIcon = Util.byteArray2Hex(System.Text.Encoding.UTF8.GetBytes(amountIcon.Trim()));
                }
                return;
            }
            this.amountIcon = str;
        }

        public void setAmount(String amount, String amountDescribe, String currencyCode, TransactionType transactionType)
        {
            Tip.d("setAmount");
            this.tradeAmount = amount;
            this.amountDescribe = amountDescribe;
            this.currencyCode = currencyCode;
            Tip.d("transactionType :" + getTradeType(transactionType));
            this.tradeType = Util.byteArray2Hex(new byte[] { getTradeType(transactionType) });//; getTradeType(transactionType);
            Tip.d("setAmount tradeType: " + tradeType);
            waitSetAmount.confirmWaitSetAmount();
        }

        public void selectEmvApp(int index)
        {
            setSelectEmvAppIndex(index);
            dea.setEmvTradeState(DoEmvApp.EmvTradeState.SET);
        }

        public void cancelSelectEmvApp()
        {
            setSelectEmvAppIndex(9);
            dea.setEmvTradeState(DoEmvApp.EmvTradeState.CANCEL);
        }

        public void finalConfirm(bool isConfirmed)
        {
            if (isConfirmed)
            {
                dea.setEmvTradeState(DoEmvApp.EmvTradeState.SET);
            }
            else
            {
                dea.setEmvTradeState(DoEmvApp.EmvTradeState.CANCEL);
            }
        }

        public void sendOnlineProcessResult(String tlv)
        {
            dea.setEmvGoOnLineData(tlv);
            dea.setEmvTradeState(DoEmvApp.EmvTradeState.SET);
        }

        public void isServerConnected(bool isConnected)
        {
            if (isConnected)
            {
                dea.setEmvTradeState(DoEmvApp.EmvTradeState.SET);
            }
            else
            {
                dea.setEmvTradeState(DoEmvApp.EmvTradeState.CANCEL);
            }

        }

        public void sendTime(String terminalTime)
        {
            Tip.d("terminalTime = " + terminalTime);
            this.terminalTime = terminalTime;
            terminalTimeFlag = true;
        }

        public bool isQposPresent()
        {
            return isPosExistFlag();
        }

        public String getSdkVersion()
        {
            return SDK_VERSION;
        }

        public void sendPin(String pin)
        {
            setPinStr(pin);
            dea.setEmvTradeState(DoEmvApp.EmvTradeState.SET);
        }

        public void emptyPin()
        {
            setPinStr("");
            dea.setEmvTradeState(DoEmvApp.EmvTradeState.SET);
        }

        public void cancelPin()
        {
            setPinStr("");
            dea.setEmvTradeState(DoEmvApp.EmvTradeState.CANCEL);
        }

        public Dictionary<String, String> anlysEmvIccData(String tlv)
        {
            return dea.anlysData(false,tlv);
        }

        private void testECHO()
        {
            if (!connect(1))
            {
                return;
            }
            CommandDownlink dc = null;
            CommandUplink uc = null;
            byte[] paras = new byte[0];

            //		D36B851253EA846F0CDB77011D0B4A51CB5CAF5A4076C982
            String str = "D36B851253EA846F0CDB77011D0B63D36B851253EA846F0CDB77011D0B63D36B851253EA846F0CDB77011D0B4A51CB5CAF5A4076C982D36B851253EA846F0CDB77011D0B63D36B851253EA846F0CDB77011D0B63D36B851253EA846F0CDB77011D0B4A51CB5CAF5A4076C982D36B851253EA846F0CDB77011D0B4A51CB5CAF5A4076C982D36B851253EA846F0CDB77011D0B63D36B851253EA846F0CDB77011D0B4A51CB5CAF5A4076C982D36B851253EA846F0CDB77011D0B4A51CB5CAF5A4076C982D36B851253EA846F0CDB77011D0B63D36B851253EA846F0CDB77011D0B4A51CB5CAF5A4076C982D36B851253EA846F0CDB77011D0B4A51CB5CAF5A4076C982D36B851253EA846F0C";

            paras = Util.HexStringToByteArray(str);
            dc = new CommandDownlink(0x20, 0xc0, 20, paras);
            pos.sendCommand(dc);
            uc = pos.receiveCommandWaitResult(20);
            bool f = checkCmdId(uc);
            disConnect();
        }
        public enum DataFormat
        {
            OLD,
            //		NEW_1,//2013-12-29  getPosInfo
        }

        public DataFormat getDataFormat()
        {
            return dataFormat;
        }

        public  enum CommunicationMode
        {
            BLUETOOTH,
            AUDIO,
            BLUETOOTH_VER2,
            com,
            BLUETOOTH_LE // Newly Added By Sheng Zhang for additional client requrement regarding connection Bluetooth 4.0 Devices
        }

        public enum DoTradeResult
        {
            NONE, MCR, ICC, NOT_ICC, BAD_SWIPE, NO_RESPONSE, NO_UPDATE_WORK_KEY,
            PLAIN_TRACK, ManulEnc, NFC_ONLINE, NFC_OFFLINE, NFC_DECLINED
        }

        public enum DoTradeMode
        {
            COMMON,
            CHECK_CARD_NO_IPNUT_PIN
        }

        public  enum EmvOption
        {
            START, START_WITH_FORCE_ONLINE
        }


        // USER_CANCEL,
        // DEVICE_DESTRUCT,// POS 自毁
        // ERR_ORTHER_ERROR, //其他没有处理错误
        public  enum Error
        {
            TIMEOUT, MAC_ERROR, CMD_TIMEOUT,
            CMD_NOT_AVAILABLE, DEVICE_RESET,
            UNKNOWN, DEVICE_BUSY,
            INPUT_OUT_OF_RANGE, INPUT_INVALID_FORMAT,
            INPUT_ZERO_VALUES, INPUT_INVALID,
            CASHBACK_NOT_SUPPORTED, CRC_ERROR, COMM_ERROR,
            WR_DATA_ERROR,
            EMV_APP_CFG_ERROR,
            EMV_CAPK_CFG_ERROR,
            DO_TRADE_ICC_EXCECPTION
        }

        public  enum Display
        {
            TRY_ANOTHER_INTERFACE, PLEASE_WAIT, REMOVE_CARD, CLEAR_DISPLAY_MSG, PROCESSING, PIN_OK, TRANSACTION_TERMINATED, INPUT_PIN_ING, MAG_TO_ICC_TRADE, INPUT_OFFLINE_PIN_ONLY
        }

        public  enum TransactionResult
        {
            APPROVED, TERMINATED, DECLINED, CANCEL, CAPK_FAIL, NOT_ICC, SELECT_APP_FAIL, DEVICE_ERROR, CARD_NOT_SUPPORTED, MISSING_MANDATORY_DATA, CARD_BLOCKED_OR_NO_EMV_APPS, INVALID_ICC_DATA, FALLBACK
        }

        public  enum TransactionType
        {
            GOODS, // 货物
            SERVICES, // 服务
            CASH,//现金
            CASHBACK, // 退款 返现
            INQUIRY, // 查询
            TRANSFER, // 转账
            ADMIN,//管理
            CASHDEPOSIT,//存款
            PAYMENT,// 付款 支付

            PBOCLOG,//        0x0A			/*PBOC日志(电子现金日志)*/
            SALE,//           0x0B			/*消费*/
            PREAUTH,//        0x0C			/*预授权*/

            ECQ_DESIGNATED_LOAD,//				0x10				/*电子现金Q指定账户圈存*/
            ECQ_UNDESIGNATED_LOAD,//			0x11				/*电子现金费非指定账户圈存*/
            ECQ_CASH_LOAD,//			0x12				/*电子现金费现金圈存*/
            ECQ_CASH_LOAD_VOID,//			0x13				/*电子现金圈存撤销*/
            ECQ_INQUIRE_LOG,//	0x0A	/*电子现金日志(和PBOC日志一样)*/


        }

        public  enum UpdateInformationResult
        {
            UPDATE_SUCCESS,
            UPDATE_FAIL,
            UPDATE_PACKET_VEFIRY_ERROR,
            UPDATE_PACKET_LEN_ERROR,
        }


        public  enum LcdModeAlign
        {
            LCD_MODE_ALIGNLEFT,     //(0x00)
            LCD_MODE_ALIGNRIGHT,	//(0x20)
            LCD_MODE_ALIGNCENTER  	//(0x40)
        }

        public  interface QPOSServiceListener
        {
            void onRequestWaitingUser();
            void onQposIdResult(Dictionary<String, String> posId);
            void onQposInfoResult(Dictionary<String, String> posInfoData);
            void onDoTradeResult(DoTradeResult result, Dictionary<String, String> decodeData);
            void onRequestSetAmount();
            void onRequestSelectEmvApp(List<String> appList);
            void onRequestIsServerConnected();
            void onRequestFinalConfirm();
            void onRequestOnlineProcess(String tlv);
            void onRequestTime();
            void onRequestTransactionResult(TransactionResult transactionResult);
            void onRequestTransactionLog(String tlv);
            void onRequestBatchData(String tlv);
            void onRequestQposConnected();
            void onRequestQposDisconnected();
            void onRequestNoQposDetected();
            //void onRequestPin();		

            void onError(Error errorState);
            void onRequestDisplay(Display displayMsg);
            void onReturnReversalData(String tlv);

            void onReturnGetPinResult(Dictionary<String, String> result);

            //icc  apdu
            void onReturnPowerOnIccResult(bool isSuccess, String ksn, String atr, int atrLen);
            void onReturnPowerOffIccResult(bool isSuccess);
            void onReturnApduResult(bool isSuccess, String apdu, int apduLen);

            //set sleep time
            void onReturnSetSleepTimeResult(bool isSuccess);

            //add 2014-03-25 qf
            void onGetCardNoResult(String cardNo);
            void onReturniccCashBack(Hashtable result);
            void onRequestSignatureResult(byte[] paras);

            //add 2014-03-25 zz
            void onRequestCalculateMac(String calMac);
            //add 2014-03-25
            void onRequestUpdateWorkKeyResult(UpdateInformationResult result);

            //add 2014-04-09 
            void onReturnCustomConfigResult(bool isSuccess, String result);

            //add 2014-04-16
            void onRequestSetPin();

            void onReturnSetMasterKeyResult(bool isSuccess);
            //add 2017-06-07
            void onQposRSAResult(String rsaPubkey);
            //add 2017-07-04
            void onReturnSendDeviceCommandString(bool isSuccess);
        }

        private bool isDisposed;
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if (!isDisposed)
            {
                if (disposing)
                {
                    stopBusinessDispatcher();
                    if (pos != null) pos.Dispose();
                    g_Instance = null;
                }
                isDisposed = true;
            }
        }

        ~QPOSService()
        {
            Dispose(false);
        }
    }
}
