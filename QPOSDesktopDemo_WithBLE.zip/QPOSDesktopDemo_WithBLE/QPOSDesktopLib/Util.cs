﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SDK_LIB
{
    /// <summary>
    /// Util Class implements a collection of function used to convert data to specific forms.
    /// </summary>
    public class Util
    {
        // Define a String Collection of all valid charaters that can be used in Hexdecimal representation.
        // This is used as reference strings to select specific characters based on the actual byte value.
        private static String HEXES = "0123456789ABCDEF";

        /// <summary>
        /// Convert a array of byte values to corresponding Hexdecmial Character representation.
        /// </summary>
        /// <param name="raw">Input Byte Array that will be converted to String Representation</param>
        /// <returns>The Hexdecimal String that represents the value of the input byte array</returns>
        public static String byteArray2Hex(byte[] raw)
        {
	        if ( raw == null ) {
                return null;
	        }

            // Initialise StringBuilder instance with twice the length of the original byte array
            // Due to the fact that two characters are used to represent all possible value one
            // Byte can have in Hexdecimal form. E.g. 1111 1111 = 0XFF
            StringBuilder hex = new StringBuilder( 2 * raw.Length );
	        foreach ( byte b in raw ) 
            {
                hex.Append(HEXES[((b & 0xF0) >> 4)]) // Check the value of the most 4 significant bits and append the corresponding characters
                    .Append(HEXES[(b & 0x0F)]); // Check the value of the least 4 significant bits and append the corresponding characters
            }
            return hex.ToString();
        }

        /**
		 * 16进制格式的字符串转成16进制byte 44 --> byte 0x44
		 * 
		 * @param hexString
		 * @return
		 */
        /// <summary>
        /// Convert a Hexdecimal String to its corresponding Hex value that it represents.
        /// </summary>
        /// <param name="hexString">The Input Hex String that will be converted</param>
        /// <returns>The Byte array that corresponding to the value the Hex String represents</returns>
        public static byte[] HexStringToByteArray(String hexString)
        {
            if (hexString == null || hexString == "")
            {
                return new byte[] { };
            }
            // If the input hexdecimal string length is not a multiple of 2
            // Pad '0' Character in front of the hex string so that convertion will not throw error
            if (hexString.Length == 1 || hexString.Length % 2 != 0)
            {
                hexString = "0" + hexString;
            }
            hexString = hexString.ToUpper();
            int length = hexString.Length / 2;
            char[] hexChars = hexString.ToCharArray();
            byte[] d = new byte[length];
            for (int i = 0; i < length; i++)
            {
                int pos = i * 2;
                d[i] = (byte)(charToByte(hexChars[pos]) << 4 | charToByte(hexChars[pos + 1]));
            }
            return d;
        }

        /// <summary>
        /// Convert single Hexdecimal Character to its corresponding Byte value in Byte form.
        /// </summary>
        /// <param name="c">Input character that will be converted to Byte value. Only Valid HEX Charater is allowed.</param>
        /// <returns>The Byte value that corresponding to the input character</returns>
        private static byte charToByte(char c)
        {
            if (HEXES.IndexOf(c) == -1) { return (byte)0X00; }
            // Select the index of the the input character within the reference HEX String.
            // Convert the index number to Byte size number.
            return (byte)HEXES.IndexOf(c);
        }

        /**
		 * 中文字符串转成16进制数组
		 * 
		 * @param str
		 * @return
		 */
        /// <summary>
        /// Convert Chinese String to its corresponding Byte array values. 
        /// </summary>
        /// <param name="str">The Chinese String of Characters</param>
        /// <returns>Byte array that corresponds to the character</returns>
        public static byte[] CNToHex(String str)
        {            
            byte[] b = null;
            b = System.Text.Encoding.GetEncoding("GBK").GetBytes(str);            
            return b;
        }

        /**
		 * byte 转换成16进制格式字符串显示
		 * 
		 * @param b
		 * @return
		 */
        /// <summary>
        /// Convert the arry of byte values to the corresponding Hexdecimal String with Hexdecimal representation format.
        /// E.g. 1111 1111 1111 0000 = 0XFF, 0XF0
        /// Similar to byteArray2Hex() but output format is different.
        /// </summary>
        /// <param name="b">Input Byte array that will be converted and formated</param>
        /// <returns>Formated Hexdecimal String</returns>
        public static String getHexString(byte[] b)
        {
            StringBuilder result = new StringBuilder("");
            for (int i = 0; i < b.Length; i++)
            {
                result.Append("0x" + Convert.ToString((b[i] & 0xff) + 0x100, 16).Substring(1) + ",");
            }
            return result.ToString(0, result.Length - 1);
        }

        /**
		 * int转成16进制的byte
		 * 
		 * @param i
		 * @return
		 */
        /// <summary>
        /// Convert a integer value to Byte arrays with base 16. E.g. 300 = 00000001 00101100
        /// </summary>
        /// <param name="i">Integer value that will be converted to Byte array</param>
        /// <returns>Byte Array that represents the input integer</returns>
        public static byte[] IntToHex(int i) {
            // Convert to Hexdecimal String representation first
            String str = null;
			if (i >= 0 && i < 10) {
				str = "0" + i;
			} else {
                str = String.Format("{0:x}", i);
			}
            // Convert the formated Hexdecimal String to Byte Array.
            return HexStringToByteArray(str);
		}

        /**
		 * 将指定byte数组以16进制的形式打印到控制台
		 * @param b
		 */
        public static void printHexString(byte[] b) {
            StringBuilder sb = new StringBuilder();
			for (int i = 0; i < b.Length; i++) {
				sb.AppendFormat("{0:X2}", b[i] & 0xFF);                
			}
            System.Diagnostics.Debug.WriteLine(sb.ToString());
		}

        /**
		 *把16进制字节转换成int
		 * 
		 * @param b
		 * @return
		 */
        /// <summary>
        /// Convert Byte Array to Integer value
        /// </summary>
        /// <param name="b">Byte Array that will be converted</param>
        /// <returns>Integer value that corresponds to the input byte array</returns>
        public static int byteArrayToInt(byte[] b)
        {
            int result = 0;
            for (int i = 0; i < b.Length; i++)
            {
                // Shift by 8 bits then or with the each byte array item.
                result <<= 8;
                result |= (b[i] & 0xff); //
            }
            return result;
        }

        /**
		 * 异或输入字节流
		 * 
		 * @param b
		 * @param startPos
		 * @param Len
		 * @return
		 */
        /// <summary>
        /// Giving a byte array, perform XOR operation to a subset of the byte array by defining the start position of the subset and the length of the subset after the starting position.
        /// </summary>
        /// <param name="b">Input Byte Array</param>
        /// <param name="startPos">Start Position of the Subset</param>
        /// <param name="Len">Length of the Subset</param>
        /// <returns>A Byte that holds the result of the XOR operation</returns>
        public static byte XorByteStream(byte[] b, int startPos, int Len)
        {
            byte bRet = 0x00;
            for (int i = 0; i < Len; i++)
            {
                bRet ^= b[startPos + i];
            }
            return bRet;
        }

        /**
	     * Gets the subarray from <tt>array</tt> that starts at <tt>offset</tt>.
	     */
        /// <summary>
        /// Extract a subarray from the input array giving the offset value.
        /// The subarray will contain all bytes start from the offset index until the end of the
        /// input array.
        /// </summary>
        /// <param name="array">Input Byte array</param>
        /// <param name="offset">Offset Index</param>
        /// <returns>A Byte array which is a subset of the original input byte array</returns>
        public static byte[] get(byte[] array, int offset)
        {
            return get(array, offset, array.Length - offset);
        }

        /**
         * Gets the subarray of length <tt>length</tt> from <tt>array</tt>
         * that starts at <tt>offset</tt>.
         */
        /// <summary>
        /// Extract a subarray from the input array giving the offset value and the length of the subarray.
        /// </summary>
        /// <param name="array">Input Byte array</param>
        /// <param name="offset">Offset Index</param>
        /// <param name="length">Length of the subarray</param>
        /// <returns>A Byte array which is a subset of the original input byte array</returns>
        public static byte[] get(byte[] array, int offset, int length)
        {
            byte[] result = new byte[length];
            Array.Copy(array, offset, result, 0, length);
            return result;
        }

        internal static Dictionary<string, string> anlysData_hh(string tlv)
        {
            throw new NotImplementedException();
        }

        internal static Dictionary<string, string> anlysData_qf(string tlv)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Parsing and Analyse the tlv data
        /// </summary>
        /// <param name="tlv">tlv data to analyse</param>
        /// <returns>A Hash Table that contains the data to predefined data tags</returns>
        internal static Dictionary<string, string> anlysData_lp(string tlv)
        {
            byte[] uc = Util.HexStringToByteArray(tlv); // Convert the received tlv string to byte array
            int countLen = uc.Length;
            int index = 0;
            // Calculate the length of the ICC Data using the first two Byte within the received tlv message
            int iccdataLen = Util.byteArrayToInt(new byte[] { uc[0], uc[1] });
            index += 2;

            // Extract ICC data from the tlv message
            byte[] iccdataarrs = new byte[iccdataLen];
            Array.Copy(uc, index, iccdataarrs, 0, iccdataLen);
            String iccdata = Util.byteArray2Hex(iccdataarrs);
            index += iccdataLen;
            index += 2; //card type    // Escape another two bytes  

            // Extract Track Block data
            int trackblockLen = Util.byteArrayToInt(new byte[] { uc[index++] });
            byte[] trackblockarrs = new byte[trackblockLen + 1];
            Array.Copy(uc, index - 1, trackblockarrs, 0, trackblockLen + 1);
            String trackblock = Util.byteArray2Hex(trackblockarrs);
            index += trackblockLen;

            // Extract PIN Block data
            int pinblockLen = 12;
            byte[] pinblockarrs = new byte[pinblockLen];
            Array.Copy(uc, index, pinblockarrs, 0, pinblockLen);
            String pinblock = Util.byteArray2Hex(pinblockarrs);
            index += pinblockLen;

            // Extract PSAMID data
            int psamIdLen = 8;
            byte[] psamIdarrs = new byte[psamIdLen];
            Array.Copy(uc, index, psamIdarrs, 0, psamIdLen);
            String psamId = Util.byteArray2Hex(psamIdarrs);
            index += psamIdLen;

            // Extract posID data
            int posIdLen = 10;
            byte[] posIdarrs = new byte[posIdLen];
            Array.Copy(uc, index, posIdarrs, 0, posIdLen);
            String posId = Util.byteArray2Hex(posIdarrs);
            index += posIdLen;

            // Extract MAC Block data
            int macblockLen = 8;
            byte[] macblockarrs = new byte[macblockLen];
            Array.Copy(uc, index, macblockarrs, 0, macblockLen);
            String macblock = Util.byteArray2Hex(macblockarrs);
            index += macblockLen;

            // Extract Format ID data
            int formatIDLen = Util.byteArrayToInt(new byte[] { uc[index++] });
            byte[] formatIDarrs = new byte[formatIDLen];
            Array.Copy(uc, index, formatIDarrs, 0, formatIDLen);
            String formatID = Util.byteArray2Hex(formatIDarrs);
            index += formatIDLen;

            // Extract Masked PAN
            int maskedPANLen = Util.byteArrayToInt(new byte[] { uc[index++] });
            byte[] maskedPANarrs = new byte[maskedPANLen];
            Array.Copy(uc, index, maskedPANarrs, 0, maskedPANLen);
            String maskedPAN = Util.byteArray2Hex(maskedPANarrs);
            index += maskedPANLen;

            // Extract Expiry Date
            int expiryDateLen = Util.byteArrayToInt(new byte[] { uc[index++] });
            byte[] expiryDatearrs = new byte[expiryDateLen];
            Array.Copy(uc, index, expiryDatearrs, 0, expiryDateLen);
            String expiryDate = Util.byteArray2Hex(expiryDatearrs);
            index += expiryDateLen;

            // Extract Service Code
            int serviceCodeLen = Util.byteArrayToInt(new byte[] { uc[index++] });
            byte[] serviceCodearrs = new byte[serviceCodeLen];
            Array.Copy(uc, index, serviceCodearrs, 0, serviceCodeLen);
            String serviceCode = Util.byteArray2Hex(serviceCodearrs);
            index += serviceCodeLen;

            // Extract Card Holder Name Info
            int cardHolderNameLen = Util.byteArrayToInt(new byte[] { uc[index++] });
            byte[] cardholderNamearrs = new byte[cardHolderNameLen];
            Array.Copy(uc, index, cardholderNamearrs, 0, cardHolderNameLen);
            String cardholderName = Util.byteArray2Hex(cardholderNamearrs);
            index += cardHolderNameLen;

            index += 8; // Escape 8 Bytes of data

            // Extract Card Squence Number
            int cardSquNoLen = uc[countLen - 2];
            byte[] cardSquNoArrs = new byte[cardSquNoLen];
            Array.Copy(uc, countLen - 1, cardSquNoArrs, 0, cardSquNoLen);
            String cardSquNo = Util.byteArray2Hex(cardSquNoArrs);
            //		index += cardSquNoLen;
            //		
            //		if (index < countLen) {
            //			expiryDateLen = uc[index++];
            //			byte[] expiryDateArrs = new byte[expiryDateLen];
            //			System.arraycopy(uc, index, expiryDateArrs, 0, expiryDateLen);
            //			expiryDate = Util.byteArray2Hex(expiryDateArrs);
            //			index += expiryDateLen;
            //		}

            // Put Prased Info into a hash table
            Dictionary<String, String> hashtable = new Dictionary<String, String>();

            hashtable.Add("formatID", formatID);
            hashtable.Add("maskedPAN", maskedPAN);
            hashtable.Add("expiryDate", expiryDate);
            hashtable.Add("cardholderName", cardholderName);
            hashtable.Add("serviceCode", serviceCode);
            hashtable.Add("trackblock", trackblock);
            hashtable.Add("psamId", psamId);
            hashtable.Add("posId", posId);
            hashtable.Add("pinblock", pinblock);
            hashtable.Add("macblock", macblock);
            hashtable.Add("iccdata", iccdata);
            hashtable.Add("cardSquNo", cardSquNo);

            return hashtable;
        }
    }
}
