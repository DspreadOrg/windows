﻿using System;
using System.Collections.Generic;

namespace SDK_LIB
{
    public class UpdateFirmware
    {
        private QPOSService esc;

        public UpdateFirmware(QPOSService esc)
        {
            this.esc = esc;
        }

        public void doSingleMac(VPos pos, byte[] cmdBytes)
        {
            CommandDownlink dc = new CommandDownlink(0x11, 0x10, 10, cmdBytes);
            CommandUplink uc = null;
            pos.sendCommand(dc);
            uc = pos.receiveCommandWaitResult(10);
            bool f = esc.checkCmdId(uc);
            if (!f)
            {
                return;
            }
            esc.onRequestCalculateMac(Util.byteArray2Hex(uc.getBytes(0, uc.length())));
        }

        public void doDoubleMac(VPos pos, byte[] cmdBytes)
        {
            CommandDownlink dc = new CommandDownlink(0x11, 0x12, 10, cmdBytes);
            CommandUplink uc = null;
            pos.sendCommand(dc);
            uc = pos.receiveCommandWaitResult(10);
            bool f = esc.checkCmdId(uc);
            if (!f)
            {
                return;
            }
            esc.onRequestCalculateMac(Util.byteArray2Hex(uc.getBytes(0, uc.length())));
        }

        public void doCalculateMac(VPos pos, byte[] cmdBytes)
        {
            CommandDownlink dc = new CommandDownlink(0x11, 0x11, 10, cmdBytes);
            CommandUplink uc = null;
            pos.sendCommand(dc);
            uc = pos.receiveCommandWaitResult(10);
            bool f = esc.checkCmdId(uc);
            if (!f)
            {
                return;
            }
            esc.onRequestCalculateMac(Util.byteArray2Hex(uc.getBytes(0, uc.length())));
        }

        public void doGetPin1071(VPos pos, String updateFirmwareStr, int timeout)
        {
            CommandDownlink dc = new CommandDownlink(0x10, 0x71, timeout, Util.HexStringToByteArray(updateFirmwareStr));
            CommandUplink uc = null;
            pos.sendCommand(dc);
            uc = pos.receiveCommandWaitResult(timeout);
            bool f = esc.checkCmdId(uc);
            if (!f)
            {
                return;
            }
            Dictionary<String, String> hashtable = new Dictionary<String, String>();
            if (uc.result() == 0)
            {
                int index = 2;
                int en_mode = Util.byteArrayToInt(uc.getBytes(index, 2));
                index += 2;
                int pinKsnLen = uc.getByte(index++);
                String pinKsn = Util.byteArray2Hex(uc.getBytes(index, pinKsnLen));
                index += pinKsnLen;

                int pinBlockLen = uc.getByte(index++);
                String pinBlock = Util.byteArray2Hex(uc.getBytes(index, pinBlockLen));
                index += pinBlockLen;

                hashtable.Add("pinKsn", pinKsn);
                hashtable.Add("pinBlock", pinBlock);
                esc.onReturnGetPinResult(hashtable);
            }
            else if (uc.result() == 8)
            {
                esc.onReturnGetPinResult(null);
            }
            else
            {
                esc.onReturnGetPinResult(null);
            }

        }

        public void doUpdateFirmware_tmk_zz(VPos pos, byte[] cmdBytes)
        {
            CommandDownlink dc = new CommandDownlink(0x10, 0xf0, 30, cmdBytes);
            CommandUplink uc = null;
            pos.sendCommand(dc);
            uc = pos.receiveCommandWaitResult(30);
            bool f = esc.checkCmdId(uc);
            if (!f)
            {
                return;
            }

            if (uc.result() == 0)
            {
                esc.onRequestUpdateWorkKeyResult(QPOSService.UpdateInformationResult.UPDATE_SUCCESS);
            }
            else if (uc.result() == 8)
            {
                esc.onRequestUpdateWorkKeyResult(QPOSService.UpdateInformationResult.UPDATE_FAIL);
            }
        }

        public void doUpdateFirmware(VPos pos, byte[] cmdBytes)
        {
            int plenf = cmdBytes.Length;
            int index = 0;
            int offset = 0;
            int countSize = cmdBytes.Length;
            // 288
            byte[] paras = new byte[130];
            Tip.d("len = " + countSize);
            if (countSize % 256 != 0)
            {
                esc.onError(QPOSService.Error.INPUT_INVALID_FORMAT);
                return;
            }

            while (plenf > 0)
            {
                offset = (index / 16);
                if (Util.IntToHex(offset).Length > 1)
                {
                    paras[0] = Util.IntToHex(offset)[0];
                    paras[1] = Util.IntToHex(offset)[1];
                }
                else
                {
                    paras[0] = 0;
                    paras[1] = Util.IntToHex(offset)[0];
                }

                for (int i = 0; i < 128; i++)
                {
                    paras[2 + i] = cmdBytes[index];
                    index++;
                    plenf--;
                }

                CommandDownlink dc = new CommandDownlink(0x40, 0x00, 30, paras);
                CommandUplink uc = null;
                pos.sendCommand(dc);
                uc = pos.receiveCommandWaitResult(10);
                bool f = esc.checkCmdId(uc);
                if (!f)
                {
                    return;
                }

                Tip.d("countSize = " + countSize);
                Tip.d("index = " + index);
                //			float bfb = ((index * 100) / countSize);
            }

            CommandDownlink dcc = new CommandDownlink(0x40, 0x10, 180);
            pos.sendCommand(dcc);
            CommandUplink ucc = null;
            ucc = pos.receiveCommandWaitResult(180);
            bool ff = esc.checkCmdId(ucc);
            if (!ff)
            {
                return;
            }
            Tip.d("=======uc.result()=" + ucc.result());
            if (ucc.result() == 0)
            {
                esc.onRequestUpdateWorkKeyResult(QPOSService.UpdateInformationResult.UPDATE_SUCCESS);
            }
            else if (ucc.result() == 1)
            {
                esc.onRequestUpdateWorkKeyResult(QPOSService.UpdateInformationResult.UPDATE_FAIL);
            }
            else if (ucc.result() == 3)
            {
                esc.onRequestUpdateWorkKeyResult(QPOSService.UpdateInformationResult.UPDATE_PACKET_VEFIRY_ERROR);
            }
            else if (ucc.result() == 4)
            {
                esc.onRequestUpdateWorkKeyResult(QPOSService.UpdateInformationResult.UPDATE_PACKET_LEN_ERROR);
            }


        }

        public void doSetMasterKey(VPos pos, String keyString)
        {
            CommandDownlink dc = new CommandDownlink(0x10, 0xe2, 15, Util.HexStringToByteArray(keyString));
            CommandUplink uc = null;
            pos.sendCommand(dc);
            uc = pos.receiveCommandWaitResult(15);
            bool f = esc.checkCmdId(uc);
            if (!f)
            {
                return;
            }

            if (uc.result() == 0)
            {
                esc.onReturnSetMasterKeyResult(true);
            }
            else if (uc.result() == 8)
            {
                esc.onReturnSetMasterKeyResult(false);
            }
        }
    }
}
