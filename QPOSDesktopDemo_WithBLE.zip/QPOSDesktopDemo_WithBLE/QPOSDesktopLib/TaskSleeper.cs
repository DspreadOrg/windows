﻿using System;
using System.Threading.Tasks;

namespace SDK_LIB
{
    /// <summary>
    /// TaskSleeper Class implements method to put current running task into sleep by calling the Task.Delay() method.
    /// </summary>
    public class TaskSleeper
    {
        /// <summary>
        /// Delay a task by user specified number of miliseconds.
        /// </summary>
        /// <param name="time">Amount of delay specified by the user.</param>
        public static void TaskSleep(int time)
        {
            Task t = Task.Run(async () =>
            {
                await Task.Delay(TimeSpan.FromMilliseconds(time));
            });
            t.Wait();
            return;
        }
    }
}
