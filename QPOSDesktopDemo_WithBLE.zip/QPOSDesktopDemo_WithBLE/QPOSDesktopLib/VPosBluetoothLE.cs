﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Windows.Devices.Bluetooth;
using Windows.Devices.Bluetooth.GenericAttributeProfile;
using Windows.Storage.Streams;
using Windows.Devices.Enumeration;
using System.Runtime.InteropServices.WindowsRuntime;

namespace SDK_LIB
{
    /// <summary>
    /// Implementation of the extension class of VPos class for Bluetooth LE (Bluetooth 4.0) Device Communication.
    /// Implemented By Sheng Zhang
    /// First version implementation date: 1st Feb 2018
    /// </summary>
    public class VPosBluetoothLE : VPos
    {
        #region Constant Variables
        private const string service_uuid = "49535343-fe7d-4ae5-8fa9-9fafd205e455";
        private const string write_uuid = "49535343-8841-43f4-a8d4-ecbe34729bb3";
        private const string notify_uuid = "49535343-1e4d-4bd9-ba61-23c647249616";
        #endregion

        #region private data fields
        /// <summary>
        /// Private field to store the instance of the VPosBluetoothLE class object
        /// </summary>
        private static VPosBluetoothLE g_Instance = null;

        /// <summary>
        /// Private empty byte array to acts for thread lock
        /// </summary>
        private static byte[] blk = { };

        /// <summary>
        /// Private field to store the information about if the Bluetooth device is opened (Connected)
        /// </summary>
        private bool isOpen = false;
        private bool hasConnected = false;

        /// <summary>
        /// Private field to store the information about if the write operation is in progress or not.
        /// False => Data is not writing to device
        /// True => Data is writing to device, ==> Device Reading will be blocked to ensure operation is complete
        /// </summary>
        private bool isWrite = false;

        /// <summary>
        /// Received Data Buffer related variables
        /// </summary>
        private List<byte[]> receivedDataBuffs = new List<byte[]>();
        private byte[] receivedDataBuff = new byte[0];
        private int totalBuffLength = 0;
        private int totalReceivdDataLength = 0;

        /// <summary>
        /// Indicate if the first chunck of data has been received via Bluetooth.
        /// </summary>
        private bool firstSegmentHasRead = false;

        /// <summary>
        /// Indicate if all data is received.
        /// </summary>
        private bool bufferComplete = false;

        /// <summary>
        /// Boolean flag to check if Value Changed Event Handler has been subscribed to.
        /// </summary>
        private bool isValueChangedHandlerRegistered = false;

        /// <summary>
        /// Gatt Device Service and Characteristics
        /// </summary>
        private GattDeviceService deviceRWService = null;
        private GattCharacteristic notify_chara = null;
        private GattCharacteristic write_chara = null;

        /// <summary>
        /// Field to store the information about if the resource is disposed properly
        /// </summary>
        private bool disposed;

        /// <summary>
        /// Boolean Flag indicate pairing operation result.
        /// </summary>
        private bool pairingSuccessful = false;

        #endregion

        #region Properties

        /// <summary>
        /// Getter to return the Bluetooth Device Address. 
        /// </summary>
        private string blueToothAddress = "";
        public string getBlueToothAddress() { return blueToothAddress; }

        /// <summary>
        /// BluetoothLEDevice property -> Store the variable to point to the Bluetooth LE Device instance.
        /// </summary>
        private BluetoothLEDevice btLEDevice;
        public BluetoothLEDevice BtLEDevice
        {
            set { btLEDevice = value; }
        }

        /// <summary>
        /// Setter to assign searched Bluetooth LE Service object to the object used in Demo App
        /// </summary>
        /// <param name="deviceService">Bluetooth LE object from the device search result</param>
        private string btLEDeviceId;
        public void setBlueToothAddress(string btLEDeviceId)
        {
            Tip.d(btLEDeviceId);
            if (btLEDeviceId == null)
            {
                return;
            }
            this.btLEDeviceId = btLEDeviceId;

        }

        #endregion

        #region CTOR
        /// <summary>
        /// Default CTOR, set to private to disable using as default CTOR.
        /// </summary>
        private VPosBluetoothLE()
        {
            disposed = false;
        }

        /// <summary>
        /// Custom CTOR to initialise the class instance
        /// </summary>
        /// <returns>An instance of the VPosBluetoothLE class</returns>
        public static VPosBluetoothLE getInstance()
        {
            lock (blk)
            {
                if (g_Instance == null)
                    g_Instance = new VPosBluetoothLE();
            }
            return g_Instance;
        }

        #endregion

        #region DTOR

        ~VPosBluetoothLE()
        {
            Dispose(false);
        }

        #endregion

        #region Members of VPos class Abstract Methods
        /// <summary>
        /// Implementation of the close() method.
        /// </summary>
        public override void close()
        {
            try
            {
                // Set the flag to trigger the device to reset unfinished transaction and be ready for new trade operation
                setNeedQuit(true);
                isOpen = false; // Set the status of reflect that the device is closed.
            }
            catch (Exception e)
            {
                Tip.d("BT close IOException");
            }
        }

        /// <summary>
        /// The disconnect() Method handles the actual socket disconnection to the Bluetooth Device
        /// Additional Note: For Windows SDK, the QPOS device will only show Bluetooth Symbol when socket connection is
        /// established. If the socket is disposed on Application side, the Windows will disconnect the bluetooth device.
        /// This will turn off the Bluetooth Symbol on the QPOS device. Because the Bluetooth connection to the QPOS is terminated.
        /// It is recommended to not release/dispose socket unless all operations to the device are completed.
        /// </summary>
        public override void disconnect()
        {
            btLEDevice.Dispose();
            write_chara = null;
            notify_chara = null;
            hasConnected = false;
        }

        /// <summary>
        /// Dispose the class instance and release all unmanaged resources.
        /// </summary>
        public override void Dispose()
        {
            // Call the privately implemented Dispose() method to fully dispose the current instance

            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Modified version of the open() method. The modified version will check if a valid socket has been connected. If a socket has been
        /// established, then the program will not initiate a new socket and try to connect it (this will cause crash due to only one socket can
        /// be assigned to a specific device).
        /// </summary>
        /// <returns>Boolean Value to indicate if operation is successful</returns>
        public override bool open()
        {
            if (isOpen)
            {
                return true;
            }

            if (hasConnected)
            {
                return true;
            }

            Tip.d("Run to set BTLED");
            Task<bool> setDeviceTask = SetDevice(btLEDeviceId);
            while ((!setDeviceTask.IsCanceled) && (!setDeviceTask.IsCompleted) && (!setDeviceTask.IsFaulted))
            {
                setDeviceTask.Wait(10);
            }
            Tip.d("Finish Run to set BTLED");
            if (!setDeviceTask.Result)
            {
                Tip.d("Set Device Task unsuccessful");
                hasConnected = false;
                return false;
            }
            var trialCounter = 0;
            Task<bool> notifyTask = SetUpNotify();
            while ((!notifyTask.IsCanceled) && (!notifyTask.IsCompleted) && (!notifyTask.IsFaulted) && trialCounter < 50)
            {
                notifyTask.Wait(100);
                trialCounter++;
            }
            if (!notifyTask.Result)
            {
                throw new InvalidOperationException("Unable to subscribe to Notification Characteristics.");
            }
            hasConnected = true;
            return notifyTask.Result;
        }

        /// <summary>
        /// Implementation of the read() method
        /// </summary>
        /// <returns>Data byte array that has been read from device response</returns>
        public override byte[] read()
        {
            byte[] b = new byte[0];
            try
            {
                if (isWrite)
                {
                    Tip.d("VposBluetooth: write error");
                    return b;
                }

                b = readResponse();
                Tip.d("[read:" + Util.byteArray2Hex(b) + "]");
            }
            catch (Exception e)
            {
                b = new byte[0];
                Tip.d("BT read IOException");
            }
            return b;
        }

        /// <summary>
        /// Implementation of the write() Method.
        /// </summary>
        /// <param name="msgArr">Message byte array to be written to the device</param>
        public override void write(byte[] msgArr)
        {
            totalBuffLength = 0;
            totalReceivdDataLength = 0;
            firstSegmentHasRead = false;
            bufferComplete = false;
            var trialCounter = 0;
            Task<bool> writeTask = CharacteristicWrite(msgArr);
            while ((!writeTask.IsCanceled) && (!writeTask.IsCompleted) && (!writeTask.IsFaulted) && trialCounter < 50)
            {
                writeTask.Wait(100);
                trialCounter++;
            }
            if (!writeTask.Result)
            {
                throw new InvalidOperationException("Unable to write to written Characteristics.");
            }
            
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Privately implemented method to dispose the instance of the Bluetooth LE class object.
        /// It disconnects the device, reset the instance variable and set the dispose status to true
        /// </summary>
        /// <param name="isFullDispose">If this boolean switch is set to true, this method will run the close() 
        /// Method to disconnect the bluetooth device and reset the instance variable to null. Otherwise it 
        /// will simply update the status of dispose variable</param>
        private void Dispose(bool isFullDispose)
        {
            // Check if the instance is already disposed. this.disposed = true ==> Disposed
            // this.disposed = false ==> Not disposed
            if (!this.disposed)
            {
                if (isFullDispose)
                {
                    close(); // Close the device communication
                    disconnect(); // Disconnect the socket connect to the Bluetooth Device
                    g_Instance = null; // Reset the instance variable
                }
                disposed = true;
            }
        }

        #region Set Device Method
        /// <summary>
        /// Dispose Existing Bluetooth Device Instance
        /// </summary>
        private void ClearBluetoothLEDevice()
        {
            btLEDevice?.Dispose();
            btLEDevice = null;
        }

        /// <summary>
        /// Set up the instance of the BluetoothLEDevice class, which will be used for data read/write operation.
        /// </summary>
        /// <param name="btLEDeviceId">Bluetooth Device ID String</param>
        /// <returns>Boolean value to indicate set device operation is successful or not</returns>
        public async Task<bool> SetDevice(string btLEDeviceId)
        {
            ClearBluetoothLEDevice();

            this.btLEDevice = await BluetoothLEDevice.FromIdAsync(btLEDeviceId);
            
            // If the device that requests to open hasn't paired, then pair the device first
            // Otherwise no service/characteristics will be available for data transmission
            if (!btLEDevice.DeviceInformation.Pairing.IsPaired)
            {
                //waitForBTPairingResult.Reset();
                //Pairing();
                //waitForBTPairingResult.WaitOne();
                return false;
            }
            var enumComplete = false;
            var timeOutCounter = 0;
            while (!enumComplete && timeOutCounter < 10)
            {
                enumComplete = enumServiceAndCharacs();
                Task.Delay(500);
            }
            return enumComplete;
        }
        #endregion

        /// <summary>
        /// Enumerate all services and characteristics to ensure compactable device is connected.
        /// </summary>
        /// <returns>Boolean value that indicate if the device is compactable</returns>
        private bool enumServiceAndCharacs()
        {
            bool service_available = false;
            bool notify_available = false;
            bool write_available = false;
            foreach (var service in btLEDevice.GattServices)
            {
                if (service.Uuid.ToString().CompareTo(service_uuid) == 0)
                {
                    service_available = true;
                    deviceRWService = service;
                    break;
                }
            }
            if (!service_available)
            {
                return false;
            }
            IReadOnlyList<GattCharacteristic> characteristics = deviceRWService.GetAllCharacteristics();
            foreach (var c in characteristics)
            {
                if (c.Uuid.ToString().CompareTo(write_uuid) == 0)
                {
                    write_available = true;
                    write_chara = c;
                }
                if (c.Uuid.ToString().CompareTo(notify_uuid) == 0)
                {
                    notify_available = true;
                    notify_chara = c;
                }
            }
            return notify_available && write_available;
        }

        #region Notify Methods

        /// <summary>
        /// Method to subscribe to Notify Characteristics
        /// Notify Characteristics is important to subscribe to as it will be the channel to receive any reponse data from the device
        /// once a command is issued.
        /// </summary>
        /// <returns>Boolean value indicate if the task execute successfully</returns>
        private async Task<bool> SetUpNotify()
        {
            // BT_Code: Must write the CCCD in order for server to send notifications.
            // We receive them in the ValueChanged event handler.
            // Note that this sample configures either Indicate or Notify, but not both.
            Tip.d("Run to SetUpNotify()");
            var result = await
                    notify_chara.WriteClientCharacteristicConfigurationDescriptorAsync(
                        GattClientCharacteristicConfigurationDescriptorValue.Notify);
            if (result == GattCommunicationStatus.Success)
            {
                AddValueChangedHandler();
                Tip.d("Successfully registered for notifications");
                return true;
            }
            else
            {
                Tip.d($"Error registering for notifications");
                return false;
            }
        }
        /// <summary>
        /// Event subscription function.
        /// </summary>
        private void AddValueChangedHandler()
        {
            if (!isValueChangedHandlerRegistered)
            {
                notify_chara.ValueChanged += Characteristic_ValueChanged;
                isValueChangedHandlerRegistered = true;
            }
        }

        /// <summary>
        /// Important method to be called when the Notify Characteristic changes its value (Which means new data is transmitted from the 
        /// Bluetooth LE device)
        /// </summary>
        /// <param name="sender">GattCharacteristic Object, should be the Notify Characteristic in this case</param>
        /// <param name="args">Any event arguments/data that are passed along with the event call</param>
        private void Characteristic_ValueChanged(GattCharacteristic sender, GattValueChangedEventArgs args)
        {
            // BT_Code: An Indicate or Notify reported that the value has changed.
            // Buff the received data
            var newValue = args.CharacteristicValue.ToArray();
            totalBuffLength += newValue.Length;
            if (!firstSegmentHasRead)
            {
                if (newValue.Length >= 3)
                {
                    // Obtain the information regarding the size of the data packet that should be received.
                    byte[] dataLengthBytes = { newValue[1], newValue[2] };
                    var dataLength = Util.byteArrayToInt(dataLengthBytes);
                    totalReceivdDataLength = dataLength + 4;
                }
                firstSegmentHasRead = true;
            }
            Tip.d("Received Bytes Length: " + newValue.Length);
            Tip.d("Received Data Bytes: " + Util.byteArray2Hex(newValue));
            receivedDataBuffs.Add(newValue);
            if(totalBuffLength >= totalReceivdDataLength)
            {
                // Sets the private globel flag to true to indicate all data has been received.
                bufferComplete = true;
            }
        }

        #endregion

        #region Write to Characteristics Method
        /// <summary>
        /// A special version of performing the Characteristic Write operation without using the await keyword to execute the async write operation.
        /// </summary>
        /// <param name="writeBuffer">IBuffer Datastream buffer that contains the original bytes in the message array</param>
        private void CharacteristicWrite_NoAwait(IBuffer writeBuffer)
        {
            var result = write_chara.WriteValueAsync(writeBuffer);
        }

        /// <summary>
        /// Implementation of the Characteristic Write operation.
        /// Used to write data to the dedicated characteristic of the Bluetooth LE device.
        /// </summary>
        /// <param name="msgArr">Array of bytes contain the data to be written into the device.</param>
        /// <returns>Boolean value to incidate if the operation executes successfully</returns>
        private async Task<bool> CharacteristicWrite(byte[] msgArr)
        {
            isWrite = true;
            receivedDataBuffs = new List<byte[]>();
            IBuffer writeBuffer = msgArr.AsBuffer();
            try
            {
                Tip.d("CMD: " + Util.byteArray2Hex(msgArr));
                // BT_Code: Writes the value from the buffer to the characteristic.

                // This block of if statement is to address the special case of issuing a resetQPOSStatus command.
                // By executing this command, the QPOS hardware will terminate on going process and reset the device status.
                // However, it currently influences the BLE communication because Windows SDK character.WriteValueAsync() runs asynchronously
                // and it will look for the GattCommunicationStatus enum to be returned if the call is set with await keyword.
                // When execute resetQPOSStatus command, the awaited character.WriteValueAsync() method unable to receive the returned
                // GattCommunicationStatus enum and thus runs into a dead lock.
                if (Util.byteArray2Hex(msgArr).CompareTo("4D00062000000500006E")==0)
                {
                    CharacteristicWrite_NoAwait(writeBuffer);
                    isWrite = false;
                    return true;
                }

                var result = await write_chara.WriteValueAsync(writeBuffer);
                if (result == GattCommunicationStatus.Success)
                {
                    Tip.d("Successfully wrote value to device");
                    isWrite = false;
                    return true;
                }
                else
                {
                    Tip.d($"Write failed");
                    isWrite = false;
                    return false;
                }
            }
            catch (Exception ex) when ((uint)ex.HResult == 0x80650003 || (uint)ex.HResult == 0x80070005)
            {
                // E_BLUETOOTH_ATT_WRITE_NOT_PERMITTED or E_ACCESSDENIED
                // This usually happens when a device reports that it support writing, but it actually doesn't.
                Tip.d(ex.Message);
                isWrite = false;
                return false;
            }
        }
        #endregion

        #region Read Methods
        /// <summary>
        /// Methods that used to call the readInputStream() methods and varify the data integraty.
        /// Valid data bytes array will only return if the received data bytes passes all the checks.
        /// </summary>
        /// <returns>The array of bytes of received data to be further passed to upper layer of the SDK</returns>
        private byte[] readResponse()
        {
            if (isNeedQuit())
                {
                    return new byte[0];
                }
            readInputStream(); // Call the readInputStream() Method to check the data buffer within this class.
            if(receivedDataBuff.Length > 3) // Check the data length
            {
                if (receivedDataBuff[0] != 0X4d) // Check the data header.
                {
                    return new byte[0];
                }
                byte[] dataLengthBytes = new byte[] { receivedDataBuff[1], receivedDataBuff[2] };
                var dataLength = Util.byteArrayToInt(dataLengthBytes)+1+3;
                if(dataLength != receivedDataBuff.Length) // Verify the received data buffer bytes length
                {
                    return new byte[0];
                }
                return receivedDataBuff;
            }
            else
            {
                return new byte[0];
            }
        }

        /// <summary>
        /// Method to reads the internal buffer and provide outer procedure if the internal buffer reading operation is not successful.
        /// </summary>
        private void readInputStream()
        {
            while (!bufferComplete)
            {
                Task.Delay(10);
            }
            Task<bool> tsk = readInternal(); // Core function to be called to read the buffered data received from the Bluetooth device.
            while ((!tsk.IsCanceled) && (!tsk.IsCompleted) && (!tsk.IsFaulted))
            {
                tsk.Wait(10);
            }
            bool ret = tsk.Result;
            if (!ret)
            {
                do
                {
                    Tip.d("quit read");
                    if (isNeedQuit())
                    {
                        return;
                    }
                    tsk = readInternal();
                    while ((!tsk.IsCanceled) && (!tsk.IsCompleted) && (!tsk.IsFaulted))
                    {
                        tsk.Wait(10);
                    }
                    ret = tsk.Result;
                } while (!ret);
            }
        }

        /// <summary>
        /// Combine/Read data from internal buffer within the Class.
        /// The data buffer is filled with response data received from the Bluetooth Device
        /// </summary>
        /// <returns>Boolean value to indicate if the operation is successful or not.</returns>
        private async Task<bool> readInternal()
        {
            if(receivedDataBuffs.Count == 0)
            {
                Tip.d("Received Data Buffer is empty, wrong!");
                return false;
            }
            receivedDataBuff = new byte[totalReceivdDataLength];
            int offset = 0;
            foreach (var bufferChunk in receivedDataBuffs)
            {
                System.Buffer.BlockCopy(bufferChunk, 0, receivedDataBuff, offset, bufferChunk.Length);
                offset += bufferChunk.Length;
            }
            return true;
        }
        #endregion

        #region Pairing (Note: The pairing functions are implemented here. They are the same as the ones used in the UI class.)
        /// <summary>
        /// Boolean flag to prevent multiple executions while one execution is currently in progress
        /// </summary>
        private bool isBusy = false;
        /// <summary>
        /// Pairing Method
        /// </summary>
        private async Task<bool> blePairing(BluetoothLEDevice btLEDevice)
        {
            // Do not allow a new Pair operation to start if an existing one is in progress.
            if (isBusy)
            {
                return false;
            }

            isBusy = true;

            Tip.d("Pairing started. Please wait...");

            // BT_Code: Pair the device.
            DevicePairingResult result = await btLEDevice.DeviceInformation.Pairing.PairAsync(DevicePairingProtectionLevel.None);
            var status = result.Status == DevicePairingResultStatus.Paired || result.Status == DevicePairingResultStatus.AlreadyPaired;
            isBusy = false;

            return status;
        }

        private async void Pairing()
        {
            pairingSuccessful = await blePairing(btLEDevice);
            //waitForBTPairingResult.Set();
        }

        #endregion

        #endregion
    }
}
