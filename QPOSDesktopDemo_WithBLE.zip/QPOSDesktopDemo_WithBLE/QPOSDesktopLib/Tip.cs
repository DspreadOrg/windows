﻿using System;


namespace SDK_LIB
{
    /// <summary>
    /// Tip Class is implemented to provide means to log messages for SDK Debugging.
    /// </summary>
    public class Tip
    {
        // Global Static string variable to store the name of the Application
        // To provide prefix for the debug message.
        private static string APP_NAME = "POS_SDK";

        /// <summary>
        /// Function to write the message to debugger. Same as methods w() and d().
        /// </summary>
        /// <param name="aMessage">Message to be written to console during debugging</param>
        public static void i(string aMessage)
        {
            System.Diagnostics.Debug.WriteLine(APP_NAME + ": " + aMessage);
        }

        /// <summary>
        /// Function to write the message to debugger. Same as methods i() and d().
        /// </summary>
        /// <param name="aMessage">Message to be written to console during debugging</param>
        public static void w(string aMessage)
        {
            System.Diagnostics.Debug.WriteLine(APP_NAME + ": " + aMessage);
        }

        /// <summary>
        /// Function to write the exception message to debugger. Function Overload to method w(string aMessage).
        /// </summary>
        /// <param name="aExp">Exception Object</param>
        public static void w(Exception aExp)
        {
            System.Diagnostics.Debug.WriteLine(APP_NAME + ": " + aExp.Message);
        }

        /// <summary>
        /// Function to write the message to debugger. Same as methods i() and w().
        /// </summary>
        /// <param name="aMessage">Message to be written to console during debugging</param>
        public static void d(string aMessage)
        {
            System.Diagnostics.Debug.WriteLine(APP_NAME + ": " + aMessage);
        }

        /// <summary>
        /// Function to write the number/error code to debugger.
        /// </summary>
        /// <param name="num">Integer to be written to console during debugging</param>
        public static void a(int num)
        {
            System.Diagnostics.Debug.WriteLine(APP_NAME + ": " + Convert.ToString(num));
        }
    }
}
