﻿using System;
using System.IO;
using System.IO.IsolatedStorage;

namespace SDK_LIB
{
    public class Signature
    {
        private QPOSService esc;

        public Signature(QPOSService esc)
        {
            this.esc = esc;
        }

        public void doSignature(VPos pos)
        {
            CommandDownlink dc = null;
            CommandUplink uc = null;
            dc = new CommandDownlink(0x41, 0x40, 300);
            pos.sendCommand(dc);

            uc = pos.receiveCommandWaitResult(300);
            bool f = esc.checkCmdId(uc);
            if (f)
            {
                //			Tip.d("sig==:"+Util.byteArray2Hex(uc.getBytes(0, uc.length())));
                //			
                //			int index;
                //			index = 0;
                //			int width = Util.byteArrayToInt(new byte[]{uc.getByte(index++)});
                //			int high = uc.getByte(index++);
                //			
                //			int sigLen = Util.byteArrayToInt(uc.getBytes(index, 2));
                //			index += 2;
                //			
                //			byte[] paras = uc.getBytes(index, sigLen);	
                //			index += sigLen;
                //			
                //			int phoneLen = uc.getByte(index++);
                //			String phone = new String(uc.getBytes(index, phoneLen));
                //			
                //			
                //			byte[] arrs = readSignatureData(paras, width, high);

                //			esc.onRequestSignatureResult(arrs);
                esc.onRequestSignatureResult(uc.getBytes(0, uc.length()));
                //			String bmpString = "424D3E000000000000003E0000002800000080000000C0FFFFFF01000100000000000000000000000000000000000000000000000000FFFFFF0000000000010002001000000000000000000000002108024013FC0000000000000000000011100220564400000000000000000000092002003840000000000000000000003FF87FFC13FC00000000000000000000200802807C8000000000000000000000200804882920000000000000000000003FF8049029F800000000000000000000200804A0282000000000000000000000200808C02820000000000000000000003FF808802BFC00000000000000000000200811842C2000000000000000000000200826842820000000000000000000002038407C4020000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";

            }
        }

        private byte[] readSignatureData(byte[] paras, int width, int high)
        {
            FileStream file = createMyFile("a13", "a.bmp");

            if (file == null)
            {
                return new byte[0];
            }
            saveBmp(paras, file, width, high);
            byte[] arrs = readBmp(file);
            Tip.d("arrs===" + Util.byteArray2Hex(arrs));
            return arrs;
        }

        private byte[] readBmp(FileStream file)
        {
            byte[] a = new byte[0];
            try
            {
                a = new byte[(int)file.Length];
                file.Read(a, 0, (int)file.Length);
            }
            catch (IOException e)
            {
                Tip.d("IOException at saveBmp");
            }
            //file.Close();
            return a;
        }

        private void saveBmp(byte[] rawData, FileStream file, int width, int high)
        {
            try
            {
                FileStream bw = file;
                // BitmapFileHeader,文件头           
                bw.WriteByte((0x42));
                bw.WriteByte((0x4D)); //Identifier,2 bytes "BM"

                int itmp = rawData.Length + 62;
                bw.WriteByte((byte)itmp);
                bw.WriteByte((byte)(itmp >> 8));
                bw.WriteByte((byte)(itmp >> 16));
                bw.WriteByte((byte)(itmp >> 24)); //File size,整个文件的字节大小
                bw.WriteByte((0));
                bw.WriteByte((0));
                bw.WriteByte((0));

                bw.WriteByte((0)); //reserved1
                bw.WriteByte((0));

                bw.WriteByte((0)); //reserved2
                bw.WriteByte((0));

                bw.WriteByte((62)); //Bitmap data offset，图像数据相对于文件开始处的偏移量
                bw.WriteByte((0));
                bw.WriteByte((0));
                bw.WriteByte((0));

                // BitmapInfoHeader,信息头
                bw.WriteByte((40)); //BitmapInfoHeader结构的大小,在windows系统中=40字节
                bw.WriteByte((0));
                bw.WriteByte((0));
                bw.WriteByte((0));

                bw.WriteByte((byte)(width)); //Width
                bw.WriteByte((0));
                bw.WriteByte((0));
                bw.WriteByte((0));

                int h = -(high);
                bw.WriteByte((byte)h); //Height,<0:第一行数据为图像左上角开始,>0:第一行数据为图像左下角开始
                bw.WriteByte((byte)(h >> 8));
                bw.WriteByte((byte)(h >> 16));
                bw.WriteByte((byte)(h >> 24));

                bw.WriteByte((1)); //Planes
                bw.WriteByte((0));

                bw.WriteByte((1)); //BitCount
                bw.WriteByte((0));

                bw.WriteByte((0)); //Compression,=0:不压缩
                bw.WriteByte((0));
                bw.WriteByte((0));
                bw.WriteByte((0));

                itmp = rawData.Length;
                bw.WriteByte((byte)itmp);
                bw.WriteByte((byte)(itmp >> 8));
                bw.WriteByte((byte)(itmp >> 16));
                bw.WriteByte((byte)(itmp >> 24)); //用字节数表示的位图数据的大小
                bw.WriteByte((0));
                bw.WriteByte((0));
                bw.WriteByte((0));

                bw.WriteByte((0)); //位图的水平分辨率，水平3780，0也可以
                bw.WriteByte((0));
                bw.WriteByte((0));
                bw.WriteByte((0));

                bw.WriteByte((0)); //位图的垂直分辨率，垂直3780，0也可以
                bw.WriteByte((0));
                bw.WriteByte((0));
                bw.WriteByte((0));

                bw.WriteByte((0)); //图像使用的颜色数，=0:BitCount定义的颜色数全部使用
                bw.WriteByte((0));
                bw.WriteByte((0));
                bw.WriteByte((0));

                bw.WriteByte((0)); //图像重要的颜色数，=0:全部重要
                bw.WriteByte((0));
                bw.WriteByte((0));
                bw.WriteByte((0));

                // 以下是颜色列表索引项
                bw.WriteByte((0xFF)); //0，白色
                bw.WriteByte((0xFF));
                bw.WriteByte((0xFF));
                bw.WriteByte((0x00));

                bw.WriteByte((0x00)); //1，黑色            
                bw.WriteByte((0x00));
                bw.WriteByte((0x00));
                bw.WriteByte((0x00));

                // 以下是RAW颜色数据
                bw.Write(rawData, 0, rawData.Length);
                bw.Flush();
                //
                //bw.Close();
            }
            catch (IOException e)
            {
                Tip.d("IOException at saveBmp");
            }
            //file.Close();
        }

        public static FileStream createMyFile(String path, String fileName)
        {
            string fpath = path + "-" + fileName;
            using (FileStream fs = new FileStream(fpath, FileMode.Append))
            {
                return fs;
            }


                //using (IsolatedStorageFile storage = IsolatedStorageFile.GetUserStoreForApplication())
                //{
                //    if (!storage.FileExists(fpath))
                //    {
                //        return storage.CreateFile(fpath);
                //    }
                //    else
                //    {
                //        return storage.OpenFile(fpath, FileMode.Open, FileAccess.ReadWrite);
                //    }
                //}
              
        }
    }
}
