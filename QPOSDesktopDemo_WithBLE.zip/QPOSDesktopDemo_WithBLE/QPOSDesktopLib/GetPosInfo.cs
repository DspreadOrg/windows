﻿using System;
using System.Collections.Generic;

namespace SDK_LIB
{
    /// <summary>
    /// GetPosInfo class implements a collection of methods that extracts various
    /// type of information and settings from the device.
    /// </summary>
    public class GetPosInfo
    {
        /// <summary>
        /// Private field to store an instance of QPOSService class.
        /// </summary>
        private QPOSService esc;

        /// <summary>
        /// CTOR
        /// </summary>
        /// <param name="esc">QPOSService object</param>
        public GetPosInfo(QPOSService esc)
        {
            this.esc = esc;
        }

        /// <summary>
        /// Method to set the sleep timeout parameter on the QPOS device
        /// </summary>
        /// <param name="pos">POS Object</param>
        /// <param name="timeout">Timeout Value</param>
        public void doSetSleepTimeout(VPos pos, int timeout)
        {
            CommandUplink uc = setSleepTime(pos, timeout); // Perform the function
            bool f = esc.checkCmdId(uc); // Check if command executed successfully
            esc.onReturnSetSleepTimeResult(f); // Pass the response to the event handler
        }

        /// <summary>
        /// Method to return the ID of the POS Device.
        /// </summary>
        /// <param name="pos">POS object</param>
        public void doGetPosId(VPos pos)
        {
            Tip.d("doGetPosId: entry*************");
            CommandUplink uc = getPosId(pos); // Perform the function
            bool f = esc.checkCmdId(uc);
            if (!f) return; // If the command doesn't execute successfully then terminate the function call

            // Parse each data byte based on the communication protocol
            Tip.d("pos id : " + Util.byteArray2Hex(uc.getBytes(0, uc.length())));
            int countLen = uc.length(); // count total message length
            int index = 0;

            // Parse PSAM ID
            int psamIdLen = uc.getByte(index++);
            String psamId = Util.byteArray2Hex(uc.getBytes(index, psamIdLen));
            index += psamIdLen;

            // Parse POS ID
            int posIdLen = uc.getByte(index++);
            String posId = Util.byteArray2Hex(uc.getBytes(index, posIdLen));
            index += posIdLen;

            String merchantId = "";
            String vendorCode = "";
            String deviceNumber = "";
            String psamNo = "";

            // Parse MERCHANT ID
            int merchantIdLen = uc.getByte(index++);//商户ID 银联标准的 15字节
            byte[] btmp = uc.getBytes(index, merchantIdLen);
            merchantId = System.Text.Encoding.UTF8.GetString(btmp, 0, btmp.Length);
            index += merchantIdLen;

            // Parse VENDOR ID
            int vendorCodeLen = uc.getByte(index++);//厂商编号
            btmp = uc.getBytes(index, vendorCodeLen);
            vendorCode = System.Text.Encoding.UTF8.GetString(btmp, 0, btmp.Length);
            index += vendorCodeLen;

            if (index < countLen)
            {
                // Parse DEVICE Serial No.
                int deviceNumberLen = uc.getByte(index++);//设备编号
                btmp = uc.getBytes(index, deviceNumberLen);
                deviceNumber = System.Text.Encoding.UTF8.GetString(btmp, 0, btmp.Length);
                index += deviceNumberLen;

                // Parse PSAM No.
                int psamNoLen = uc.getByte(index++);//psam编号
                btmp = uc.getBytes(index, psamNoLen);
                psamNo = System.Text.Encoding.UTF8.GetString(btmp, 0, btmp.Length);
                index += psamNoLen;
            }

            Dictionary<String, String> ksnDict = new Dictionary<String, String>();
            ksnDict.Add("posId", posId);
            ksnDict.Add("psamId", psamId);
            ksnDict.Add("merchantId", merchantId);
            ksnDict.Add("vendorCode", vendorCode);
            ksnDict.Add("deviceNumber", deviceNumber);
            ksnDict.Add("psamNo", psamNo);
            esc.onQposIdResult(ksnDict);

        }

        /// <summary>
        /// Method to return the RSA stored in the POS Device.
        /// </summary>
        /// <param name="pos">POS object</param>
        public void doGetPosRsa(VPos pos)
        {
            Tip.d("doGetPosRsa: entry*************");
            CommandUplink uc = getPosRsa(pos);
            bool f = esc.checkCmdId(uc);
            if (!f) return;

            Tip.d("RSA id : " + Util.byteArray2Hex(uc.getBytes(0, uc.length())));
            int countLen = uc.length()-7;
            int index = 2;
            String RSAkey = Util.byteArray2Hex(uc.getBytes(index, countLen));

            esc.onQposRSAResult(RSAkey);

        }

        /// <summary>
        /// Method to Set the Format ID stored in the POS Device.
        /// The command is sent in Raw Byte Array format
        /// </summary>
        /// <param name="pos">POS object</param>
        /// <param name="deviceCommandString">Command String that will specify the format ID</param>
        public void doSetFormatID(VPos pos,String deviceCommandString)
        {
            Tip.d("doSetFormatID: entry*************");
            CommandUplink uc = setFormatID(pos, deviceCommandString);
            bool f = esc.checkCmdId(uc);
            Tip.d("Result : " + Util.byteArray2Hex(uc.getBytes(0, uc.length())));
            bool isSuccess = false;
            if (f)
            {
                isSuccess = true;                
            }
            else {isSuccess=false;}
            esc.onQposSendRawCommand(isSuccess);

        }

        /// <summary>
        /// Method to Get the KSN that is stored in the POS Device.
        /// </summary>
        /// <param name="pos">POS object</param>
        public void doKsn(VPos pos)
        {
            CommandUplink uc = getKsn(pos);

            bool f = esc.checkCmdId(uc);
            if (!f) return;
            Tip.d("ksn : " + Util.byteArray2Hex(uc.getBytes(0, uc.length())));

            // Parse UID
            int index = 0;
            int uidLen = uc.getByte(index++);
            String uid = Util.byteArray2Hex(uc.getBytes(index, uidLen));
            index += uidLen;

            // Parse trackKSN
            int trackKsnLen = uc.getByte(index++);
            String trackKsn = Util.byteArray2Hex(uc.getBytes(index, trackKsnLen));
            index += trackKsnLen;

            // Parse emvKSN
            int emvKsnLen = uc.getByte(index++);
            String emvKsn = Util.byteArray2Hex(uc.getBytes(index, emvKsnLen));
            index += emvKsnLen;

            // Parse PIN KSN
            int pinKsnLen = uc.getByte(index++);
            String pinKsn = Util.byteArray2Hex(uc.getBytes(index, pinKsnLen));
            index += pinKsnLen;

            // Collect all KSNs into a Hash Table
            Dictionary<String, String> ksnDict = new Dictionary<String, String>();
            ksnDict.Add("pinKsn", pinKsn);
            ksnDict.Add("trackKsn", trackKsn);
            ksnDict.Add("emvKsn", emvKsn);
            ksnDict.Add("uid", uid);
            esc.onQposIdResult(ksnDict);

        }

        /// <summary>
        /// Method to return the summary of the POS Device.
        /// </summary>
        /// <param name="pos">POS object</param>
        public void doGetPosInfo(VPos pos)
        {
            // Similar procedure to doGetPosId()
            CommandUplink uc = getPosInfo(pos);
            bool f = esc.checkCmdId(uc);
            if (!f) return;
            Tip.d("device info : " + Util.byteArray2Hex(uc.getBytes(0, uc.length())));

            int countLen = uc.length();
            int index = 0;
            int bootloaderVersionLen = uc.getByte(index++);

            // Parse Bootloader Version
            byte[] btmp = uc.getBytes(index, bootloaderVersionLen);
            String bootloaderVersion = System.Text.Encoding.UTF8.GetString(btmp, 0, btmp.Length);
            index += bootloaderVersionLen;

            // Parse Firmware Version
            int firmwareVersionLen = uc.getByte(index++);
            btmp = uc.getBytes(index, firmwareVersionLen);
            String firmwareVersion = System.Text.Encoding.UTF8.GetString(btmp, 0, btmp.Length);
            index += firmwareVersionLen;

            // Parse Hardware Version
            int hardwareVersionLen = uc.getByte(index++);
            btmp = uc.getBytes(index, hardwareVersionLen);
            String hardwareVersion = System.Text.Encoding.UTF8.GetString(btmp, 0, btmp.Length);
            index += hardwareVersionLen;

            // Parse Battery Level
            int batteryLevelLen = uc.getByte(index++);
            Tip.d("batteryLevelLen:" + batteryLevelLen);
            String batteryLevel = Util.byteArrayToInt(uc.getBytes(index, batteryLevelLen)) + " mV";
            index += batteryLevelLen;

            // Parse Charging Status
            int isChargingLen = uc.getByte(index++);
            String isCharging = Util.byteArray2Hex(uc.getBytes(index, isChargingLen));
            if ("00" == isCharging)
            {
                isCharging = "false";
            }
            else
            {
                isCharging = "true";
            }
            index += isChargingLen;

            // Parse USB Connection Status
            int isUsbConnectedLen = uc.getByte(index++);
            String isUsbConnected = Util.byteArray2Hex(uc.getBytes(index, isUsbConnectedLen));
            if ("00"==(isUsbConnected))
            {
                isUsbConnected = "false";
            }
            else
            {
                isUsbConnected = "true";
            }
            index += isUsbConnectedLen;

            // Parse Track1 Support Info
            int isSupportedTrack1Len = uc.getByte(index++);
            String isSupportedTrack1 = Util.byteArray2Hex(uc.getBytes(index, isSupportedTrack1Len));
            if ("00"==(isSupportedTrack1))
            {
                isSupportedTrack1 = "false";
            }
            else
            {
                isSupportedTrack1 = "true";
            }
            index += isSupportedTrack1Len;

            // Parse Track2 Support Info
            int isSupportedTrack2Len = uc.getByte(index++);
            String isSupportedTrack2 = Util.byteArray2Hex(uc.getBytes(index, isSupportedTrack2Len));
            if ("00"==(isSupportedTrack2))
            {
                isSupportedTrack2 = "false";
            }
            else
            {
                isSupportedTrack2 = "true";
            }
            index += isSupportedTrack2Len;

            // Parse Track3 Support Info
            int isSupportedTrack3Len = uc.getByte(index++);
            String isSupportedTrack3 = Util.byteArray2Hex(uc.getBytes(index, isSupportedTrack3Len));
            if ("00"==(isSupportedTrack3))
            {
                isSupportedTrack3 = "false";
            }
            else
            {
                isSupportedTrack3 = "true";
            }
            index += isSupportedTrack3Len;

            // Parse Data Encryption Mode (This could be optional Field)
            String dataEncryptionMode = "";
            if (index < countLen)
            {
                int dataEncryptionModeLen = uc.getByte(index++);//加密方式
                dataEncryptionMode = Util.byteArray2Hex(uc.getBytes(index, dataEncryptionModeLen));
                index += dataEncryptionModeLen;
            }

            // Parse Flag to see if Work Key will be updated (This could be optional Field)
            String updateWorkKeyFlag = "";
            if (index < countLen)
            {
                int updateWorkKeyFlagLen = uc.getByte(index++);//
                updateWorkKeyFlag = Util.byteArray2Hex(uc.getBytes(index, updateWorkKeyFlagLen));

                if ("00" == (updateWorkKeyFlag))
                {
                    updateWorkKeyFlag = "false";
                }
                else
                {
                    updateWorkKeyFlag = "true";
                }
                index += updateWorkKeyFlagLen;
            }

            // Put all parsed data into a hashtable
            Dictionary<String, String> deviceInfoData = new Dictionary<String, String>();

            deviceInfoData.Add("isSupportedTrack1", isSupportedTrack1);
            deviceInfoData.Add("isSupportedTrack2", isSupportedTrack2);
            deviceInfoData.Add("isSupportedTrack3", isSupportedTrack3);
            deviceInfoData.Add("bootloaderVersion", bootloaderVersion);
            deviceInfoData.Add("firmwareVersion", firmwareVersion);
            deviceInfoData.Add("isUsbConnected", isUsbConnected);
            deviceInfoData.Add("isCharging", isCharging);
            deviceInfoData.Add("batteryLevel", batteryLevel);
            deviceInfoData.Add("hardwareVersion", hardwareVersion);
            deviceInfoData.Add("dataEncryptionMode", dataEncryptionMode);
            deviceInfoData.Add("updateWorkKeyFlag", updateWorkKeyFlag);

            esc.onQposInfoResult(deviceInfoData);

        }

        /// <summary>
        /// Core function to return the KSN that is stored in the POS device
        /// </summary>
        /// <param name="pos">POS object</param>
        /// <returns>CommandUplink object that contains the device response</returns>
        private CommandUplink getKsn(VPos pos)
        {
            CommandDownlink dc = null;
            CommandUplink uc = null;

            dc = new CommandDownlink(0x11, 0x40, 5);
            pos.sendCommand(dc);
            uc = pos.receiveCommandWaitResult(5);
            return uc;
        }

        /// <summary>
        /// Core function to return the ID of the POS device
        /// </summary>
        /// <param name="pos">POS object</param>
        /// <returns>CommandUplink object that contains the device response</returns>
        private CommandUplink getPosId(VPos pos)
        {
            CommandDownlink dc = null;
            CommandUplink uc = null;

            dc = new CommandDownlink(0x10, 0x00, 5);
            pos.sendCommand(dc);
            uc = pos.receiveCommandWaitResult(5);
            return uc;
        }

        /// <summary>
        /// Core function to return the RSA stored in the POS device
        /// </summary>
        /// <param name="pos">POS object</param>
        /// <returns>CommandUplink object that contains the device response</returns>
        private CommandUplink getPosRsa(VPos pos)
        {
            CommandDownlink dc = null;
            CommandUplink uc = null;

            byte[] paras = new byte[2];
            
            paras[0] = 0x00;
            paras[1] = 0x87;

            dc = new CommandDownlink(0x21, 0xa0, 5, paras);
            pos.sendCommand(dc);
            uc = pos.receiveCommandWaitResult(5);
            return uc;
        }

        /// <summary>
        /// Core function to Set the Format ID stored in the POS device
        /// </summary>
        /// <param name="pos">POS object</param>
        /// <param name="deviceCommandString">Command String that will specify the format ID</param>
        /// <returns></returns>
        private CommandUplink setFormatID(VPos pos,String deviceCommandString)
        {
            CommandDownlink dc = null;
            CommandUplink uc = null;

            byte[] paras = new byte[2];

            paras[0] = 0x00;
            paras[1] = 0x02;

            //dc = new CommandDownlink(0x21, 0xa0, 5, paras);
            pos.sendRawPacket(Util.HexStringToByteArray(deviceCommandString));
            uc = pos.receiveCommandWaitResult(5);
            return uc;
        }

        /// <summary>
        /// Core function to return the summary info of the POS device
        /// </summary>
        /// <param name="pos">POS object</param>
        /// <returns>CommandUplink object that contains the device response</returns>
        private CommandUplink getPosInfo(VPos pos)
        {
            CommandDownlink dc = null;
            CommandUplink uc = null;

            dc = new CommandDownlink(0x11, 0x30, 5);
            pos.sendCommand(dc);
            uc = pos.receiveCommandWaitResult(5);
            return uc;
        }

        /// <summary>
        /// Core function that will be used to update the sleep time parameter (Used Privately)
        /// </summary>
        /// <param name="pos">POS object</param>
        /// <param name="timeout">Time out value</param>
        /// <returns>CommandUplink object that contains the device response</returns>
        private CommandUplink setSleepTime(VPos pos, int timeout)
        {
            byte[] paras = new byte[2];
            byte[] arrs = Util.IntToHex(timeout);
            if (arrs.Length > 1)
            {
                paras[0] = arrs[0];
                paras[1] = arrs[1];
            }
            else
            {
                paras[0] = 0;
                paras[1] = arrs[0];
            }

            CommandDownlink dc = new CommandDownlink(0x20, 0xd0, 5, paras);
            CommandUplink uc = null;
            pos.sendCommand(dc);
            uc = pos.receiveCommandWaitResult(5);
            return uc;
        }
    }
}
